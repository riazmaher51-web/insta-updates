$ErrorActionPreference = 'SilentlyContinue'
$src = Join-Path $PSScriptRoot 'bundle'
$newApp = Join-Path $src 'app.py'
$newDesk = Join-Path $src 'desktop.py'

Write-Host ''
Write-Host 'InstaUploader Update lag raha hai...'
Write-Host 'Laptop mein app ki saari copies dhoondh raha hun...'
Write-Host ''

$roots = @(
    "$env:USERPROFILE\Desktop",
    "$env:USERPROFILE\Downloads",
    "$env:USERPROFILE\Documents",
    "$env:USERPROFILE\OneDrive\Desktop",
    $PSScriptRoot
)

$found = @()
foreach ($r in $roots) {
    if (-not (Test-Path $r)) { continue }
    $hits = Get-ChildItem -Path $r -Recurse -Depth 4 -Filter 'desktop.py' -File
    foreach ($h in $hits) {
        $dir = $h.Directory
        if ($dir.Name -ne 'bundle') { continue }
        if ($dir.FullName -ieq $src) { continue }
        $appPy = Join-Path $dir.FullName 'app.py'
        if (-not (Test-Path $appPy)) { continue }
        $content = Get-Content $h.FullName -Raw
        if ($content -notmatch 'DesktopApp') { continue }
        Copy-Item $newApp (Join-Path $dir.FullName 'app.py') -Force
        Copy-Item $newDesk $h.FullName -Force
        $check = Get-Content $h.FullName -Raw
        if ($check -match '7 Nov: Like Comment') {
            $found += $dir.Parent.FullName
            Write-Host ('  UPDATE HO GAYA: ' + $dir.Parent.FullName)
        }
    }
}

Write-Host ''
if ($found.Count -eq 0) {
    Write-Host 'App ki koi copy nahi mili! '
    Write-Host 'Is message ka screenshot bhej dein.'
} else {
    Write-Host ('Total ' + $found.Count + ' jagah update lag gaya hai.')
    Write-Host 'Ab app kholo - upar title mein "7 Nov: Like Comment" likha aayega.'
    Write-Host 'Naya: accounts ki order ab fixed hai - Logout se entry nahi hatte gi, aur ▲ ▼ se order badal sakte hain.'
}
Write-Host ''
