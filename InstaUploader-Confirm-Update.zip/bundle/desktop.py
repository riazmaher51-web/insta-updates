#!/usr/bin/env python3
"""
InstaUploader Desktop — a native window on your laptop (no browser needed).
Post photos/videos to Instagram, download from links, schedule posts.
Everything stays on this computer.
"""
import os
import sys
from pathlib import Path as _Path

# Tell tkinter where its Tcl/Tk script libraries live (portable bundle).
_base = _Path(__file__).resolve().parent
os.environ.setdefault("TCL_LIBRARY", str(_base / "tcl" / "tcl8.6"))
os.environ.setdefault("TK_LIBRARY", str(_base / "tcl" / "tk8.6"))
# On some laptops Windows can't find the bundled Tk DLLs unless we say so.
try:
    os.add_dll_directory(str(_base))
except Exception:
    pass

import re
import secrets
import shutil
import threading
import time
import calendar
import json
import webbrowser
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox, simpledialog, ttk
except ImportError:
    print()
    print("The window version needs a missing piece on this laptop,")
    print("so InstaUploader opens in your browser instead - same features.")
    print()
    sys.exit(3)
from datetime import datetime, timedelta
from pathlib import Path

import app  # backend: accounts, queue, downloads, scheduler


# ---------------- auto-update ----------------
# The app checks this file on startup (and on demand). It holds:
#   {"build": 2, "marker": "31 Oct: ... ✅",
#    "pack": "https://raw.githubusercontent.com/riazmaher51-web/"
#            "insta-updates/main/InstaUploader-....zip"}
# build only ever goes up. A pack is applied only when the remote build
# is newer than UPDATE_BUILD below, and only after verifying the pack
# actually contains the marker. Only bundle/app.py + bundle/desktop.py
# are ever replaced — data/ (accounts, queue, posts) is never touched.
UPDATE_BUILD = 20
UPDATE_VERSION_URL = ("https://raw.githubusercontent.com/riazmaher51-web/"
                      "insta-updates/main/version.json")


def verify_update_pack(zip_path, marker):
    """True if the zip is intact, carries both code files, and its
    bundle/desktop.py contains the expected version marker."""
    import zipfile
    try:
        with zipfile.ZipFile(zip_path) as z:
            if z.testzip() is not None:
                return False
            names = z.namelist()
            if "bundle/app.py" not in names or \
                    "bundle/desktop.py" not in names:
                return False
            text = z.read("bundle/desktop.py").decode("utf-8", "ignore")
            return marker in text
    except Exception:
        return False


def apply_update_pack(zip_path, bundle_dir):
    """Back up the current code files, then replace them from the zip.

    Both new contents are read first, so a bad zip never leaves a
    half-replaced bundle. Old files stay as app.py.bak / desktop.py.bak.
    """
    import zipfile
    bundle_dir = Path(bundle_dir)
    with zipfile.ZipFile(zip_path) as z:
        app_src = z.read("bundle/app.py")
        desk_src = z.read("bundle/desktop.py")
    for name, data in (("app.py", app_src), ("desktop.py", desk_src)):
        target = bundle_dir / name
        if target.exists():
            shutil.copy2(target, bundle_dir / (name + ".bak"))
        target.write_bytes(data)
    return True


THEMES = {
    "Light": {
        "bg": "#f4f4f6", "fg": "#222222", "frame": "#ffffff",
        "accent": "#e91e63", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#222222",
        "sel": "#f8bbd0", "header_fg": "#e91e63",
        "code_bg": "#fff3e0",
    },
    "Dark": {
        "bg": "#262626", "fg": "#f0f0f0", "frame": "#333333",
        "accent": "#e91e63", "accent_fg": "#ffffff",
        "entry_bg": "#454545", "entry_fg": "#f0f0f0",
        "sel": "#5a5a5a", "header_fg": "#f06292",
        "code_bg": "#4a3a28",
    },
    "Pink": {
        "bg": "#fff0f4", "fg": "#5b2333", "frame": "#ffffff",
        "accent": "#d81b60", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#5b2333",
        "sel": "#f8bbd0", "header_fg": "#d81b60",
        "code_bg": "#ffe0ec",
    },
    "Ocean 🌊": {
        "bg": "#e8f4f8", "fg": "#123a4a", "frame": "#ffffff",
        "accent": "#0288d1", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#123a4a",
        "sel": "#b3e5fc", "header_fg": "#0277bd",
        "code_bg": "#e1f5fe",
    },
    "Sunset 🌅": {
        "bg": "#fff5ec", "fg": "#4e2a1e", "frame": "#ffffff",
        "accent": "#f4511e", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#4e2a1e",
        "sel": "#ffccbc", "header_fg": "#e64a19",
        "code_bg": "#fbe9e7",
    },
    "Forest 🌲": {
        "bg": "#eef5ee", "fg": "#1e3a1e", "frame": "#ffffff",
        "accent": "#2e7d32", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#1e3a1e",
        "sel": "#c8e6c9", "header_fg": "#1b5e20",
        "code_bg": "#e8f5e9",
    },
    "Lavender 💜": {
        "bg": "#f5f0fa", "fg": "#3a2a4e", "frame": "#ffffff",
        "accent": "#7b1fa2", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#3a2a4e",
        "sel": "#e1bee7", "header_fg": "#6a1b9a",
        "code_bg": "#f3e5f5",
    },
    "Coffee ☕": {
        "bg": "#f5f0eb", "fg": "#3e2f23", "frame": "#ffffff",
        "accent": "#6d4c41", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#3e2f23",
        "sel": "#d7ccc8", "header_fg": "#4e342e",
        "code_bg": "#efebe9",
    },
    "Custom 🎨": {
        "bg": "#f4f4f6", "fg": "#222222", "frame": "#ffffff",
        "accent": "#e91e63", "accent_fg": "#ffffff",
        "entry_bg": "#ffffff", "entry_fg": "#222222",
        "sel": "#f8bbd0", "header_fg": "#e91e63",
        "code_bg": "#fff3e0",
    },
}
THEME_FILE = app.DATA / "theme.json"


def custom_theme_dict(accent):
    t = dict(THEMES["Custom 🎨"])
    t["accent"] = accent
    t["header_fg"] = accent
    return t


def load_theme_name():
    try:
        return json.loads(THEME_FILE.read_text(encoding="utf-8")).get("theme", "Light")
    except Exception:
        return "Light"


APP_FONTS = [
    "Segoe UI", "Arial", "Calibri", "Verdana", "Tahoma", "Georgia",
    "Times New Roman", "Comic Sans MS", "Trebuchet MS", "Courier New",
    "Arial Black", "Arial Narrow", "Bahnschrift", "Book Antiqua",
    "Bookman Old Style", "Bradley Hand ITC", "Brush Script MT",
    "Cascadia Code", "Cascadia Mono", "Century Gothic", "Consolas",
    "Copperplate Gothic", "Corbel", "Curlz MT", "Edwardian Script ITC",
    "Franklin Gothic Medium", "Gabriola", "Garamond", "Harlow Solid Italic",
    "Impact", "Ink Free", "Javanese Text", "Juice ITC", "Kristen ITC",
    "Lucida Console", "Lucida Handwriting", "Lucida Sans",
    "Magneto", "Maiandra GD", "Malgun Gothic", "Microsoft Himalaya",
    "Microsoft JhengHei", "Microsoft New Tai Lue", "Microsoft Phagspa",
    "Microsoft Sans Serif", "Microsoft Tai Le", "Microsoft YaHei",
    "Microsoft Yi Baiti", "MingLiU", "Monotype Corsiva", "MS Gothic",
    "MS Mincho", "MS PGothic", "MS PMincho", "MV Boli", "Myanmar Text",
    "Nirmala UI", "Palatino Linotype", "Papyrus", "Pristina",
    "Ravie", "Rockwell", "Segoe Print", "Segoe Script", "Segoe UI Emoji",
    "Segoe UI Historic", "Segoe UI Symbol", "Showcard Gothic",
    "SimSun", "Sitka Text", "Snap ITC", "Stencil", "Sylfaen",
    "Symbol", "Tempus Sans ITC", "Viner Hand ITC", "Vivaldi",
    "Vladimir Script", "Wide Latin", "Wingdings", "Yu Gothic",
    "Yu Mincho", "Algerian", "Baskerville Old Face", "Bell MT",
    "Berlin Sans FB", "Bernard MT Condensed", "Bodoni MT",
    "Bodoni MT Black", "Britannic Bold", "Broadway", "Californian FB",
    "Calisto MT", "Castellar", "Chiller", "Colonna MT", "Cooper Black",
    "Footlight MT Light", "Forte", "Freestyle Script", "French Script MT",
    "Gigi", "Gill Sans MT", "Gloucester MT Extra Condensed",
    "Goudy Old Style", "Haettenschweiler", "Harrington",
]


def load_font_name():
    try:
        return json.loads(THEME_FILE.read_text(encoding="utf-8")).get(
            "font", "Segoe UI")
    except Exception:
        return "Segoe UI"


def save_font_name(name):
    try:
        data = {}
        try:
            data = json.loads(THEME_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
        data["font"] = name
        THEME_FILE.write_text(json.dumps(data), encoding="utf-8")
    except Exception:
        pass


def load_custom_accent():
    try:
        return json.loads(THEME_FILE.read_text(encoding="utf-8")).get(
            "custom_accent", "#e91e63")
    except Exception:
        return "#e91e63"


def save_theme_name(name, custom_accent=None):
    try:
        data = {"theme": name}
        if custom_accent:
            data["custom_accent"] = custom_accent
        elif name == "Custom 🎨":
            data["custom_accent"] = load_custom_accent()
        THEME_FILE.write_text(json.dumps(data), encoding="utf-8")
    except Exception:
        pass


def parse_datetime(s):
    s = (s or "").strip().replace("T", " ")
    for fmt in ("%Y-%m-%d %I:%M %p", "%Y-%m-%d %I:%M%p",
                "%d/%m/%Y %I:%M %p",
                "%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S",
                "%d/%m/%Y %H:%M"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def parse_time(s):
    s = (s or "").strip()
    for fmt in ("%I:%M %p", "%I:%M%p", "%H:%M"):
        try:
            return datetime.strptime(s, fmt).strftime("%H:%M")
        except ValueError:
            pass
    return None


def chunk_consecutive(items, n):
    """Split a list into consecutive chunks of at most n items.

    Used by the bulk dialog's one-go month setup: photos in dialog
    order become consecutive carousels. A trailing chunk of exactly
    1 item is NOT a valid carousel — the caller leaves it single.
    """
    try:
        n = int(n or 4)
    except (TypeError, ValueError):
        n = 4
    n = max(2, min(20, n))
    return [list(items[i:i + n]) for i in range(0, len(items), n)]


def short(s, n=42):
    s = s or ""
    return s if len(s) <= n else s[:n] + "…"


class DateTimePicker:
    """Popup calendar + time picker that fills a target entry."""

    def __init__(self, parent, entry, theme):
        self.entry = entry
        self.theme = theme
        dt = parse_datetime(entry.get()) or datetime.now()
        self.year, self.month, self.day = dt.year, dt.month, dt.day
        h12 = dt.hour % 12 or 12
        self.hour = tk.StringVar(value=f"{h12:02d}")
        self.minute = tk.StringVar(value=f"{dt.minute:02d}")
        self.ampm = tk.StringVar(value="PM" if dt.hour >= 12 else "AM")

        self.top = tk.Toplevel(parent)
        self.top.title("Pick date & time")
        self.top.resizable(False, False)
        self.top.transient(parent)
        self.top.grab_set()

        t = theme
        self.top.configure(bg=t["frame"])
        nav = tk.Frame(self.top, bg=t["frame"])
        nav.pack(fill="x", padx=8, pady=(8, 4))
        tk.Button(nav, text="◀", width=3, command=self.prev_month,
                  bg=t["frame"], fg=t["fg"]).pack(side="left")
        self.title_lbl = tk.Label(nav, font=("Segoe UI", 11, "bold"),
                                  bg=t["frame"], fg=t["fg"])
        self.title_lbl.pack(side="left", expand=True)
        tk.Button(nav, text="▶", width=3, command=self.next_month,
                  bg=t["frame"], fg=t["fg"]).pack(side="right")

        self.cal = tk.Frame(self.top, bg=t["frame"])
        self.cal.pack(padx=8)
        for i, d in enumerate(["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]):
            tk.Label(self.cal, text=d, font=("Segoe UI", 9, "bold"),
                     bg=t["frame"], fg=t["header_fg"], width=4).grid(row=0, column=i)

        tf = tk.Frame(self.top, bg=t["frame"])
        tf.pack(pady=8)
        tk.Label(tf, text="Time:", bg=t["frame"], fg=t["fg"],
                 font=("Segoe UI", 10)).pack(side="left")
        tk.Spinbox(tf, from_=1, to=12, width=3, textvariable=self.hour,
                   format="%02.0f", font=("Segoe UI", 11),
                   bg=t["entry_bg"], fg=t["entry_fg"]).pack(side="left", padx=(6, 0))
        tk.Label(tf, text=":", bg=t["frame"], fg=t["fg"],
                 font=("Segoe UI", 11)).pack(side="left")
        tk.Spinbox(tf, from_=0, to=59, width=3, textvariable=self.minute,
                   format="%02.0f", font=("Segoe UI", 11),
                   bg=t["entry_bg"], fg=t["entry_fg"]).pack(side="left")
        ttk.Combobox(tf, textvariable=self.ampm, values=["AM", "PM"],
                     state="readonly", width=4,
                     font=("Segoe UI", 11)).pack(side="left", padx=(6, 0))

        bf = tk.Frame(self.top, bg=t["frame"])
        bf.pack(pady=(0, 10))
        tk.Button(bf, text="OK", width=10, command=self.ok,
                  bg=t["accent"], fg=t["accent_fg"],
                  font=("Segoe UI", 10, "bold")).pack(side="left", padx=6)
        tk.Button(bf, text="Cancel", width=10, command=self.top.destroy,
                  bg=t["frame"], fg=t["fg"]).pack(side="left", padx=6)
        self.draw()

    def prev_month(self):
        if self.month == 1:
            self.month, self.year = 12, self.year - 1
        else:
            self.month -= 1
        self.draw()

    def next_month(self):
        if self.month == 12:
            self.month, self.year = 1, self.year + 1
        else:
            self.month += 1
        self.draw()

    def draw(self):
        t = self.theme
        self.title_lbl.config(
            text=f"{calendar.month_name[self.month]} {self.year}")
        for w in self.cal.grid_slaves():
            if int(w.grid_info()["row"]) > 0:
                w.destroy()
        for r, week in enumerate(calendar.monthcalendar(self.year, self.month), 1):
            for c, day in enumerate(week):
                if day == 0:
                    tk.Label(self.cal, text="", bg=t["frame"], width=4).grid(
                        row=r, column=c)
                else:
                    is_sel = (day == self.day)
                    b = tk.Button(self.cal, text=str(day), width=4,
                                  font=("Segoe UI", 10, "bold" if is_sel else "normal"),
                                  bg=t["accent"] if is_sel else t["frame"],
                                  fg=t["accent_fg"] if is_sel else t["fg"],
                                  command=lambda d=day: self.choose(d))
                    b.grid(row=r, column=c, padx=1, pady=1)

    def choose(self, day):
        self.day = day
        self.draw()

    def ok(self):
        try:
            h = max(1, min(12, int(self.hour.get())))
            mi = max(0, min(59, int(self.minute.get())))
        except ValueError:
            h, mi = 10, 0
        ap = self.ampm.get().strip().upper() or "AM"
        if ap not in ("AM", "PM"):
            ap = "AM"
        self.entry.delete(0, "end")
        self.entry.insert(
            0, f"{self.year:04d}-{self.month:02d}-{self.day:02d} {h:02d}:{mi:02d} {ap}")
        self.top.destroy()


class DesktopApp:
    def __init__(self, root):
        self.root = root
        self.root.title(f"InstaUploader  (📁 {app.BASE.name})"
                        "  —  7 Nov: Confirm ✅")
        self.root.geometry("740x660")
        self.root.minsize(680, 580)
        self.chosen_file = None
        self.carousel_files = []  # direct-form carousel picks (photos)
        self.carousel_src = ""  # "zip" | "photos" | "" (no pick)
        self.code_rows = {}
        self.queue_trees = []
        self.queue_filters = []
        self.queue_checked = set()  # job ids ticked via the ✓ column
        # One state per running bulk download: runs no longer share a
        # single cancel flag or progress line, so starting a second
        # account's run never disturbs the first one's.
        self.bulk_runs = {}
        self._bulk_run_seq = 0
        self._tab_canvases = []
        self.theme_name = load_theme_name()
        self.font_name = load_font_name()
        if self.font_name not in APP_FONTS:
            self.font_name = "Segoe UI"
        if self.theme_name == "Custom 🎨":
            self.theme = custom_theme_dict(load_custom_accent())
        else:
            self.theme = THEMES.get(self.theme_name, THEMES["Light"])

        self.apply_theme()

        top = ttk.Frame(root, padding=(10, 8, 10, 0))
        top.pack(fill="x")
        ttk.Label(top, text="📸 InstaUploader",
                  font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Label(top, text=f"   📁 Copy: {app.BASE.name}",
                  font=("Segoe UI", 9)).pack(side="left")
        ttk.Label(top, text="Font:").pack(side="right", padx=(8, 4))
        self.font_btn = ttk.Button(top, text=f"🔤 {self.font_name}", width=16,
                                   command=self.open_font_picker)
        self.font_btn.pack(side="right")
        ttk.Label(top, text="Theme:").pack(side="right", padx=(0, 4))
        ttk.Label(top, text="Theme:").pack(side="right", padx=(0, 4))
        self.theme_combo = ttk.Combobox(top, state="readonly", width=12,
                                        values=list(THEMES.keys()))
        self.theme_combo.set(self.theme_name)
        self.theme_combo.pack(side="right")
        self.theme_combo.bind("<<ComboboxSelected>>", self.change_theme)
        ttk.Button(top, text="🎨", width=3,
                   command=self.pick_custom_color).pack(side="right",
                                                       padx=(0, 4))

        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=8)

        self.post_tab = self._scrollable_tab("  📤 Post  ")
        self.sched_tab = self._scrollable_tab("  📅 Schedule  ")
        self.sched_tab_id = self.notebook.tabs()[-1]
        self.groups_tab = self._scrollable_tab("  👥 Groups  ")
        self.link_tab = self._scrollable_tab("  🔗 Download from link  ")
        self.hist_tab = self._scrollable_tab("  🕘 History  ")
        self.notif_tab = self._scrollable_tab("  🔔 Notifications  ")
        self.posting_tab = self._scrollable_tab("  ▶️ Posting  ")
        self.posting_tab_id = self.notebook.tabs()[-1]
        self.fb_tab = self._scrollable_tab("  🔵 Facebook  ")
        self.access_tab = self._scrollable_tab("  🔑 Dost Access  ")

        self.build_post_tab()
        self.build_schedule_tab()
        self.build_groups_tab()
        self.build_link_tab()
        self.build_hist_tab()
        self.build_notif_tab()
        self.build_posting_tab()
        self.build_fb_tab()
        self.build_access_tab()

        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(root, textvariable=self.status_var, relief="sunken",
                  anchor="w", padding=(6, 2)).pack(fill="x", side="bottom")

        self.refresh_groups()
        self.root.after(2500, self.refresh)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self._check_activation()
        # Auto-update: one silent check at startup when enabled.
        # Threaded, so a slow or offline connection never blocks the
        # window; failures stay silent (the manual button reports them).
        try:
            if self.auto_update_var.get():
                threading.Thread(target=self.check_for_updates,
                                 daemon=True).start()
        except Exception:
            pass
        # Posting control: the scheduler starts PAUSED (app.py
        # default) — ask her before any automatic posting runs.
        self._ask_startup_posting()

    # ---------------- dost access ----------------
    def build_access_tab(self):
        """Owner panel: issue a username / key / password for a friend."""
        f = self.access_tab
        ttk.Label(f, text="🔑 Dost ko access dein",
                  style="Header.TLabel").pack(anchor="w", pady=(0, 4))
        ttk.Label(f, text="Ye sirf doston wali copy ke liye hai. Aap ki apni app par is ka koi asar nahi hota.",
                  wraplength=640).pack(anchor="w", pady=(0, 8))
        box = ttk.LabelFrame(f, text=" Dost ka username / key / password ",
                             padding=10)
        box.pack(fill="x")
        ttk.Label(box, text="Dost ka username:").pack(anchor="w")
        self.access_user = ttk.Entry(box, width=40)
        self.access_user.pack(anchor="w", pady=(0, 6))
        ttk.Label(box, text="Key (dost isi se app khole gi):").pack(anchor="w")
        keyrow = ttk.Frame(box)
        keyrow.pack(fill="x", pady=(0, 6))
        self.acc_key = ttk.Entry(keyrow, width=30)
        self.acc_key.pack(side="left")
        ttk.Button(keyrow, text="🎲 Key banayein",
                   command=self._access_gen_key).pack(side="left", padx=6)
        ttk.Label(box, text="Password:").pack(anchor="w")
        self.acc_pw = ttk.Entry(box, width=40, show="*")
        self.acc_pw.pack(anchor="w", pady=(0, 8))
        ttk.Button(box, text="💾 Access file banayein",
                   command=self._access_save).pack(anchor="w")
        self.acc_msg = ttk.Label(box, text="", wraplength=640)
        self.acc_msg.pack(anchor="w", pady=(6, 0))
        ttk.Label(f, text="Access file mein password NAHI hota (sirf us ka hash hota hai). Dost ko ye file + teen values (username, key, password) bhejein — file ke baghair app nahi khule ga.",
                  wraplength=640).pack(anchor="w", pady=8)

    def _access_gen_key(self):
        self.acc_key.delete(0, tk.END)
        self.acc_key.insert(0, app.make_access_key())

    def _access_save(self):
        user = (self.access_user.get() or "").strip()
        key = (self.acc_key.get() or "").strip()
        pw = self.acc_pw.get() or ""
        if not user or not key or not pw:
            messagebox.showwarning("Dost Access",
                                   "Teeno cheezein likhein: username, key aur password.")
            return
        record = app.make_access_record(user, key, pw)
        path = filedialog.asksaveasfilename(
            title="Access file kahan save karein",
            defaultextension=".json", initialfile="dost-access.json",
            filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            Path(path).write_text(json.dumps(record, ensure_ascii=False,
                                             indent=2), encoding="utf-8")
            # A copy in this app's own data folder, so it is never lost
            # (data/ is never shipped in any pack).
            app.DATA.mkdir(exist_ok=True)
            app.ACCESS_FILE.write_text(json.dumps(record, ensure_ascii=False,
                                                  indent=2), encoding="utf-8")
        except Exception as e:
            messagebox.showwarning("Dost Access", f"File nahi bani: {e}")
            return
        self.acc_msg.config(
            text=f"Access file ban gayi: {path}\n"
                 "Dost ko ye file + username, key aur password bhejein.")

    def _activation_record_candidates(self):
        cands = []
        for p in (app.BASE / "dost-access.json", app.DATA / "dost-access.json"):
            if p.exists():
                cands.append(p)
        return cands

    def _create_activation_dialog(self):
        """Builds (but does not wait on) the first-run setup dialog."""
        top = tk.Toplevel(self.root)
        top.title("🔑 Setup — Username / Key / Password")
        top.geometry("440x340")
        ttk.Label(top, text="🔑 Setup",
                  font=("Segoe UI", 14, "bold")).pack(pady=(12, 2))
        ttk.Label(top, text="App kholne ke liye username, key aur password likhein (jo aap ko diye gaye hain).",
                  wraplength=380).pack(pady=(0, 10))
        frm = ttk.Frame(top, padding=10)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="Username:").pack(anchor="w")
        user_e = ttk.Entry(frm, width=36)
        user_e.pack(anchor="w", pady=(0, 6))
        ttk.Label(frm, text="Key:").pack(anchor="w")
        key_e = ttk.Entry(frm, width=36)
        key_e.pack(anchor="w", pady=(0, 6))
        ttk.Label(frm, text="Password:").pack(anchor="w")
        pw_e = ttk.Entry(frm, width=36, show="*")
        pw_e.pack(anchor="w", pady=(0, 8))
        self._act_record = None
        self._act_file_lbl = ttk.Label(frm, text="Access file: nahi chuni gayi")
        self._act_file_lbl.pack(anchor="w", pady=(0, 6))
        # Auto-load a file dropped in the app folder.
        for p in self._activation_record_candidates():
            try:
                self._act_record = json.loads(p.read_text(encoding="utf-8"))
                self._act_file_lbl.config(
                    text=f"Access file: {p.name} mil gayi ✅")
                break
            except Exception:
                pass
        btns = ttk.Frame(frm)
        btns.pack(fill="x", pady=(4, 0))
        ttk.Button(btns, text="📁 Access file chunein",
                   command=lambda: self._act_pick_file(top)).pack(side="left")
        ttk.Button(btns, text="🔓 Unlock karein",
                   command=lambda: self._act_try_unlock(
                       top, user_e, key_e, pw_e)).pack(side="left", padx=6)
        ttk.Button(btns, text="Band karein",
                   command=lambda: self._act_quit(top)).pack(side="left")
        self._act_ok = False
        return top

    def _act_pick_file(self, top):
        p = filedialog.askopenfilename(title="Access file chunein",
                                       filetypes=[("JSON", "*.json")])
        if not p:
            return
        try:
            self._act_record = json.loads(Path(p).read_text(encoding="utf-8"))
            self._act_file_lbl.config(
                text=f"Access file: {Path(p).name} mil gayi ✅")
        except Exception:
            messagebox.showwarning("Access file",
                                   "Ye file parhi nahi gayi. Sahi dost-access.json chunein.",
                                   parent=top)

    def _act_try_unlock(self, top, user_e, key_e, pw_e):
        if self._act_record is None:
            messagebox.showwarning("Setup",
                                   "Pehle Access file chunein (dost-access.json).",
                                   parent=top)
            return
        if app.verify_access(user_e.get(), key_e.get(), pw_e.get(),
                             self._act_record):
            try:
                app.ACTIVATED_FILE.write_text(json.dumps(
                    {"username": (user_e.get() or "").strip(),
                     "key": (key_e.get() or "").strip().upper(),
                     "activated_at": datetime.now().isoformat(timespec="seconds")},
                    ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception:
                pass
            self._act_ok = True
            top.destroy()
        else:
            messagebox.showwarning("Setup",
                                   "Ghalat username, key ya password. Dobara likhein.",
                                   parent=top)

    def _act_quit(self, top):
        top.destroy()
        self.root.destroy()

    def _check_activation(self):
        """Friend copies stay locked behind the setup until unlocked once."""
        if not app.needs_activation():
            return
        top = self._create_activation_dialog()
        top.transient(self.root)
        top.grab_set()
        self.root.wait_window(top)
        if not getattr(self, "_act_ok", False):
            if self.root.winfo_exists():
                self.root.destroy()

    # ---------------- helpers ----------------
    def apply_theme(self):
        t = self.theme
        f = self.font_name
        self.root.configure(bg=t["bg"])
        try:
            style = ttk.Style()
            style.theme_use("clam")
        except Exception:
            style = ttk.Style()
        style.configure("TFrame", background=t["frame"])
        style.configure("TLabel", background=t["frame"], foreground=t["fg"],
                        font=(f, 10))
        style.configure("Header.TLabel", foreground=t["header_fg"],
                        font=(f, 16, "bold"))
        style.configure("TButton", background=t["frame"], foreground=t["fg"],
                        font=(f, 10), padding=6)
        style.map("TButton",
                  background=[("active", t["sel"])])
        style.configure("Accent.TButton", background=t["accent"],
                        foreground=t["accent_fg"], font=(f, 11, "bold"),
                        padding=8)
        style.map("Accent.TButton",
                  background=[("active", t["accent"])])
        style.configure("TEntry", fieldbackground=t["entry_bg"],
                        foreground=t["entry_fg"], insertcolor=t["entry_fg"])
        style.configure("TCombobox", fieldbackground=t["entry_bg"],
                        foreground=t["entry_fg"], arrowcolor=t["fg"])
        style.configure("TNotebook", background=t["bg"])
        style.configure("TNotebook.Tab", background=t["frame"],
                        foreground=t["fg"], padding=(18, 10),
                        font=(f, 12, "bold"))
        style.map("TNotebook.Tab",
                  background=[("selected", t["accent"])],
                  foreground=[("selected", t["accent_fg"])])
        style.configure("Treeview", background=t["entry_bg"],
                        foreground=t["entry_fg"], fieldbackground=t["entry_bg"],
                        font=(f, 10), rowheight=28)
        style.configure("Treeview.Heading", background=t["frame"],
                        foreground=t["header_fg"], font=(f, 10, "bold"))
        style.map("Treeview", background=[("selected", t["sel"])])
        style.configure("TLabelframe", background=t["frame"],
                        foreground=t["fg"])
        style.configure("TLabelframe.Label", background=t["frame"],
                        foreground=t["header_fg"], font=(f, 12, "bold"))
        style.configure("TRadiobutton", background=t["frame"],
                        foreground=t["fg"], font=("Segoe UI", 10))
        # plain tk widgets
        for w in (getattr(self, "caption_text", None),
                  getattr(self, "link_caption", None),
                  getattr(self, "gcaption_text", None),
                  getattr(self, "acc_list", None),
                  getattr(self, "grp_members_list", None),
                  getattr(self, "bulk_summary", None),
                  getattr(self, "links_text", None),
                  getattr(self, "hist_list", None),
                  getattr(self, "fb_acc_list", None)):
            if w is not None:
                try:
                    w.configure(bg=t["entry_bg"], fg=t["entry_fg"],
                                insertbackground=t["entry_fg"],
                                selectbackground=t["sel"])
                except Exception:
                    pass
        # tab scroll areas follow the theme background
        for cv in getattr(self, "_tab_canvases", []):
            try:
                cv.configure(bg=t["bg"])
            except Exception:
                pass

    def change_theme(self, _event=None):
        name = self.theme_combo.get()
        if name == "Custom 🎨":
            self.pick_custom_color()
            return
        if name in THEMES:
            self.theme_name = name
            self.theme = THEMES[name]
            save_theme_name(name)
            self.apply_theme()
            self.status(f"Theme: {name}")

    def change_font(self, _event=None):
        name = self.font_name
        if name in APP_FONTS:
            save_font_name(name)
            self.apply_theme()
            self.font_btn.config(text=f"🔤 {name}")
            self.status(f"Font: {name}")

    def open_font_picker(self):
        """Font list where each name is shown in its own style."""
        top = tk.Toplevel(self.root)
        top.title("Choose a font")
        top.geometry("380x480")
        top.transient(self.root)
        top.grab_set()
        ttk.Label(top, text="Pick a font — each name shows its own style:",
                  font=(self.font_name, 10, "bold")).pack(padx=12, pady=(12, 4),
                                                          anchor="w")
        fr = ttk.Frame(top)
        fr.pack(fill="both", expand=True, padx=12, pady=4)
        lb = tk.Listbox(fr, font=(self.font_name, 11))
        sb = ttk.Scrollbar(fr, orient="vertical", command=lb.yview)
        lb.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        lb.pack(side="left", fill="both", expand=True)
        for fnt in APP_FONTS:
            lb.insert("end", fnt)
            try:
                lb.itemconfig("end", font=(fnt, 13))
            except Exception:
                pass
        # select current
        if self.font_name in APP_FONTS:
            idx = APP_FONTS.index(self.font_name)
            lb.selection_set(idx)
            lb.see(idx)
        # live preview
        prev = tk.Label(top, text="Your name, engraved forever 💛",
                        font=(self.font_name, 13))
        prev.pack(pady=8)

        def on_pick(_e=None):
            sel = lb.curselection()
            if sel:
                prev.config(font=(lb.get(sel[0]), 13))
        lb.bind("<<ListboxSelect>>", on_pick)

        def apply():
            sel = lb.curselection()
            if sel:
                self.font_name = lb.get(sel[0])
                self.change_font()
            top.destroy()
        br = ttk.Frame(top)
        br.pack(fill="x", padx=12, pady=(0, 12))
        ttk.Button(br, text="Apply", style="Accent.TButton",
                   command=apply).pack(side="right")
        ttk.Button(br, text="Cancel",
                   command=top.destroy).pack(side="right", padx=(0, 8))

    def pick_custom_color(self):
        from tkinter import colorchooser
        picked = colorchooser.askcolor(title="Pick your theme color",
                                       color=load_custom_accent())
        if not picked or not picked[1]:
            self.theme_combo.set(self.theme_name)
            return
        accent = picked[1]
        self.theme_name = "Custom 🎨"
        self.theme = custom_theme_dict(accent)
        save_theme_name("Custom 🎨", custom_accent=accent)
        self.theme_combo.set("Custom 🎨")
        self.apply_theme()
        self.status(f"Theme: Custom 🎨 ({accent})")

    def status(self, msg):
        self.status_var.set(msg)

    def on_close(self):
        self.root.destroy()

    def selected_job(self):
        jobs = self.selected_jobs()
        return jobs[0] if jobs else None

    def selected_jobs(self):
        """All selected queue jobs across the queue trees (multi-select)."""
        found = []
        seen = set()
        for tree in self.queue_trees:
            for iid in tree.selection():
                if iid in seen:
                    continue
                seen.add(iid)
                with app.QUEUE_LOCK:
                    for j in app.QUEUE:
                        if j.get("id") == iid:
                            found.append(j)
                            break
        return found

    def checked_jobs(self):
        """Queue jobs ticked via the ✓ checkbox column."""
        found = []
        with app.QUEUE_LOCK:
            for j in app.QUEUE:
                if j.get("id") in self.queue_checked:
                    found.append(j)
        return found

    def toggle_queue_check(self, tree, event):
        """Clicking the ✓ column ticks/unticks that row's checkbox."""
        row = tree.identify_row(event.y)
        if not row:
            return
        if tree.identify_column(event.x) == "#1":
            if row in self.queue_checked:
                self.queue_checked.discard(row)
            else:
                self.queue_checked.add(row)
            self.refresh_queue()
            return "break"

    # ---------------- post tab ----------------
    def _scrollable_tab(self, text):
        """Notebook tab with a vertical scrollbar; returns the inner frame."""
        outer = ttk.Frame(self.notebook)
        self.notebook.add(outer, text=text)
        canvas = tk.Canvas(outer, highlightthickness=0,
                           bg=self.theme.get("bg", "#ffffff"))
        vbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vbar.set)
        vbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = ttk.Frame(canvas, padding=10)
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfig(win, width=e.width))

        def on_wheel(e):
            canvas.yview_scroll(-1 if e.delta > 0 else 1, "units")

        def bind_wheel(_e):
            canvas.bind_all("<MouseWheel>", on_wheel)

        def unbind_wheel(_e):
            canvas.unbind_all("<MouseWheel>")

        for w in (outer, canvas, inner):
            w.bind("<Enter>", bind_wheel)
            w.bind("<Leave>", unbind_wheel)
        self._tab_canvases.append(canvas)
        return inner

    def build_post_tab(self):
        # accounts
        acc = ttk.LabelFrame(self.post_tab, text="Your accounts", padding=8)
        acc.pack(fill="x")
        self.acc_frame = acc
        # Box for accounts that need a login (⚠️ login needed + ⏻ logged
        # out): one row each with its own Login button, so a broken
        # account is fixed from here instead of hunted in the list.
        self.login_needed_frame = ttk.LabelFrame(
            self.post_tab, text="🔑 Login chahiye", padding=8)
        self.login_needed_frame.pack(fill="x", pady=(8, 0))
        # The box scrolls on its own: with many accounts needing a login
        # the rows used to push the whole tab down and the later ones
        # were out of sight. Now 4 rows show and the rest scroll here.
        self._login_needed_canvas = tk.Canvas(
            self.login_needed_frame, highlightthickness=0, height=32,
            bg=self.theme.get("bg", "#ffffff"))
        self._login_needed_vbar = ttk.Scrollbar(
            self.login_needed_frame, orient="vertical",
            command=self._login_needed_canvas.yview)
        self._login_needed_canvas.configure(
            yscrollcommand=self._login_needed_vbar.set)
        self._login_needed_vbar.pack(side="right", fill="y")
        self._login_needed_canvas.pack(side="left", fill="both", expand=True)
        self._login_needed_box = ttk.Frame(self._login_needed_canvas)
        _ln_win = self._login_needed_canvas.create_window(
            (0, 0), window=self._login_needed_box, anchor="nw")
        self._login_needed_box.bind(
            "<Configure>",
            lambda e: self._login_needed_canvas.configure(
                scrollregion=self._login_needed_canvas.bbox("all")))
        self._login_needed_canvas.bind(
            "<Configure>",
            lambda e: self._login_needed_canvas.itemconfig(
                _ln_win, width=e.width))
        self._login_needed_shown = None
        self.acc_list = tk.Listbox(acc, height=6, font=("Segoe UI", 10))
        self.acc_list.pack(side="left", fill="both", expand=True)
        acc_sb = ttk.Scrollbar(acc, orient="vertical",
                               command=self.acc_list.yview)
        self.acc_list.configure(yscrollcommand=acc_sb.set)
        acc_sb.pack(side="left", fill="y")
        btns = ttk.Frame(acc)
        btns.pack(side="left", padx=(8, 0))
        ttk.Label(btns, text="Username").pack(anchor="w")
        self.acc_user = ttk.Entry(btns, width=20)
        self.acc_user.pack()
        ttk.Label(btns, text="Password").pack(anchor="w")
        self.acc_pass = ttk.Entry(btns, width=20, show="*")
        self.acc_pass.pack()
        row = ttk.Frame(btns)
        row.pack(pady=(6, 0))
        ttk.Button(row, text="+ Add", command=self.add_account).pack(side="left")
        ttk.Button(row, text="Remove", command=self.remove_account).pack(side="left", padx=(6, 0))
        row2 = ttk.Frame(btns)
        row2.pack(pady=(4, 0))
        ttk.Button(row2, text="⏻ Logout",
                   command=self.logout_account).pack(side="left")
        ttk.Button(row2, text="🔑 Login",
                   command=self.relogin_account).pack(side="left", padx=(6, 0))
        ttk.Button(row2, text="▲ Up",
                   command=lambda: self.move_account(-1)).pack(side="left", padx=(6, 0))
        ttk.Button(row2, text="▼ Down",
                   command=lambda: self.move_account(1)).pack(side="left", padx=(6, 0))
        row3 = ttk.Frame(btns)
        row3.pack(pady=(4, 0))
        ttk.Button(row3, text="👁 4 accounts dekho…",
                   command=self._multi_view_dialog).pack(side="left")
        ttk.Label(btns, text="✅ = active  •  ⏻ = logged out  •  ⚠️ = login needed.\n"
                  "⚠️ wale account ko select karein aur 🔑 Login dabayein.\n"
                  "▲ ▼ move the account; the order is saved and never\n"
                  "changes on logout or re-login.",
                  font=("Segoe UI", 8), foreground="gray").pack(anchor="w", pady=(6, 0))
        ttk.Label(btns, text="Password login blocked? Use Session ID instead:",
                  font=("Segoe UI", 8)).pack(anchor="w", pady=(8, 0))
        self.acc_session = ttk.Entry(btns, width=20, show="*")
        self.acc_session.pack()
        ttk.Button(btns, text="+ Add via Session ID",
                   command=self.add_via_session).pack(pady=(4, 0))
        ttk.Label(btns, text="Get it: instagram.com in Chrome → F12 → Application →\n"
                  "Cookies → instagram.com → copy 'sessionid' value.",
                  font=("Segoe UI", 7), foreground="gray").pack(anchor="w")
        upd_row = ttk.Frame(btns)
        upd_row.pack(fill="x", pady=(8, 0))
        self.auto_update_var = tk.BooleanVar(value=self._update_enabled())
        ttk.Checkbutton(upd_row, text="🔄 Auto-update",
                        variable=self.auto_update_var,
                        command=self._save_update_toggle).pack(side="left")
        ttk.Button(upd_row, text="🔍 Check karein",
                   command=self.manual_update_check).pack(side="left",
                                                          padx=(6, 0))

        # new post — lives on the Schedule tab now, so creating a
        # post and checking the scheduled list happen in one place
        np_ = ttk.LabelFrame(self.sched_tab, text="New post", padding=8)
        np_.pack(fill="x", pady=(8, 0))
        r1 = ttk.Frame(np_)
        r1.pack(fill="x")
        ttk.Label(r1, text="Account:").pack(side="left")
        self.post_account = ttk.Combobox(r1, state="readonly", width=22)
        self.post_account.pack(side="left", padx=(6, 12))
        self.file_btn = ttk.Button(r1, text="Choose photo/video…",
                                   command=self.choose_file)
        self.file_btn.pack(side="left")
        # Button order, as she specified: single-post pair first
        # (file, then its zip), then the carousel pair (photos,
        # then its zip).
        self.zip_btn = ttk.Button(r1, text="📦 Zip…",
                                  command=self.choose_zip)
        self.zip_btn.pack(side="left", padx=(6, 0))
        self.car_btn = ttk.Button(r1, text="🎠 Carousel photos…",
                                  command=self.choose_carousel)
        self.car_btn.pack(side="left", padx=(6, 0))
        self.carzip_btn = ttk.Button(r1, text="🎠 Carousel Zip…",
                                     command=self.choose_carousel_zip)
        self.carzip_btn.pack(side="left", padx=(6, 0))
        self.file_lbl = ttk.Label(r1, text="no file chosen",
                                  font=("Segoe UI", 9, "italic"))
        self.file_lbl.pack(side="left", padx=(8, 0))

        # Live carousel summary, right under the pick row: what this
        # carousel will do (Post now / Schedule + Story on/off), so
        # there is never any doubt whether schedule/story apply to
        # the carousel pick. The row is packed now (so it sits under
        # r1) but its label stays unpacked — an empty frame takes no
        # space — until a carousel is picked.
        self.car_sum_row = ttk.Frame(np_)
        self.car_sum_row.pack(fill="x")
        self.car_sum_lbl = ttk.Label(self.car_sum_row,
                                     font=(self.font_name, 9, "bold"))

        capbar = ttk.Frame(np_)
        capbar.pack(fill="x", pady=(6, 0))
        ttk.Label(capbar, text="Caption:").pack(side="left")
        ttk.Button(capbar, text="📦 Zip se caption",
                   command=self.load_caption_from_zip).pack(
                       side="left", padx=(8, 0))
        self.caption_text = tk.Text(np_, height=3, font=("Segoe UI", 10))
        self.caption_text.pack(fill="x")

        r2 = ttk.Frame(np_)
        r2.pack(fill="x", pady=(6, 0))
        self.when_var = tk.StringVar(value="now")
        ttk.Radiobutton(r2, text="Post now", variable=self.when_var,
                        value="now").pack(side="left")
        ttk.Radiobutton(r2, text="Schedule:", variable=self.when_var,
                        value="later").pack(side="left", padx=(12, 4))
        self.sched_entry = ttk.Entry(r2, width=18)
        self.sched_entry.pack(side="left")
        ttk.Button(r2, text="📅", width=3,
                   command=lambda: (DateTimePicker(self.root, self.sched_entry,
                                                   self.theme),
                                    self._refresh_car_summary())).pack(side="left", padx=(4, 0))
        ttk.Label(r2, text="YYYY-MM-DD HH:MM AM",
                  font=("Segoe UI", 8)).pack(side="left", padx=(6, 0))
        ttk.Label(r2, text="every", font=("Segoe UI", 9)).pack(
            side="left", padx=(10, 2))
        self.hours_entry = ttk.Entry(r2, width=4, font=("Segoe UI", 10))
        self.hours_entry.pack(side="left")
        ttk.Label(r2, text="hours apart", font=("Segoe UI", 9)).pack(
            side="left", padx=(2, 0))

        r2b = ttk.Frame(np_)
        r2b.pack(fill="x", pady=(4, 0))
        self.story_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            r2b, text="📱 Post ke saath Story pe bhi lagayein",
            variable=self.story_var).pack(side="left")
        self.cover_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            r2b, text="🖼 Video ke saath cover bhi lagayein",
            variable=self.cover_var).pack(side="left", padx=(14, 0))
        self.cover_path = ""
        ttk.Button(r2b, text="Cover photo…",
                   command=self.choose_cover).pack(side="left",
                                                   padx=(6, 0))
        self.cover_lbl = ttk.Label(r2b, text="", font=("Segoe UI", 8))
        self.cover_lbl.pack(side="left", padx=(4, 0))
        ttk.Button(r2b, text="📦 Zip..",
                   command=self.choose_cover_zip).pack(side="left",
                                                       padx=(8, 0))

        # Keep the carousel summary live: any Post now / Schedule /
        # Story / time change rewrites it on the spot.
        self.when_var.trace_add(
            "write", lambda *a: self._refresh_car_summary())
        self.story_var.trace_add(
            "write", lambda *a: self._refresh_car_summary())
        self.sched_entry.bind(
            "<KeyRelease>", lambda e: self._refresh_car_summary())
        self.sched_entry.bind(
            "<FocusOut>", lambda e: self._refresh_car_summary())

        # Add to queue comes LAST, below the cover row — so a post is
        # only added after video, caption, schedule and cover are all
        # set, never before the cover is picked.
        r3 = ttk.Frame(np_)
        r3.pack(fill="x", pady=(8, 0))
        ttk.Button(r3, text="Add to queue", style="Accent.TButton",
                   command=self.add_post).pack(side="right")

        # login codes (stays visible while a code is needed)
        self.code_frame = ttk.LabelFrame(self.post_tab,
                                         text="📱 Instagram login codes",
                                         padding=8)

        # queue
        self.queue_frame = self.build_queue_ui(self.post_tab, recover=True)

    def build_queue_ui(self, parent, recover=False):
        """Queue list + buttons; shared by Post and Groups tabs."""
        qf = ttk.LabelFrame(parent, text="Queue", padding=8)
        qf.pack(fill="both", expand=True, pady=(8, 0))
        fr = ttk.Frame(qf)
        fr.pack(fill="x", pady=(0, 4))
        ttk.Label(fr, text="Show:").pack(side="left")
        if not hasattr(self, "queue_filter_var"):
            self.queue_filter_var = tk.StringVar(value="All accounts")
        qfilter = ttk.Combobox(fr, textvariable=self.queue_filter_var,
                               state="readonly", width=20)
        qfilter.pack(side="left", padx=(6, 0))
        qfilter.bind("<<ComboboxSelected>>",
                     lambda e: self.refresh_queue())
        self.queue_filters.append(qfilter)
        if not hasattr(self, "queue_count_var"):
            self.queue_count_var = tk.StringVar(value="")
        ttk.Label(fr, textvariable=self.queue_count_var,
                  font=("Segoe UI", 9, "bold")).pack(side="right", padx=(12, 0))
        cols = ("sel", "account", "file", "when", "status")
        qwrap = ttk.Frame(qf)
        qwrap.pack(fill="both", expand=True)
        tree = ttk.Treeview(qwrap, columns=cols, show="headings", height=8,
                            selectmode="extended")
        for c, w, t in (("sel", 30, "✓"), ("account", 110, "Account"),
                        ("file", 170, "File"), ("when", 110, "When"),
                        ("status", 220, "Status")):
            tree.heading(c, text=t)
            tree.column(c, width=w,
                        anchor="center" if c == "sel" else "w")
        tree.bind("<Button-1>",
                  lambda e, tr=tree: self.toggle_queue_check(tr, e))
        qsb = ttk.Scrollbar(qwrap, orient="vertical", command=tree.yview)
        qhsb = ttk.Scrollbar(qwrap, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=qsb.set, xscrollcommand=qhsb.set)
        qsb.pack(side="right", fill="y")
        qhsb.pack(side="bottom", fill="x")
        tree.pack(side="left", fill="both", expand=True)
        self.queue_trees.append(tree)
        # Two button rows: one long row grew past the window width
        # and clipped the middle buttons (Time badlo vanished on her
        # laptop even though it existed). Row 1: posting/selection/
        # job moves, row 2: posting on/off + start posting +
        # delete/clear/schedule, so nothing can hide.
        qr = ttk.Frame(qf)
        qr.pack(fill="x", pady=(6, 0))
        ttk.Button(qr, text="🚀 Post now", command=self.post_now).pack(side="left")
        ttk.Button(qr, text="⏩ Abhi post karo",
                   command=self.post_filtered_now).pack(side="left",
                                                        padx=(6, 0))
        ttk.Button(qr, text="Retry", command=self.retry_job).pack(side="left", padx=(6, 0))
        ttk.Button(qr, text="✓ Select all",
                   command=self.select_all_queue).pack(side="left",
                                                       padx=(6, 0))
        ttk.Button(qr, text="🕐 Time badlo…",
                   command=self.retime_queue_jobs).pack(side="left",
                                                        padx=(6, 0))
        ttk.Button(qr, text="🔄 Account badlo…",
                   command=self.move_account_jobs).pack(side="left",
                                                        padx=(6, 0))
        qr2 = ttk.Frame(qf)
        qr2.pack(fill="x", pady=(4, 0))
        if not hasattr(self, "_sched_toggle_btns"):
            self._sched_toggle_btns = []
        _sched_btn = ttk.Button(qr2, text="▶️ Posting shuru karo",
                                command=self._toggle_scheduler)
        _sched_btn.pack(side="left")
        self._sched_toggle_btns.append(_sched_btn)
        ttk.Button(qr2, text="▶️ Start posting…",
                   command=self.start_all_posting).pack(side="left",
                                                        padx=(6, 0))
        ttk.Button(qr2, text="🛑 Stop / Delete",
                   command=self.remove_job).pack(side="left",
                                                 padx=(6, 0))
        _clear_btn = ttk.Button(qr2, text="🗑 Clear",
                                command=self.clear_all_queue)
        _clear_btn.pack(side="left", padx=(6, 0))
        if recover:
            # Main queue only (this builder also makes the Groups tab
            # queue): its label follows the filter, so the button
            # itself shows which account it will clear.
            self.clear_all_btn = _clear_btn
        ttk.Button(qr2, text="📊 Accounts ka schedule",
                   command=self.show_account_schedule).pack(side="left",
                                                           padx=(6, 0))
        if recover:
            ttk.Button(qr2, text="♻️ Recover lost posts",
                       command=self.recover_dialog).pack(side="left",
                                                         padx=(6, 0))
        ttk.Button(qr2, text="Clear finished",
                   command=self.clear_finished).pack(side="right")
        # Posting gap, on the main queue only (this builder also makes
        # the Groups tab queue, where a second control would fight the
        # first over one setting). Posts in one batch go one by one
        # with this many minutes between them, so accounts sharing a
        # post time no longer fire as a burst. Saved to a file; the
        # batch reads the file, so it works even before the window
        # opens.
        if recover:
            gapf = ttk.Frame(qr)
            gapf.pack(side="right", padx=(0, 6))
            ttk.Label(gapf, text="⏳ Posts ke darmiyan waqfa:").pack(
                side="left")
            self.post_gap_var = tk.StringVar(
                value=str(app.load_post_gap_minutes()))
            self.post_gap_spin = ttk.Spinbox(
                gapf, from_=0, to=60, width=4,
                textvariable=self.post_gap_var,
                command=self._save_post_gap)
            self.post_gap_spin.pack(side="left", padx=(4, 0))
            ttk.Label(gapf, text="minute").pack(side="left", padx=(2, 0))
            self.post_gap_spin.bind("<FocusOut>",
                                    lambda e: self._save_post_gap())
            self.post_gap_spin.bind("<Return>",
                                    lambda e: self._save_post_gap())
        return qf

    def build_schedule_tab(self):
        """📅 Schedule tab: the whole scheduled series at a glance —
        each waiting post in posting order with its day/date, cover
        picture and caption, so a series can be checked properly
        (Day 1's video really has Day 1's caption and cover)."""
        ttk.Label(
            self.sched_tab,
            text=("Upar New post form se post schedule karein — neeche "
                  "list mein us ki cover aur caption ke saath check "
                  "karein.\n"
                  "Schedule ki sari posts — tartib se, pehle post hone "
                  "wali sab se upar.\n"
                  "Har row mein: din/tareekh, cover ki photo, video ka "
                  "naam aur us ki caption.\n"
                  "Har row ko tick karke select karein — phir Pause, "
                  "Resume ya Stop dabayein. ✏️ se kisi post ki caption "
                  "aur cover badal sakti hain.\n"
                  "Video ke naam ya cover ke naam pe click karein to "
                  "preview window khulegi — us mein video/cover bari "
                  "nazar aayegi aur caption ya cover badal sakti hain.\n"
                  "Sirf waiting aur paused posts dikhti hain.\n"
                  "Is tab mein sirf zip se lagi posts dikhti hain — "
                  "baqi posts (bulk, single, carousel) Post tab ke "
                  "Queue mein hain."),
            font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 6))
        top = ttk.Frame(self.sched_tab)
        top.pack(fill="x", pady=(0, 6))
        self.sched_count_var = tk.StringVar(value="")
        ttk.Label(top, textvariable=self.sched_count_var,
                  font=("Segoe UI", 10, "bold")).pack(side="left")
        ttk.Label(top, text="Show:").pack(side="left", padx=(16, 4))
        self.sched_filter_var = tk.StringVar(value="All accounts")
        self.sched_filter = ttk.Combobox(top,
                                         textvariable=self.sched_filter_var,
                                         state="readonly", width=22)
        self.sched_filter["values"] = (["All accounts"]
                                       + self.all_account_labels())
        self.sched_filter.pack(side="left")
        self.sched_filter.bind("<<ComboboxSelected>>",
                               lambda _e: self.refresh_schedule_tab())
        # Picking an account in the New post form also filters the
        # list below to that account's posts.
        self.post_account.bind("<<ComboboxSelected>>",
                               self._sched_sync_filter, add="+")
        ttk.Button(top, text="🔄 Refresh",
                   command=self.refresh_schedule_tab).pack(side="right")
        ttk.Button(top, text="♻️ Recover lost posts",
                   command=self.recover_dialog).pack(side="right",
                                                    padx=(0, 8))
        # Selection + pause/resume/stop bar
        act = ttk.Frame(self.sched_tab)
        act.pack(fill="x", pady=(0, 6))
        self._sched_rows = []
        self._sched_sel_all = tk.BooleanVar(value=False)

        def _sel_all():
            val = self._sched_sel_all.get()
            for r in self._sched_rows:
                r["var"].set(val)
        ttk.Checkbutton(act, text="Select all",
                        variable=self._sched_sel_all,
                        command=_sel_all).pack(side="left")
        ttk.Button(act, text="⏸ Pause",
                   command=self.sched_pause).pack(side="left", padx=(8, 0))
        ttk.Button(act, text="▶ Resume",
                   command=self.sched_resume).pack(side="left", padx=(4, 0))
        ttk.Button(act, text="🛑 Stop / Delete",
                   command=self.sched_stop).pack(side="left", padx=(4, 0))
        self.sched_rows_frame = ttk.Frame(self.sched_tab)
        self.sched_rows_frame.pack(fill="both", expand=True)
        self._sched_imgs = []
        self.refresh_schedule_tab()

        def _on_tab_changed(e):
            try:
                if self.notebook.select() == self.sched_tab_id:
                    self.refresh_schedule_tab()
            except Exception:
                pass
        self.notebook.bind("<<NotebookTabChanged>>", _on_tab_changed)

    @staticmethod
    def _is_zip_post(job):
        """Does this job belong on the Schedule tab? Only zip posts.

        Jobs recorded before kinds existed have no "kind": bulk and
        download-from-link jobs carry a source URL and old carousels
        carry their "Carousel (N photos)" name, so those hide;
        everything else is a zip/single/recover post and still shows,
        so her existing series never disappears from this tab.
        """
        k = job.get("kind")
        if k:
            return k == "zip"
        if job.get("source"):
            return False
        if (job.get("filename") or "").startswith("Carousel ("):
            return False
        return True

    def refresh_schedule_tab(self):
        if not hasattr(self, "sched_rows_frame"):
            return
        for w in self.sched_rows_frame.winfo_children():
            w.destroy()
        self._sched_imgs = []
        self._sched_rows = []
        if hasattr(self, "_sched_sel_all"):
            self._sched_sel_all.set(False)
        # Waiting + paused both show; the scheduler only picks up
        # "waiting", so a paused post never posts on its own.
        # And only zip posts show here — the rest live in the Queue.
        # The Show filter (or the New post form's account) narrows the
        # list to one account; "All accounts" shows everything.
        filt = self.sched_filter_var.get().strip() \
            if hasattr(self, "sched_filter_var") else "All accounts"

        def _disp(j):
            acc = j.get("account", "")
            return ("📘 " + acc) if j.get("via") == "meta" else acc

        shown = [j for j in app.QUEUE
                 if j.get("status") in ("waiting", "paused")
                 and self._is_zip_post(j)
                 and (not filt or filt == "All accounts"
                      or _disp(j) == filt)]
        sched = [j for j in shown if j.get("scheduled_at")]
        now = [j for j in shown if not j.get("scheduled_at")]
        sched.sort(key=lambda j: j.get("scheduled_at") or "")
        ordered = sched + now
        n_paused = sum(1 for j in ordered if j.get("status") == "paused")
        self.sched_count_var.set(
            f"📅 {len(ordered)} posts schedule hain"
            + (f" ({n_paused} paused)" if n_paused else "")
            + (f" ({len(now)} foran wali)" if now else "")
            + (f" — sirf {filt}" if filt and filt != "All accounts"
               else ""))
        if not ordered:
            msg = ("Koi schedule post nahi hai — zip se queue "
                   "karein to wo yahan nazar ayengi.")
            if filt and filt != "All accounts":
                msg = (f"Is account ({filt}) ki koi schedule post "
                       "nahi hai.")
            ttk.Label(self.sched_rows_frame, text=msg,
                      font=("Segoe UI", 10)).pack(anchor="w")
            return
        for i, job in enumerate(ordered, 1):
            row = ttk.Frame(self.sched_rows_frame, padding=(0, 4))
            row.pack(fill="x")
            v = tk.BooleanVar(value=False)
            ttk.Checkbutton(row, variable=v).pack(side="left")
            self._sched_rows.append({"job": job, "var": v})
            ttk.Label(row, text=f"{i}.", font=("Segoe UI", 11, "bold"),
                      width=4, anchor="nw").pack(side="left")
            when = job.get("scheduled_at") or ""
            try:
                dt = datetime.strptime(when, "%Y-%m-%dT%H:%M")
                when_s = dt.strftime("%d %b\n%I:%M %p")
            except Exception:
                when_s = "Post now\n(foran)"
            if job.get("status") == "paused":
                when_s += "\n⏸ Paused"
            ttk.Label(row, text=when_s, font=("Segoe UI", 9),
                      width=12, anchor="nw").pack(side="left", padx=(0, 8))
            # Cover NAME, not the picture: the row stays compact.
            # Click the cover name or the video name for the preview
            # window, where the picture/video shows large and the
            # caption or cover can be changed.
            cov_path = job.get("cover") or ""
            cov_name = Path(cov_path).name if cov_path else "—"
            clbl = ttk.Label(
                row, text=("🖼 " + cov_name[:18]) if cov_path else "—",
                font=("Segoe UI", 9), width=20, anchor="nw",
                cursor="hand2")
            clbl.pack(side="left", padx=(0, 8))
            clbl.bind("<Button-1>",
                      lambda e, j=job: self.sched_edit(j))
            flbl = ttk.Label(row, text=f"{job.get('filename', '')}\n"
                                       f"{job.get('account', '')}",
                             font=("Segoe UI", 9), width=22,
                             anchor="nw", cursor="hand2")
            flbl.pack(side="left", padx=(0, 8))
            flbl.bind("<Button-1>",
                      lambda e, j=job: self.sched_edit(j))
            ttk.Label(row, text=job.get("caption", ""),
                      font=("Segoe UI", 9), wraplength=360,
                      anchor="nw", justify="left").pack(side="left",
                                                        fill="x",
                                                        expand=True)
            ttk.Button(row, text="✏️",
                       width=3,
                       command=lambda j=job: self.sched_edit(j)).pack(
                           side="right", padx=(8, 0))
            ttk.Separator(self.sched_rows_frame,
                          orient="horizontal").pack(fill="x", pady=2)

    def _sched_selected_jobs(self):
        return [r["job"] for r in getattr(self, "_sched_rows", [])
                if r["var"].get()]

    def sched_pause(self):
        jobs = [j for j in self._sched_selected_jobs()
                if j.get("status") == "waiting"]
        if not jobs:
            messagebox.showinfo(
                "Pause",
                "Pehle waiting posts ko tick karein.",
                parent=self.root)
            return
        for j in jobs:
            j["status"] = "paused"
        app.save_queue()
        self.refresh_queue()
        self.refresh_schedule_tab()
        self.status(f"{len(jobs)} post(s) pause kar di hain. ⏸")

    def sched_resume(self):
        jobs = [j for j in self._sched_selected_jobs()
                if j.get("status") == "paused"]
        if not jobs:
            messagebox.showinfo(
                "Resume",
                "Pehle paused posts ko tick karein.",
                parent=self.root)
            return
        for j in jobs:
            j["status"] = "waiting"
        app.save_queue()
        self.refresh_queue()
        self.refresh_schedule_tab()
        self.status(f"{len(jobs)} post(s) dobara schedule ho gayi. ▶")

    def sched_stop(self):
        jobs = self._sched_selected_jobs()
        if not jobs:
            messagebox.showinfo(
                "Stop / Delete",
                "Pehle posts ko tick karein, phir ye button dabayein.",
                parent=self.root)
            return
        if not messagebox.askyesno(
                "Stop / Delete",
                f"{len(jobs)} posts schedule se delete kar dun?",
                parent=self.root):
            return
        ids = {j["id"] for j in jobs}
        with app.QUEUE_LOCK:
            app.QUEUE[:] = [j for j in app.QUEUE
                            if j.get("id") not in ids]
        app.save_queue()
        self.refresh_queue()
        self.refresh_schedule_tab()
        self.status(f"Stopped & deleted {len(jobs)} post(s). 🛑")

    def sched_edit(self, job):
        """Preview window for a scheduled post: the cover (or the
        photo itself) shows large, a video can be played, and the
        caption/cover can be changed in place and saved."""
        top = tk.Toplevel(self.root)
        top.title("Preview — " + job.get("filename", ""))
        top.geometry("520x400")
        top.transient(self.root)
        top.grab_set()
        ttk.Label(top, text=job.get("filename", ""),
                  font=("Segoe UI", 10, "bold")).pack(
                      padx=12, pady=(12, 4), anchor="w")
        # Preview on top: the cover, or the photo itself for a photo
        # post; a video gets a play button (system player).
        prev_path = job.get("cover") or ""
        if not prev_path or not Path(prev_path).is_file():
            fp0 = job.get("filepath") or ""
            if Path(fp0).suffix.lower() in app.IMAGE_EXTS \
                    and Path(fp0).is_file():
                prev_path = fp0
            else:
                prev_path = ""
        if prev_path:
            try:
                from PIL import Image, ImageTk
                im = Image.open(prev_path)
                im.thumbnail((460, 260))
                tkimg = ImageTk.PhotoImage(im)
                top._preview_img = tkimg  # keep a reference
                ttk.Label(top, image=tkimg).pack(padx=12, pady=(4, 0))
                top.geometry("520x640")
            except Exception:
                pass
        fp = job.get("filepath") or ""
        if Path(fp).suffix.lower() in app.VIDEO_EXTS:
            def _play(p=fp):
                try:
                    import os as _os
                    _os.startfile(p)
                except Exception as e:
                    messagebox.showwarning(
                        "Video", f"Video nahi khul saki:\n{e}",
                        parent=top)
            ttk.Button(top, text="▶ Video chalao",
                       command=_play).pack(padx=12, pady=(6, 0),
                                           anchor="w")
            if not prev_path:
                ttk.Label(top, text="Is video ki koi cover nahi lagi.",
                          font=("Segoe UI", 9)).pack(padx=12, anchor="w")
                top.geometry("520x470")
        # Change the video/photo itself (a carousel has many files, so
        # it stays caption-only). The new file is copied into uploads
        # on Save, exactly like queueing — the old file is left alone.
        vid = {"path": job.get("filepath", "")}
        _is_vid = Path(fp).suffix.lower() in app.VIDEO_EXTS
        _is_pic = Path(fp).suffix.lower() in app.IMAGE_EXTS
        if not job.get("files") and (_is_vid or _is_pic):
            vrow = ttk.Frame(top)
            vrow.pack(fill="x", padx=12, pady=(6, 0))
            vid_lbl = ttk.Label(vrow, text="", font=("Segoe UI", 9))
            vid_lbl.pack(side="left")

            def _vid_text():
                p = vid["path"]
                vid_lbl.config(
                    text=("Video: " if _is_vid else "Photo: ")
                    + (Path(p).name if p else "—"))
            _vid_text()

            def _pick_video():
                f = filedialog.askopenfilename(
                    parent=top,
                    title="Video chunein" if _is_vid else "Photo chunein",
                    filetypes=[(("Videos", "*.mp4 *.mov")
                                if _is_vid else
                                ("Images",
                                 "*.jpg *.jpeg *.png *.webp")),
                               ("All files", "*.*")])
                if not f:
                    return
                ok_exts = app.VIDEO_EXTS if _is_vid else app.IMAGE_EXTS
                if Path(f).suffix.lower() not in ok_exts:
                    messagebox.showwarning(
                        "File",
                        "Ye file is post ke liye sahi nahi hai.",
                        parent=top)
                    return
                vid["path"] = f
                _vid_text()
            ttk.Button(vrow,
                       text="🎬 Video badlo…" if _is_vid
                       else "🖼 Photo badlo…",
                       command=_pick_video).pack(side="left", padx=(6, 0))
        ttk.Label(top, text="Caption:").pack(padx=12, anchor="w")
        cap = tk.Text(top, height=6, font=("Segoe UI", 10))
        cap.pack(fill="x", padx=12)
        cap.insert("1.0", job.get("caption", ""))
        cov = {"path": job.get("cover", "")}
        cov_lbl = ttk.Label(top, text="", font=("Segoe UI", 9))
        cov_lbl.pack(padx=12, anchor="w", pady=(8, 0))

        def _cov_text():
            p = cov["path"]
            cov_lbl.config(
                text="Cover: " + (Path(p).name if p else "koi cover nahi"))
        _cov_text()
        brow = ttk.Frame(top)
        if job.get("files"):
            # A carousel has no cover of its own — caption only.
            ttk.Label(top, text="🎠 Carousel — is pe cover nahi lagta.",
                      font=("Segoe UI", 9)).pack(padx=12, anchor="w",
                                                pady=(8, 0))
        else:
            brow.pack(fill="x", padx=12, pady=(4, 0))

        def _pick():
            f = filedialog.askopenfilename(
                parent=top, title="Cover photo chunein",
                filetypes=[("Images", "*.jpg *.jpeg *.png *.webp"),
                           ("Zip files", "*.zip"),
                           ("All files", "*.*")])
            if not f:
                return
            if Path(f).suffix.lower() == ".zip":
                img = app.first_image_in_zip(f)
                if not img:
                    messagebox.showwarning(
                        "Cover", "Is zip file mein koi photo nahi mili.",
                        parent=top)
                    return
                f = img
            cov["path"] = f
            _cov_text()
        ttk.Button(brow, text="Cover photo…",
                   command=_pick).pack(side="left")

        def _clear():
            cov["path"] = ""
            _cov_text()
        ttk.Button(brow, text="Cover hatayein",
                   command=_clear).pack(side="left", padx=(6, 0))

        def _save():
            # New video/photo picked? Copy it into uploads and point
            # the job at it (same as queueing). A vanished pick or a
            # failed copy never stores a dead path — old file stays.
            new_vid = vid["path"]
            if new_vid and new_vid != job.get("filepath", ""):
                vsrc = Path(new_vid)
                if vsrc.is_file():
                    vsafe = re.sub(r"[^a-zA-Z0-9_.-]", "_", vsrc.name)
                    vdest = app.UPLOADS / (f"{int(time.time())}_{vsafe}")
                    try:
                        shutil.copy(vsrc, vdest)
                        job["filepath"] = str(vdest)
                        job["filename"] = vsrc.name
                    except Exception:
                        pass
            new_cov = cov["path"]
            if new_cov and new_cov != job.get("cover", ""):
                csrc = Path(new_cov)
                if csrc.is_file():
                    csafe = re.sub(r"[^a-zA-Z0-9_.-]", "_", csrc.name)
                    cdest = app.UPLOADS / (f"{int(time.time())}_cover_"
                                           f"{csafe}")
                    try:
                        shutil.copy(csrc, cdest)
                        new_cov = str(cdest)
                    except Exception:
                        new_cov = job.get("cover", "")
                else:
                    # Picked file vanished before Save — never store
                    # a dead path; keep the old cover instead.
                    new_cov = job.get("cover", "")
            job["caption"] = cap.get("1.0", "end").strip()
            job["cover"] = new_cov
            app.save_queue()
            try:
                self.refresh_queue()
            except Exception:
                pass
            top.destroy()
            self.refresh_schedule_tab()
            self.status("Post update ho gaya. ✅")
        brow2 = ttk.Frame(top)
        brow2.pack(fill="x", padx=12, pady=(12, 0))
        ttk.Button(brow2, text="Save", style="Accent.TButton",
                   command=_save).pack(side="right")
        ttk.Button(brow2, text="Cancel",
                   command=top.destroy).pack(side="right", padx=(0, 8))

    def build_groups_tab(self):
        self.gchosen_file = None
        # my groups: pick a group -> see which accounts are in it
        mg = ttk.LabelFrame(self.groups_tab, text="My groups", padding=8)
        mg.pack(fill="x")
        r = ttk.Frame(mg)
        r.pack(fill="x")
        ttk.Label(r, text="Group:").pack(side="left")
        self.grp_view_combo = ttk.Combobox(r, state="readonly", width=24)
        self.grp_view_combo.pack(side="left", padx=(6, 12))
        self.grp_view_combo.bind(
            "<<ComboboxSelected>>",
            lambda e: self.refresh_group_members())
        ttk.Button(r, text="+ New group",
                   command=self.new_group).pack(side="left")
        ttk.Button(r, text="Edit",
                   command=self.edit_group).pack(side="left", padx=(6, 0))
        ttk.Button(r, text="Delete",
                   command=self.delete_group).pack(side="left", padx=(6, 0))
        ttk.Label(mg, text="Accounts in this group:").pack(anchor="w",
                                                           pady=(8, 0))
        mlf = ttk.Frame(mg)
        mlf.pack(fill="x")
        self.grp_members_list = tk.Listbox(mlf, height=5,
                                           font=("Segoe UI", 10))
        self.grp_members_list.pack(side="left", fill="x", expand=True)
        msb = ttk.Scrollbar(mlf, orient="vertical",
                            command=self.grp_members_list.yview)
        msb.pack(side="right", fill="y")
        self.grp_members_list.configure(yscrollcommand=msb.set)
        self.grp_members_list.bind("<<ListboxSelect>>",
                                   self.on_group_member_select)
        mr = ttk.Frame(mg)
        mr.pack(fill="x", pady=(6, 0))
        ttk.Button(mr, text="➕ Add accounts",
                   command=self.add_group_members).pack(side="left")
        ttk.Button(mr, text="➖ Remove selected",
                   command=self.remove_group_member).pack(side="left",
                                                         padx=(6, 0))

        # post to group: pick group -> pick account -> post/schedule
        pg = ttk.LabelFrame(self.groups_tab, text="Post to group", padding=8)
        pg.pack(fill="x", pady=(8, 0))
        r1 = ttk.Frame(pg)
        r1.pack(fill="x")
        ttk.Label(r1, text="Group:").pack(side="left")
        self.gpost_group = ttk.Combobox(r1, state="readonly", width=20)
        self.gpost_group.pack(side="left", padx=(6, 12))
        self.gpost_group.bind(
            "<<ComboboxSelected>>",
            lambda e: self.refresh_group_post_accounts())
        ttk.Label(r1, text="Account:").pack(side="left")
        self.gpost_account = ttk.Combobox(r1, state="readonly", width=20)
        self.gpost_account.pack(side="left", padx=(6, 0))
        r2 = ttk.Frame(pg)
        r2.pack(fill="x", pady=(6, 0))
        ttk.Button(r2, text="Choose photo/video…",
                   command=self.gchoose_file).pack(side="left")
        self.gfile_lbl = ttk.Label(r2, text="no file chosen",
                                   font=("Segoe UI", 9, "italic"))
        self.gfile_lbl.pack(side="left", padx=(8, 0))
        ttk.Label(pg, text="Caption:").pack(anchor="w", pady=(6, 0))
        self.gcaption_text = tk.Text(pg, height=3, font=("Segoe UI", 10))
        self.gcaption_text.pack(fill="x")
        r3 = ttk.Frame(pg)
        r3.pack(fill="x", pady=(6, 0))
        self.gwhen_var = tk.StringVar(value="now")
        ttk.Radiobutton(r3, text="Post now", variable=self.gwhen_var,
                        value="now").pack(side="left")
        ttk.Radiobutton(r3, text="Schedule:", variable=self.gwhen_var,
                        value="later").pack(side="left", padx=(12, 4))
        self.gsched_entry = ttk.Entry(r3, width=18)
        self.gsched_entry.pack(side="left")
        ttk.Button(r3, text="📅", width=3,
                   command=lambda: DateTimePicker(self.root, self.gsched_entry,
                                                  self.theme)).pack(
                                                      side="left", padx=(4, 0))
        ttk.Label(r3, text="YYYY-MM-DD HH:MM AM",
                  font=("Segoe UI", 8)).pack(side="left", padx=(6, 0))
        ttk.Button(r3, text="Add to queue", style="Accent.TButton",
                   command=self.add_group_post).pack(side="right")
        ttk.Button(r3, text="📢 Post to ALL in group", style="Accent.TButton",
                   command=self.add_group_post_all).pack(side="right",
                                                         padx=(0, 8))

        # queue (shared with Post tab)
        self.build_queue_ui(self.groups_tab)

    def build_link_tab(self):
        lf = ttk.LabelFrame(self.link_tab, text="Download from a link",
                            padding=8)
        lf.pack(fill="x")
        ttk.Label(lf, text="Post link:").pack(anchor="w")
        lr = ttk.Frame(lf)
        lr.pack(fill="x")
        self.link_entry = ttk.Entry(lr, font=("Segoe UI", 10))
        self.link_entry.pack(side="left", fill="x", expand=True)
        self.link_entry.bind("<KeyRelease>", self.detect_platform)
        self.platform_var = tk.StringVar(value="")
        ttk.Label(lr, textvariable=self.platform_var,
                  font=("Segoe UI", 10, "bold")).pack(side="left", padx=(8, 0))
        # group + account for single links
        lgr = ttk.Frame(lf)
        lgr.pack(fill="x", pady=(6, 0))
        ttk.Label(lgr, text="Group:").pack(side="left")
        self.link_group = ttk.Combobox(lgr, state="readonly", width=18)
        self.link_group.pack(side="left", padx=(6, 0))
        self.link_group.bind("<<ComboboxSelected>>",
                             lambda e: self.refresh_link_accounts())
        ttk.Label(lgr, text="Account:").pack(side="left", padx=(12, 0))
        self.link_account = ttk.Combobox(lgr, state="readonly", width=20)
        self.link_account.pack(side="left", padx=(6, 0))
        ttk.Button(lgr, text="+ New",
                   command=self.link_new_group).pack(side="left", padx=(6, 0))
        ttk.Button(lgr, text="Edit",
                   command=self.link_edit_group).pack(side="left", padx=(4, 0))
        ttk.Button(lgr, text="Delete",
                   command=self.link_delete_group).pack(side="left",
                                                        padx=(4, 0))

        ttk.Label(lf, text="Caption:").pack(anchor="w", pady=(6, 0))
        self.link_caption = tk.Text(lf, height=2, font=("Segoe UI", 10))
        self.link_caption.pack(fill="x")

        self.link_mode = tk.StringVar(value="now")
        mr = ttk.Frame(lf)
        mr.pack(fill="x", pady=(6, 0))
        ttk.Radiobutton(mr, text="Download & post now",
                        variable=self.link_mode, value="now").pack(anchor="w")
        fr1 = ttk.Frame(mr)
        fr1.pack(fill="x")
        ttk.Radiobutton(fr1, text="Download & schedule once:",
                        variable=self.link_mode, value="once").pack(side="left")
        self.link_sched = ttk.Entry(fr1, width=18)
        self.link_sched.pack(side="left", padx=(6, 0))
        ttk.Button(fr1, text="📅", width=3,
                   command=lambda: DateTimePicker(self.root, self.link_sched,
                                                  self.theme)).pack(side="left", padx=(4, 0))
        ttk.Label(fr1, text="YYYY-MM-DD HH:MM AM",
                  font=("Segoe UI", 8)).pack(side="left", padx=(6, 0))
        fr2 = ttk.Frame(mr)
        fr2.pack(fill="x")
        ttk.Radiobutton(fr2, text="Download & post daily at:",
                        variable=self.link_mode, value="daily").pack(side="left")
        self.link_daily = ttk.Entry(fr2, width=8)
        self.link_daily.insert(0, "10:00 AM")
        self.link_daily.pack(side="left", padx=(6, 0))
        ttk.Label(fr2, text="HH:MM AM/PM", font=("Segoe UI", 8)).pack(side="left")
        ttk.Button(lf, text="Add", command=self.add_link).pack(pady=(8, 0))
        ttk.Label(lf, text="Or paste many links at once (one per line):").pack(
            anchor="w", pady=(6, 0))
        self.links_text = tk.Text(lf, height=3, font=("Segoe UI", 10))
        self.links_text.pack(fill="x")
        mr2 = ttk.Frame(lf)
        mr2.pack(fill="x", pady=(6, 0))
        self.links_mode = tk.StringVar(value="now")
        ttk.Radiobutton(mr2, text="Post now", variable=self.links_mode,
                        value="now").pack(side="left")
        ttk.Radiobutton(mr2, text="Schedule from:", variable=self.links_mode,
                        value="once").pack(side="left", padx=(12, 0))
        self.links_sched = ttk.Entry(mr2, width=18)
        self.links_sched.pack(side="left", padx=(6, 0))
        ttk.Button(mr2, text="📅", width=3,
                   command=lambda: DateTimePicker(self.root, self.links_sched,
                                                  self.theme)).pack(side="left", padx=(4, 0))
        ttk.Label(mr2, text="every").pack(side="left", padx=(8, 0))
        self.links_every = ttk.Spinbox(mr2, from_=1, to=48, width=4)
        self.links_every.set(2)
        self.links_every.pack(side="left", padx=(4, 0))
        ttk.Label(mr2, text="hours").pack(side="left")
        fr2b = ttk.Frame(lf)
        fr2b.pack(fill="x")
        ttk.Radiobutton(fr2b, text="Download & post daily at:",
                        variable=self.links_mode, value="daily").pack(side="left")
        self.links_daily = ttk.Entry(fr2b, width=8)
        self.links_daily.insert(0, "10:00 AM")
        self.links_daily.pack(side="left", padx=(6, 0))
        ttk.Label(fr2b, text="HH:MM AM/PM", font=("Segoe UI", 8)).pack(side="left")
        ttk.Button(lf, text="Add all links",
                   command=self.add_links).pack(pady=(8, 0))

        bf = ttk.LabelFrame(self.link_tab,
                            text="📌 Bulk: whole Pinterest profile / board",
                            padding=8)
        bf.pack(fill="x", pady=(8, 0))
        # group + account for bulk
        bgr = ttk.Frame(bf)
        bgr.pack(fill="x")
        ttk.Label(bgr, text="Group:").pack(side="left")
        self.bulk_group = ttk.Combobox(bgr, state="readonly", width=18)
        self.bulk_group.pack(side="left", padx=(6, 0))
        self.bulk_group.bind("<<ComboboxSelected>>",
                             lambda e: self.refresh_bulk_accounts())
        ttk.Label(bgr, text="Account:").pack(side="left", padx=(12, 0))
        self.bulk_account = ttk.Combobox(bgr, state="readonly", width=20)
        self.bulk_account.pack(side="left", padx=(6, 0))
        self._bulk_link_autofilled = ""
        self._bulk_last_account = ""
        self.bulk_account.bind("<<ComboboxSelected>>",
                               lambda e: self.autofill_bulk_link(
                                   force=True))
        ttk.Button(bgr, text="+ New",
                   command=self.bulk_new_group).pack(side="left", padx=(6, 0))
        ttk.Button(bgr, text="Edit",
                   command=self.bulk_edit_group).pack(side="left", padx=(4, 0))
        ttk.Button(bgr, text="Delete",
                   command=self.bulk_delete_group).pack(side="left",
                                                        padx=(4, 0))
        br1 = ttk.Frame(bf)
        br1.pack(fill="x", pady=(6, 0))
        ttk.Label(br1, text="Profile/board link:").pack(side="left")
        self.bulk_link = ttk.Entry(br1, width=42)
        self.bulk_link.pack(side="left", padx=(6, 0), fill="x", expand=True)
        ttk.Button(br1, text="🔍 Check how many",
                   command=self.check_pinterest_count).pack(side="left")
        # Attached board, always visible: whichever account is picked,
        # its attached board link shows here — never hidden behind
        # whatever happens to be typed in the link box.
        self.bulk_attached_var = tk.StringVar(value="")
        ttk.Label(bf, textvariable=self.bulk_attached_var,
                  font=("Segoe UI", 9)).pack(anchor="w", pady=(2, 0))
        br1b = ttk.Frame(bf)
        br1b.pack(fill="x", pady=(4, 0))
        ttk.Label(br1b, text="Download only the first").pack(side="left")
        self.bulk_limit = ttk.Spinbox(br1b, from_=0, to=500, width=6)
        self.bulk_limit.set("0")
        self.bulk_limit.pack(side="left", padx=(6, 0))
        ttk.Label(br1b, text="pins (0 = all)").pack(side="left")
        ttk.Label(br1b, text="•  Pin #").pack(side="left", padx=(12, 0))
        self.bulk_start = ttk.Spinbox(br1b, from_=1, to=10000, width=6)
        self.bulk_start.set("1")
        self.bulk_start.pack(side="left", padx=(6, 0))
        ttk.Label(br1b, text="se shuru karein").pack(side="left")
        self.bulk_use_caption = tk.BooleanVar(value=True)
        ttk.Checkbutton(br1b, text="Copy pin's caption",
                        variable=self.bulk_use_caption).pack(side="left",
                                                             padx=(12, 0))
        self.bulk_save_link = tk.BooleanVar(value=True)
        ttk.Checkbutton(br1b, text="🔖 Is account ka link save rakho",
                        variable=self.bulk_save_link).pack(side="left",
                                                           padx=(12, 0))
        br2 = ttk.Frame(bf)
        br2.pack(fill="x", pady=(6, 0))
        ttk.Label(br2, text="Media:").pack(side="left")
        self.bulk_kind = ttk.Combobox(br2, state="readonly", width=12,
                                      values=["Both", "Videos only", "Photos only"])
        self.bulk_kind.set("Both")
        self.bulk_kind.pack(side="left", padx=(6, 0))
        self.bulk_mode = tk.StringVar(value="now")
        ttk.Radiobutton(br2, text="Queue all now",
                        variable=self.bulk_mode, value="now").pack(side="left", padx=(12, 0))
        ttk.Radiobutton(br2, text="Schedule from:",
                        variable=self.bulk_mode, value="schedule").pack(side="left", padx=(6, 0))
        self.bulk_sched = ttk.Entry(br2, width=16)
        self.bulk_sched.pack(side="left")
        ttk.Button(br2, text="📅", width=3,
                   command=lambda: DateTimePicker(self.root, self.bulk_sched,
                                                  self.theme)).pack(side="left", padx=(4, 0))
        ttk.Label(br2, text="every").pack(side="left", padx=(6, 0))
        self.bulk_every = tk.Spinbox(br2, from_=1, to=48, width=4,
                                     font=("Segoe UI", 10))
        self.bulk_every.pack(side="left", padx=(2, 0))
        self.bulk_every.delete(0, "end")
        self.bulk_every.insert(0, "2")
        ttk.Label(br2, text="hours").pack(side="left")
        br3 = ttk.Frame(bf)
        br3.pack(fill="x", pady=(8, 0))
        ttk.Button(br3, text="⬇ Download all pins & queue them",
                   style="Accent.TButton",
                   command=self.start_bulk).pack(side="left")
        ttk.Button(br3, text="⛔ Cancel",
                   command=self.cancel_bulk).pack(side="left", padx=(8, 0))
        ttk.Button(br3, text="📋 Purane bulk links",
                   command=self.bulk_history_dialog).pack(side="left",
                                                          padx=(8, 0))
        self.bulk_progress = ttk.Label(br3, text="", font=("Segoe UI", 9))
        self.bulk_progress.pack(side="left", padx=(10, 0))
        # One row per running bulk download (account + live progress +
        # its own stop button) — added under the buttons, above the
        # summary, so several accounts' runs can show at once.
        self.bulk_runs_frame = ttk.Frame(bf)
        self.bulk_runs_frame.pack(fill="x", pady=(4, 0))
        srow = ttk.Frame(bf)
        srow.pack(fill="x", pady=(6, 0))
        self.bulk_summary = tk.Text(srow, height=3, font=("Segoe UI", 9),
                                    wrap="word", state="disabled")
        self.bulk_summary.pack(side="left", fill="x", expand=True)
        ttk.Button(srow, text="📋 Copy",
                   command=self.copy_bulk_summary).pack(side="left",
                                                        padx=(6, 0))

        dl = ttk.LabelFrame(self.link_tab, text="Downloads", padding=8)
        dl.pack(fill="x", pady=(8, 0))
        dl_wrap = ttk.Frame(dl)
        dl_wrap.pack(fill="x")
        self.dl_tree = ttk.Treeview(dl_wrap, columns=("link", "account", "status"),
                                    show="headings", height=4)
        for c, w, t in (("link", 300, "Link"), ("account", 110, "Account"),
                        ("status", 200, "Status")):
            self.dl_tree.heading(c, text=t)
            self.dl_tree.column(c, width=w)
        dl_sb = ttk.Scrollbar(dl_wrap, orient="vertical",
                              command=self.dl_tree.yview)
        dl_hsb = ttk.Scrollbar(dl_wrap, orient="horizontal",
                               command=self.dl_tree.xview)
        self.dl_tree.configure(yscrollcommand=dl_sb.set,
                               xscrollcommand=dl_hsb.set)
        dl_sb.pack(side="right", fill="y")
        dl_hsb.pack(side="bottom", fill="x")
        self.dl_tree.pack(side="left", fill="x", expand=True)

        wl = ttk.LabelFrame(self.link_tab, text="Daily reposts", padding=8)
        wl.pack(fill="both", expand=True, pady=(8, 0))
        w_wrap = ttk.Frame(wl)
        w_wrap.pack(fill="both", expand=True)
        self.watch_tree = ttk.Treeview(w_wrap, columns=("link", "account", "time",
                                                   "status"),
                                       show="headings", height=4)
        for c, w, t in (("link", 220, "Link"), ("account", 100, "Account"),
                        ("time", 70, "Daily at"), ("status", 220, "Status")):
            self.watch_tree.heading(c, text=t)
            self.watch_tree.column(c, width=w)
        w_sb = ttk.Scrollbar(w_wrap, orient="vertical",
                             command=self.watch_tree.yview)
        w_hsb = ttk.Scrollbar(w_wrap, orient="horizontal",
                              command=self.watch_tree.xview)
        self.watch_tree.configure(yscrollcommand=w_sb.set,
                                  xscrollcommand=w_hsb.set)
        w_sb.pack(side="right", fill="y")
        w_hsb.pack(side="bottom", fill="x")
        self.watch_tree.pack(side="left", fill="both", expand=True)
        ttk.Button(wl, text="Remove selected",
                   command=self.remove_watch).pack(pady=(6, 0))

    def build_hist_tab(self):
        hwrap = ttk.Frame(self.hist_tab)
        hwrap.pack(fill="both", expand=True)
        self.hist_list = tk.Listbox(hwrap, font=("Segoe UI", 10))
        hsb = ttk.Scrollbar(hwrap, orient="vertical",
                            command=self.hist_list.yview)
        hhsb = ttk.Scrollbar(hwrap, orient="horizontal",
                             command=self.hist_list.xview)
        self.hist_list.configure(yscrollcommand=hsb.set,
                                 xscrollcommand=hhsb.set)
        hsb.pack(side="right", fill="y")
        hhsb.pack(side="bottom", fill="x")
        self.hist_list.pack(side="left", fill="both", expand=True)
        # ---- posted-posts manager: see posted posts, delete the ones
        # she ticks — from Instagram too, one by one or all at once.
        # (Deliberately NOT refreshed by the 2.5s loop: that would
        # clear her ticks while she is choosing.)
        mgr = ttk.Frame(self.hist_tab)
        mgr.pack(fill="x", pady=(8, 0))
        ttk.Label(mgr, text="Posted posts — dekh kar delete karein",
                  font=(self.font_name, 11, "bold")).pack(anchor="w")
        ttk.Label(mgr, text="Har button sirf apni kisam delete karta "
                            "hai — video, photo, carousel ya story, "
                            "alag alag. Delete wapas nahi aayegi; "
                            "ghalti se shuru ho jaye to ⏹ Stop dabayein.",
                  font=(self.font_name, 9)).pack(anchor="w")
        filt = ttk.Frame(mgr)
        filt.pack(fill="x", pady=(4, 0))
        ttk.Label(filt, text="Account:",
                  font=(self.font_name, 10)).pack(side="left")
        self.posted_acct = ttk.Combobox(filt, state="readonly", width=28)
        self.posted_acct.pack(side="left", padx=(6, 0))
        self.posted_acct.bind("<<ComboboxSelected>>",
                              lambda e: self.refresh_posted_manager())
        # Type filter, same idea as Account: Story chunein to sirf
        # stories nazar aayengi, Carousel chunein to sirf carousels —
        # taake list mein dhoondhna na pare ke kaun si kya hai.
        ttk.Label(filt, text="Type:",
                  font=(self.font_name, 10)).pack(side="left",
                                                  padx=(12, 0))
        self.posted_type = ttk.Combobox(
            filt, state="readonly", width=14,
            values=["Sab", "🎬 Video", "🖼 Photo", "🎠 Carousel",
                    "📱 Story"])
        self.posted_type.set("Sab")
        self.posted_type.pack(side="left", padx=(6, 0))
        self.posted_type.bind("<<ComboboxSelected>>",
                              lambda e: self.refresh_posted_manager())
        bar = ttk.Frame(mgr)
        bar.pack(fill="x", pady=(4, 2))
        ttk.Button(bar, text="Select all",
                   command=lambda: self._posted_set_all(True)).pack(
                       side="left")
        ttk.Button(bar, text="Clear",
                   command=lambda: self._posted_set_all(False)).pack(
                       side="left", padx=(6, 0))
        ttk.Button(bar, text="🔄 Refresh list",
                   command=self.refresh_posted_manager).pack(
                       side="left", padx=(6, 0))
        # Four separate delete buttons, one per kind — a video button
        # can never delete a photo, and Story delete never touches
        # the post itself (only its recorded story). Packed
        # right-to-left so they read Video, Photo, Carousel, Story,
        # Stop. Stop is enabled only while a delete is running.
        self.stop_btn = ttk.Button(bar, text="⏹ Stop",
                                   command=self._stop_delete,
                                   state="disabled")
        self.stop_btn.pack(side="right")
        self.del_btns = {}
        for text, kind in [("📱 Story delete", "story"),
                           ("🎠 Carousel delete", "carousel"),
                           ("🖼 Photo delete", "photo"),
                           ("🗑 Video delete", "video")]:
            b = ttk.Button(bar, text=text,
                           command=lambda k=kind:
                           self.delete_typed_posts(k))
            b.pack(side="right", padx=(6, 0))
            self.del_btns[kind] = b
        cbox = ttk.Frame(mgr)
        cbox.pack(fill="x", pady=(2, 0))
        canvas = tk.Canvas(cbox, height=170, highlightthickness=0)
        vsb = ttk.Scrollbar(cbox, orient="vertical",
                            command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="x", expand=True)
        self.posted_box = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=self.posted_box, anchor="nw")
        self.posted_box.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        self.posted_rows = []  # (entry, BooleanVar)
        self._delete_results = None
        self._delete_running = False
        self._delete_progress = None  # (done, total, filename)
        self._delete_kind = "video"
        self._delete_total = 0
        self._delete_stop = None  # threading.Event, set by ⏹ Stop
        # Live progress line UNDER the list, so a long delete never
        # looks stuck — she can see it moving, post by post.
        self.posted_prog = ttk.Label(mgr, text="",
                                     font=(self.font_name, 10, "bold"))
        self.posted_prog.pack(anchor="w", pady=(4, 0))
        self.refresh_posted_manager()

    def refresh_posted_manager(self):
        for w in self.posted_box.winfo_children():
            w.destroy()
        self.posted_rows = []
        entries = app.posted_entries()
        stories = app.load_story_posts()
        # Account filter: only accounts with posted posts are offered.
        # A selection survives refreshes (and deletes) while that
        # account still has posts; otherwise it falls back to all.
        accts = sorted({e["account"] for e in entries})
        prev = self.posted_acct.get()
        self.posted_acct["values"] = ["All accounts"] + accts
        if prev in (["All accounts"] + accts):
            self.posted_acct.set(prev)
        else:
            self.posted_acct.set("All accounts")
        chosen_acct = self.posted_acct.get()
        if chosen_acct and chosen_acct != "All accounts":
            entries = [e for e in entries if e["account"] == chosen_acct]
        # Type filter, composed with the account filter. Story means
        # "has a recorded story", whatever the post kind; the other
        # kinds follow _entry_kind, the same rule the delete buttons
        # use, so the filter and the buttons never disagree.
        chosen_type = self.posted_type.get()
        if chosen_type == "🎬 Video":
            entries = [e for e in entries
                       if self._entry_kind(e) == "video"]
        elif chosen_type == "🖼 Photo":
            entries = [e for e in entries
                       if self._entry_kind(e) == "photo"]
        elif chosen_type == "🎠 Carousel":
            entries = [e for e in entries
                       if self._entry_kind(e) == "carousel"]
        elif chosen_type == "📱 Story":
            entries = [e for e in entries if e["link"] in stories]
        if not entries:
            if (chosen_acct not in ("", "All accounts")
                    and chosen_type != "Sab"):
                msg = (f"@{chosen_acct} mein {chosen_type} ki koi "
                       "post nahi hai.")
            elif chosen_type != "Sab":
                msg = f"{chosen_type} ki koi post nahi hai."
            elif chosen_acct not in ("", "All accounts"):
                msg = (f"Is account (@{chosen_acct}) ki koi posted post "
                       "History mein nahi hai.")
            else:
                msg = "Abhi koi posted post History mein nahi hai."
            ttk.Label(self.posted_box, text=msg,
                      font=(self.font_name, 10)).pack(anchor="w")
            return
        for e in entries:
            row = ttk.Frame(self.posted_box)
            row.pack(fill="x", pady=1)
            v = tk.BooleanVar(value=False)
            ttk.Checkbutton(row, variable=v).pack(side="left")
            # Type icon FIRST and badges right after the filename, so
            # a long caption can never push them off the visible row
            # (the old layout put badges after the caption, where a
            # 95-char cut could hide them entirely).
            icon = {"video": "🎬", "photo": "🖼",
                    "carousel": "🎠"}.get(self._entry_kind(e), "📄")
            txt = (f"{icon} {e['date']} | @{e['account']} | "
                   f"{e['filename']}")
            if e["via"] == "meta":
                txt += "  (via Facebook)"
            if e["link"] in stories:
                txt += "  📱 Story"
            if e["caption"]:
                txt += f" — {e['caption'][:40]}"
            ttk.Label(row, text=txt[:95],
                      font=(self.font_name, 9)).pack(side="left",
                                                     padx=(4, 0))
            if e["link"].startswith("http"):
                link_lbl = ttk.Label(row, text="🔗 Dekhein",
                                     font=(self.font_name, 9),
                                     cursor="hand2")
                link_lbl.pack(side="left", padx=(8, 0))
                link_lbl.bind("<Button-1>",
                              lambda ev, url=e["link"]:
                              webbrowser.open(url))
            self.posted_rows.append((e, v))

    def _posted_set_all(self, val):
        for _e, v in self.posted_rows:
            v.set(val)

    KIND_NAMES = {"video": "video", "photo": "photo",
                  "carousel": "carousel", "story": "story"}

    @staticmethod
    def _entry_kind(e):
        """A history entry's delete kind. Carousels carry no media
        extension by construction — their history filename is
        "Carousel (N photos)" — so they are detected by prefix."""
        fn = e["filename"]
        if fn.startswith("Carousel ("):
            return "carousel"
        ext = Path(fn).suffix.lower()
        if ext in app.VIDEO_EXTS:
            return "video"
        if ext in app.IMAGE_EXTS:
            return "photo"
        return "other"

    def delete_typed_posts(self, kind):
        """One delete button's flow: filter ticked rows by kind, one
        confirmation naming kind + count, then start the run. A
        kind with no ticked rows warns and does nothing."""
        if self._delete_running:
            messagebox.showwarning("Delete posts",
                                   "Delete abhi chal rahi hai — thora "
                                   "ruk jayein.",
                                   parent=self.root)
            return
        ticked = [e for e, v in self.posted_rows if v.get()]
        if not ticked:
            messagebox.showwarning("Delete posts",
                                   "Pehle koi post tick karein.",
                                   parent=self.root)
            return
        if kind == "story":
            # A story is only deletable if this app recorded its id
            # at upload time — the 📱 badge marks those rows. Rows
            # without a record are skipped (their stories expired
            # with the 24h window or were never posted from here).
            recorded = app.load_story_posts()
            chosen = [e for e in ticked if e["link"] in recorded]
        else:
            chosen = [e for e in ticked if self._entry_kind(e) == kind]
        if not chosen:
            if kind == "story":
                msg = ("Tick ki hui rows mein koi recorded story "
                       "nahi hai.")
            else:
                msg = (f"Tick ki hui rows mein koi "
                       f"{self.KIND_NAMES[kind]} nahi hai.")
            messagebox.showwarning("Delete posts", msg,
                                   parent=self.root)
            return
        if kind == "story":
            confirm = (f"{len(chosen)} stories delete hongi, posts "
                       "rahenge.\n\nPakka?")
        else:
            confirm = (f"{len(chosen)} {self.KIND_NAMES[kind]} post(s) "
                       "Instagram se DELETE hongi — wapas nahi "
                       "aayengi.\n\nPakka delete karun?")
        if not messagebox.askyesno("Delete posts", confirm,
                                   parent=self.root):
            return
        self._start_delete(chosen, kind)

    def _start_delete(self, chosen, kind):
        self._delete_running = True
        self._delete_kind = kind
        self._delete_total = len(chosen)
        self._delete_stop = threading.Event()
        self._delete_results = None
        self._delete_progress = (0, len(chosen), "")
        if kind == "story":
            self.posted_prog.config(
                text=f"⏳ Stories delete ho rahi hain: 0 / {len(chosen)}")
            self.status(f"{len(chosen)} stories delete ho rahi hain…")
        else:
            self.posted_prog.config(
                text=f"⏳ Delete ho rahi hain: 0 / {len(chosen)}")
            self.status(f"{len(chosen)} post(s) delete ho rahi hain…")
        self._set_delete_ui_running(True)
        threading.Thread(target=self._delete_posts_worker,
                         args=(chosen, kind), daemon=True).start()
        # The worker must never touch Tk (that crashes from a thread),
        # so the main thread polls for its result instead.
        self.root.after(500, self._poll_delete)

    def _set_delete_ui_running(self, running):
        state = "disabled" if running else "normal"
        for b in self.del_btns.values():
            b.config(state=state)
        self.stop_btn.config(state="normal" if running else "disabled")

    def _stop_delete(self):
        # Only sets the event — the worker checks it between entries.
        # Never touches worker state; the poll loop reports the stop.
        if self._delete_stop is not None:
            self._delete_stop.set()
        self.status("⏹ Roka ja raha hai — maujooda entry ke baad "
                    "ruk jayega…")

    def _delete_posts_worker(self, chosen, kind):
        def _prog(n, total, name):
            # Plain attribute assignment only — no Tk calls from here.
            self._delete_progress = (n, total, name)

        story_only = (kind == "story")
        try:
            results = app.delete_posted_entries(
                chosen, on_progress=_prog, story_only=story_only,
                should_stop=self._delete_stop)
        except Exception as ex:
            # The whole delete failing must never leave the progress
            # line spinning forever. In story-only mode this is
            # reported as failed stories, never as failed posts.
            if story_only:
                results = [(e, True, "",
                            {"status": "failed",
                             "error": f"Delete shuru nahi ho saka: {ex}"[:120]})
                           for e in chosen]
            else:
                results = [(e, False,
                            f"Delete shuru nahi ho saka: {ex}"[:150], None)
                           for e in chosen]
        done, failed, stories = [], [], []
        for r in results:
            # Defensive: older result shapes (3-tuples) still unpack.
            e, ok, err = r[0], r[1], r[2]
            story = r[3] if len(r) > 3 else None
            if story_only:
                # Story-only runs never touch posts: no history lines
                # are dropped and no post is ever reported failed.
                if story is not None:
                    stories.append((e, story))
            else:
                if ok:
                    done.append(e)
                else:
                    failed.append((e, err))
                if story is not None:
                    stories.append((e, story))
        if done:
            app.delete_history_links([e["link"] for e in done])
        stopped = (self._delete_stop is not None
                   and self._delete_stop.is_set()
                   and len(results) < len(chosen))
        self._delete_results = (done, failed, stories, stopped)

    def _poll_delete(self):
        try:
            prog = self._delete_progress
            if prog is not None:
                n, total, name = prog
                if self._delete_kind == "story":
                    txt = (f"⏳ Stories delete ho rahi hain: "
                           f"{n} / {total}")
                else:
                    txt = f"⏳ Delete ho rahi hain: {n} / {total}"
                if name:
                    txt += f" — {name}"
                self.posted_prog.config(text=txt)
            if self._delete_results is None:
                self.root.after(500, self._poll_delete)
                return
        except Exception:
            return
        self._finish_delete()

    def _finish_delete(self):
        # Defensive: older result shapes (2-/3-tuples) still unpack.
        res = self._delete_results or ([], [], [], False)
        done = res[0] if len(res) > 0 else []
        failed = res[1] if len(res) > 1 else []
        stories = res[2] if len(res) > 2 else []
        stopped = res[3] if len(res) > 3 else False
        kind = getattr(self, "_delete_kind", "video")
        total = getattr(self, "_delete_total", 0)
        self._delete_results = None
        self._delete_running = False
        self._delete_progress = None
        self.posted_prog.config(text="")
        self._set_delete_ui_running(False)
        self.refresh_history()
        self.refresh_posted_manager()
        if kind == "story":
            n_sdel = sum(1 for _e, s in stories
                         if s.get("status") == "deleted")
            n_sgone = sum(1 for _e, s in stories
                          if s.get("status") == "gone")
            s_failed = [(e, s.get("error", "")) for e, s in stories
                        if s.get("status") == "failed"]
            remaining = max(0, total - len(stories))
            if s_failed:
                lines = []
                if stopped:
                    lines.append(f"⏹ Rok diya gaya: {n_sdel} stories "
                                 f"delete ho gayin, {remaining} baaki "
                                 "reh gayin.")
                lines.append("Story delete nahi ho saki:")
                lines += [f"{e['filename']}: {err}"
                          for e, err in s_failed[:5]]
                if n_sdel:
                    lines.append(f"{n_sdel} story delete ✅")
                if n_sgone:
                    lines.append(f"{n_sgone} story pehle se khatam "
                                 "thi (24h)")
                messagebox.showwarning("Delete posts", "\n".join(lines),
                                       parent=self.root)
            else:
                if stopped:
                    self.status(f"⏹ Rok diya gaya: {n_sdel} stories "
                                f"delete ho gayin, {remaining} baaki "
                                "reh gayin.")
                elif n_sdel or n_sgone:
                    self.status(
                        f"{n_sdel} stories delete ho gayin ✅"
                        + (f" • {n_sgone} pehle se khatam thi (24h)"
                           if n_sgone else ""))
                else:
                    self.status("In posts ki koi recorded story nahi "
                                "hai — kuch delete nahi hua.")
            return
        # Post kinds (video/photo/carousel): already-deleted posts
        # stay deleted even when stopped — they cannot come back.
        remaining = max(0, total - (len(done) + len(failed)))
        if failed:
            lines = []
            if stopped:
                lines.append(f"⏹ Rok diya gaya: {len(done)} delete ho "
                             f"gayin, {remaining} baaki reh gayin.")
            lines.append(f"{len(done)} post(s) delete ho gayin ✅")
            lines.append(f"{len(failed)} post delete nahi ho saki:")
            lines += [f"{e['filename']}: {err}"
                      for e, err in failed[:5]]
            messagebox.showwarning("Delete posts", "\n".join(lines),
                                   parent=self.root)
        else:
            if stopped:
                self.status(f"⏹ Rok diya gaya: {len(done)} delete ho "
                            f"gayin, {remaining} baaki reh gayin.")
            else:
                self.status(f"{len(done)} post(s) Instagram se delete "
                            "ho gayin ✅")

    def build_notif_tab(self):
        """🔔 Notifications: today's posts — done, pending, failed."""
        top = ttk.Frame(self.notif_tab)
        top.pack(fill="x", pady=(0, 8))
        ttk.Label(top, text="Today's posting status",
                  style="Header.TLabel").pack(side="left")
        ttk.Button(top, text="🔄 Refresh",
                   command=self.refresh_notif).pack(side="right")
        # Today's posting plan: time slots, accounts per slot, live
        # done counts. The sections below list everything (thousands
        # of far-future jobs); this one shows only what posts today.
        planf = ttk.LabelFrame(self.notif_tab, text="📅 Aaj ki posting",
                               padding=8)
        planf.pack(fill="x", pady=(0, 6))
        prow = ttk.Frame(planf)
        prow.pack(fill="x")
        ttk.Label(prow, text="Time:").pack(side="left")
        self.today_time_var = tk.StringVar(value="Aaj sab")
        self.today_time_combo = ttk.Combobox(
            prow, textvariable=self.today_time_var, state="readonly",
            width=14)
        self.today_time_combo.pack(side="left", padx=(6, 0))
        self.today_time_combo.bind(
            "<<ComboboxSelected>>",
            lambda e: self._refresh_today_plan())
        self.today_summary = ttk.Label(prow, font=(self.font_name, 10,
                                                   "bold"))
        self.today_summary.pack(side="left", padx=(12, 0))
        ttk.Button(prow, text="📋 Accounts batch…",
                   command=self._account_batch_dialog).pack(
                       side="left", padx=(12, 0))
        lrow = ttk.Frame(planf)
        lrow.pack(fill="x", pady=(6, 0))
        self.today_list = tk.Listbox(lrow, height=6,
                                     font=(self.font_name, 10))
        tsb = ttk.Scrollbar(lrow, orient="vertical",
                            command=self.today_list.yview)
        self.today_list.configure(yscrollcommand=tsb.set)
        tsb.pack(side="right", fill="y")
        self.today_list.pack(side="left", fill="both", expand=True)
        # summary counts
        self.notif_summary = ttk.Label(self.notif_tab,
                                       font=(self.font_name, 11, "bold"))
        self.notif_summary.pack(anchor="w", pady=(0, 6))
        # three sections
        for title, attr in [("✅ Posted today", "notif_done"),
                            ("⏳ Waiting / scheduled", "notif_pending"),
                            ("❌ Failed — needs your attention", "notif_failed")]:
            hdr = ttk.Frame(self.notif_tab)
            hdr.pack(fill="x", pady=(6, 2))
            ttk.Label(hdr, text=title,
                      font=(self.font_name, 11, "bold")).pack(side="left")
            if attr == "notif_failed":
                ttk.Button(hdr, text="🗑 Clear failed",
                           command=self.clear_failed).pack(side="right")
            lst = tk.Listbox(self.notif_tab, height=5,
                             font=(self.font_name, 10))
            sb = ttk.Scrollbar(self.notif_tab, orient="vertical",
                               command=lst.yview)
            lst.configure(yscrollcommand=sb.set)
            sb.pack(side="right", fill="y")
            lst.pack(fill="x", expand=False)
            setattr(self, attr, lst)
        self.refresh_notif()

    def clear_failed(self):
        """Remove all failed jobs from the queue (clears the Failed list)."""
        with app.QUEUE_LOCK:
            n = sum(1 for j in app.QUEUE if j.get("status") == "failed")
        if not n:
            self.status("No failed posts to clear.")
            return
        if not messagebox.askyesno(
                "Clear failed",
                f"Remove all {n} failed post(s) from the list?\n\n"
                "They will not be retried."):
            return
        with app.QUEUE_LOCK:
            app.QUEUE[:] = [j for j in app.QUEUE
                            if j.get("status") != "failed"]
        app.save_queue()
        self.refresh_notif()
        try:
            self.refresh_queue()
        except Exception:
            pass
        self.status(f"Cleared {n} failed post(s). 🗑")

    def refresh_notif(self):
        from datetime import datetime
        today = datetime.now().strftime("%Y-%m-%d")
        done, pending, failed = [], [], []
        for line in app.read_history(limit=200):
            if line.startswith(today):
                # "2026-10-18 20:01 | account | file | caption | link"
                parts = line.split(" | ")
                acct = parts[1] if len(parts) > 1 else "?"
                fn = parts[2] if len(parts) > 2 else ""
                done.append(f"✅ {acct} — {fn}")
        with app.QUEUE_LOCK:
            queue = list(app.QUEUE)
        for job in queue:
            acct = job.get("account", "?")
            fn = Path(job.get("file", "")).name or job.get("link", "")
            st = job.get("status", "")
            when = job.get("scheduled_at", "")
            if st == "failed":
                failed.append(f"❌ {acct} — {fn} — {job.get('message', '')}")
            else:
                pending.append(f"⏳ {acct} — {fn}"
                               + (f" at {when}" if when else ""))
        for lst, items in [(self.notif_done, done),
                           (self.notif_pending, pending),
                           (self.notif_failed, failed)]:
            lst.delete(0, "end")
            if items:
                for it in items:
                    lst.insert("end", it)
            else:
                lst.insert("end", "(none)")
        self.notif_summary.config(
            text=f"✅ {len(done)} posted   •   ⏳ {len(pending)} waiting   •   "
                 f"❌ {len(failed)} failed")
        self._refresh_today_plan()

    def _refresh_today_plan(self):
        """Fill the Today's posting plan section (live, every 2.5s).

        Kept separate from refresh_notif: the old sections list
        thousands of jobs and rebuild only on manual Refresh, while
        this small section must advance live as posts land (waiting
        -> done) during a posting window.
        """
        if not hasattr(self, "today_list"):
            return
        from datetime import datetime
        today = datetime.now().strftime("%Y-%m-%d")
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        order, plan = app.today_posting_plan(jobs, today)
        values = ["Aaj sab"] + order
        self.today_time_combo["values"] = values
        sel = self.today_time_var.get()
        if sel not in values:
            sel = "Aaj sab"
            self.today_time_var.set(sel)
        slots = order if sel == "Aaj sab" else [sel] if sel in plan else []
        rows = []
        for slot in slots:
            for job in plan.get(slot, []):
                rows.append((slot, job))
        accts = set()
        done = failed = 0
        for _slot, job in rows:
            acct = job.get("account", "")
            if job.get("via") == "meta":
                acct = "📘 " + acct
            accts.add(acct)
            if job.get("status") == "done":
                done += 1
            elif job.get("status") == "failed":
                failed += 1
        baaki = len(rows) - done - failed
        scope = "Aaj" if sel == "Aaj sab" else sel
        txt = (f"{scope}: {len(accts)} accounts • {len(rows)} posts • "
               f"✅ {done} done • ⏳ {baaki} baaki")
        if failed:
            txt += f" • ❌ {failed} failed"
        self.today_summary.config(text=txt)
        self.today_list.delete(0, "end")
        if not rows:
            self.today_list.insert(
                "end", "(Aaj koi posting nahi hai)" if sel == "Aaj sab"
                else f"(Is time ({sel}) koi posting nahi hai)")
            return
        icons = {"done": "✅", "failed": "❌", "paused": "⏸",
                 "uploading": "📤"}
        for slot, job in rows:
            acct = job.get("account", "")
            if job.get("via") == "meta":
                acct = "📘 " + acct
            fn = job.get("filename", "") or job.get("link", "")
            icon = icons.get(job.get("status", ""), "⏳")
            self.today_list.insert(
                "end", f"{icon} {slot}  {acct} — {fn}")

    # ---------------- Facebook login ----------------
    META_GUIDE = (
        "Get your Facebook login working (one time, about 10 minutes):\n\n"
        "1. On your laptop go to developers.facebook.com and log in\n"
        "   with your Facebook account.\n"
        "2. Click 'Create App'. Name it WITHOUT the words insta, gram,\n"
        "   face, book or fb (Meta blocks those) - e.g. PostPilot.\n"
        "   Type: Business. Then Create.\n"
        "3. Left menu -> 'Add use cases' -> tick 'Authenticate and\n"
        "   request data from users with Facebook Login' -> continue.\n"
        "   (Skip Business verification and App Review - you don't\n"
        "   need them for your own accounts.)\n"
        "4. Left menu -> Facebook Login -> Settings -> set\n"
        "   'Login from Devices' to Yes -> Save.\n"
        "5. Left menu -> Settings -> Basic. Copy the 'App ID' and the\n"
        "   'App Secret' (click Show).\n"
        "   Then left menu -> Settings -> Advanced, find 'Client\n"
        "   Token' and copy it too (needed for the login step).\n"
        "6. Back in InstaUploader's Facebook tab, paste all three\n"
        "   above and press Save.\n"
        "7. Press 'Login with Facebook'. The app shows you a code -\n"
        "   on your phone or computer go to facebook.com/device,\n"
        "   type the code, and approve. Done!\n\n"
        "Notes:\n"
        "- Keep the app in Development mode (no review needed for\n"
        "  your own accounts).\n"
        "- The login lasts about 60 days, then just log in again.\n"
        "- Posting this way uploads your photo/video to a temporary\n"
        "  public link (catbox.moe) so Instagram can fetch it."
    )

    def build_fb_tab(self):
        sf = ttk.LabelFrame(self.fb_tab, text="Meta app (one-time setup)",
                            padding=8)
        sf.pack(fill="x")
        ttk.Label(sf, text="App ID:").pack(anchor="w")
        self.meta_app_id = ttk.Entry(sf, width=40)
        self.meta_app_id.pack(fill="x")
        ttk.Label(sf, text="App Secret:").pack(anchor="w", pady=(6, 0))
        self.meta_app_secret = ttk.Entry(sf, width=40, show="•")
        self.meta_app_secret.pack(fill="x")
        ttk.Label(sf, text="Client Token (App Settings → Advanced):").pack(
            anchor="w", pady=(6, 0))
        self.meta_client_token = ttk.Entry(sf, width=40, show="•")
        self.meta_client_token.pack(fill="x")
        br = ttk.Frame(sf)
        br.pack(fill="x", pady=(8, 0))
        ttk.Button(br, text="Save", command=self.save_meta_creds).pack(
            side="left")
        ttk.Button(br, text="Where do I get these?",
                   command=self.show_meta_guide).pack(side="left", padx=(6, 0))
        m = app.load_meta()
        if m.get("app_id"):
            self.meta_app_id.insert(0, m["app_id"])
        if m.get("app_secret"):
            self.meta_app_secret.insert(0, m["app_secret"])
        if m.get("client_token"):
            self.meta_client_token.insert(0, m["client_token"])

        lf = ttk.LabelFrame(self.fb_tab, text="Login", padding=8)
        lf.pack(fill="x", pady=(8, 0))
        ttk.Button(lf, text="🔵 Login with Facebook", style="Accent.TButton",
                   command=self.fb_login).pack(anchor="w")
        self.fb_status = ttk.Label(lf, text="Not logged in.",
                                   font=("Segoe UI", 9))
        self.fb_status.pack(anchor="w", pady=(6, 0))
        self.fb_error = ttk.Label(lf, text="", font=("Segoe UI", 9),
                                  wraplength=620)
        self.fb_error.pack(anchor="w", pady=(2, 0))

        mf = ttk.LabelFrame(self.fb_tab,
                            text="No browser login? Paste a token instead",
                            padding=8)
        mf.pack(fill="x", pady=(8, 0))
        ttk.Label(mf, font=("Segoe UI", 8), wraplength=620,
                  text="1. Go to developers.facebook.com/tools/explorer\n"
                       "2. Pick your app (top-right dropdown)\n"
                       "3. 'Add a permission': tick instagram_business_basic, "
                       "instagram_business_content_publish\n"
                       "4. 'Generate access token' -> approve -> copy the token\n"
                       "5. Paste it below and press Use token.").pack(anchor="w")
        self.meta_manual_token = ttk.Entry(mf, width=40)
        self.meta_manual_token.pack(fill="x", pady=(6, 0))
        ttk.Button(mf, text="Use this token",
                   command=self.fb_use_manual_token).pack(anchor="w",
                                                         pady=(6, 0))

        af = ttk.LabelFrame(self.fb_tab,
                            text="Connected accounts", padding=8)
        af.pack(fill="x", pady=(8, 0))
        self.fb_bm_label = ttk.Label(af, text="🏢 Business: —",
                                     font=("Segoe UI", 10, "bold"))
        self.fb_bm_label.pack(anchor="w")
        ttk.Label(af, text="Page:").pack(anchor="w", pady=(6, 0))
        self.fb_page_combo = ttk.Combobox(af, state="readonly",
                                          font=("Segoe UI", 10))
        self.fb_page_combo.pack(fill="x")
        ttk.Label(af, text="Instagram:").pack(anchor="w", pady=(6, 0))
        self.fb_ig_combo = ttk.Combobox(af, state="readonly",
                                        font=("Segoe UI", 10))
        self.fb_ig_combo.pack(fill="x")
        ttk.Button(af, text="Refresh list",
                   command=self.fb_refresh_from_facebook).pack(pady=(6, 0))

        ttk.Label(
            self.fb_tab,
            text="Posting via Facebook uploads your photo/video to a "
                 "temporary public link (catbox.moe) so Instagram can fetch "
                 "it. Your App Secret never leaves this laptop.",
            font=("Segoe UI", 8), wraplength=640).pack(pady=(8, 0), anchor="w")
        self.update_fb_status()
        self.fb_refresh_accounts()

    def save_meta_creds(self):
        m = app.load_meta()
        m["app_id"] = self.meta_app_id.get().strip()
        m["app_secret"] = self.meta_app_secret.get().strip()
        m["client_token"] = self.meta_client_token.get().strip()
        app.save_meta(m)
        self.status("Meta app details saved.")

    def show_meta_guide(self):
        top = tk.Toplevel(self.root)
        top.title("Facebook setup guide")
        top.geometry("520x520")
        txt = tk.Text(top, font=("Segoe UI", 10), wrap="word", padx=10, pady=10,
                      bg=self.theme["entry_bg"], fg=self.theme["entry_fg"])
        txt.pack(fill="both", expand=True)
        txt.insert("1.0", self.META_GUIDE)
        txt.config(state="disabled")

    def update_fb_status(self):
        m = app.load_meta()
        if m.get("access_token") and m.get("expires_at", 0) > time.time():
            days = int((m["expires_at"] - time.time()) // 86400)
            self.fb_status.config(
                text=f"Logged in ✅ (expires in about {days} days)")
        else:
            self.fb_status.config(text="Not logged in.")

    def fb_refresh_accounts(self):
        m = app.load_meta()
        bms = m.get("businesses", [])
        if bms:
            self.fb_bm_label.config(
                text="🏢 Business: " + ", ".join(b["name"] for b in bms))
        else:
            self.fb_bm_label.config(text="🏢 Business: —")
        pages = m.get("pages", [])
        # Sorted A-Z (case-insensitive) for display only: the API
        # returns Pages in no usable order, so finding one in a long
        # list was guesswork. The saved discovery order is untouched.
        page_names = sorted((p["name"] for p in pages),
                            key=lambda s: s.lower())
        self.fb_page_combo["values"] = page_names or ["—"]
        self.fb_page_combo.current(0)
        igs = sorted(m.get("ig_accounts", []),
                     key=lambda a: a.get("username", "").lower())
        self.fb_ig_combo["values"] = [
            f"📘 @{a['username']}" + (f"  (via {a['page']})" if a.get("page") else "")
            for a in igs] or ["—"]
        self.fb_ig_combo.current(0)
        self.refresh_accounts()

    def fb_refresh_from_facebook(self):
        """Refresh list now really re-fetches from Facebook.

        The old button only redrew the saved list, so Pages/IG accounts
        linked AFTER login never appeared until the next login. This
        re-runs discovery with the saved token and saves the result.
        A failed or empty fetch never wipes the saved list.
        """
        if getattr(self, "_fb_refreshing", False):
            return
        m = app.load_meta()
        token = m.get("access_token", "")
        if not token or m.get("expires_at", 0) <= time.time():
            messagebox.showinfo(
                "Refresh list",
                "Pehle 'Login with Facebook' karo — token nahi hai ya "
                "expire ho gaya hai.")
            return
        self._fb_refreshing = True
        self.fb_status.config(text="List update ho rahi hai…")

        def run():
            try:
                disc = app.meta_discover(token)
                self.root.after(0, lambda: self._fb_refresh_done(disc))
            except Exception as e:
                # Capture now: the except-block variable is deleted
                # before a deferred lambda would read it.
                err = str(e)
                self.root.after(0, lambda: self._fb_refresh_done(None, err))

        threading.Thread(target=run, daemon=True).start()

    def _fb_refresh_done(self, disc, err=None):
        self._fb_refreshing = False
        saved = app.load_meta()
        if disc is None:
            self.fb_status.config(text="List update nahi ho saki.")
            messagebox.showwarning(
                "Refresh list",
                "Nayi list nahi aa saki (internet ya token ka masla) — "
                "purani list wahi hai.\n\nAgar masla rahe to dobara "
                "'Login with Facebook' karo.")
            return
        if (not disc.get("pages") and not disc.get("ig_accounts")
                and (saved.get("pages") or saved.get("ig_accounts"))):
            # A failed fetch returns empty lists; never let it wipe good data.
            self.fb_status.config(text="List update nahi ho saki.")
            messagebox.showwarning(
                "Refresh list",
                "Facebook se khaali list aayi — purani list mehfooz rakhi "
                "gayi hai.\n\nAgar masla rahe to dobara "
                "'Login with Facebook' karo.")
            return
        saved["businesses"] = disc.get("businesses", [])
        saved["pages"] = disc.get("pages", [])
        saved["ig_accounts"] = disc.get("ig_accounts", [])
        app.save_meta(saved)
        self.fb_refresh_accounts()
        n = len(saved["ig_accounts"])
        self.fb_status.config(
            text=f"List update ho gayi — {n} Instagram account(s).")
        self.status(f"Facebook list update ho gayi — {n} Instagram account(s).")
        self._announce_meta_convert(
            app.convert_api_jobs_to_meta(disc.get("ig_accounts", [])))

    def _announce_meta_convert(self, moved):
        """Tell her which waiting posts just switched to Meta.

        Runs after every Facebook discovery (login + Refresh list):
        an account that just got Page-linked has its waiting API
        posts switched to the Meta route on its own, so she never
        has to re-queue them by hand. Only waiting posts move, and
        only when something actually moved is anything shown.
        """
        if not moved:
            return
        total = sum(moved.values())
        detail = " • ".join(f"{u}: {c}" for u, c in moved.items())
        self.refresh_queue()
        self.status(f"Meta route: {total} waiting posts khud hi Meta "
                    f"par kar di gayi — {detail}.")
        messagebox.showinfo(
            "Meta route",
            f"Page link ho gaya, is liye {total} waiting posts khud "
            f"hi Meta route par kar di gayi hain:\n\n{detail}\n\n"
            "Time, caption aur video wahi hain. Video covers Meta "
            "route par nahi lagte.")

    def fb_fail(self, msg):
        """Show a login error persistently in the tab (and as a popup)."""
        self.fb_status.config(text="Login failed.")
        try:
            self.fb_error.config(text=str(msg), foreground="red")
        except Exception:
            pass
        try:
            messagebox.showerror("Facebook login", str(msg))
        except Exception:
            pass

    def fb_login(self):
        m = app.load_meta()
        app_id = self.meta_app_id.get().strip() or m.get("app_id", "")
        app_secret = self.meta_app_secret.get().strip() or m.get("app_secret", "")
        client_token = self.meta_client_token.get().strip() or m.get("client_token", "")
        if not app_id or not app_secret:
            messagebox.showwarning(
                "Missing",
                "Enter your App ID and App Secret first "
                "(see 'Where do I get these?').")
            return
        m["app_id"] = app_id
        m["app_secret"] = app_secret
        m["client_token"] = client_token
        app.save_meta(m)
        self.fb_error.config(text="")
        self.fb_status.config(text="Starting Facebook login…")

        def run():
            try:
                dev = app.meta_device_login_start(app_id, app_secret,
                                                  client_token or None)
                self.root.after(
                    0, lambda: self.show_device_dialog(dev, app_id, app_secret,
                                                      client_token or None))
                self.root.after(
                    0, lambda: self.fb_status.config(text="Enter the code…"))
            except Exception as e:
                msg = str(e)
                self.root.after(0, lambda: self.fb_fail(msg))

        threading.Thread(target=run, daemon=True).start()

    def show_device_dialog(self, dev, app_id, app_secret, client_token=None):
        top = tk.Toplevel(self.root)
        top.title("Facebook login")
        top.geometry("440x320")
        top.resizable(False, False)
        top.transient(self.root)
        top.grab_set()
        stop = threading.Event()
        ttk.Label(top, text="Enter this code at facebook.com/device:",
                  font=("Segoe UI", 11)).pack(pady=(18, 4))
        ttk.Label(top, text=dev["user_code"],
                  font=("Segoe UI", 34, "bold"),
                  foreground=self.theme["header_fg"]).pack(pady=8)
        ttk.Label(top,
                  text="On your phone or computer, go to facebook.com/device,\n"
                       "type the code, and approve.",
                  font=("Segoe UI", 10), justify="center").pack(pady=4)
        status = ttk.Label(top, text="Waiting for approval…",
                           font=("Segoe UI", 9, "italic"))
        status.pack(pady=8)

        def cancel():
            stop.set()
            top.destroy()
            self.fb_status.config(text="Login cancelled.")

        ttk.Button(top, text="Cancel", command=cancel).pack(pady=4)
        top.protocol("WM_DELETE_WINDOW", cancel)

        def run():
            try:
                self.root.after(0, lambda: status.config(
                    text="Waiting for approval at facebook.com/device…"))
                token, exp = app.meta_device_login_poll(
                    app_id, app_secret, dev["code"],
                    dev.get("interval", 5), dev.get("expires_in", 420), stop,
                    client_token)
                self.root.after(0, lambda: status.config(
                    text="Code approved! Getting your accounts…"))
                m2 = app.load_meta()
                m2["access_token"] = token
                m2["expires_at"] = exp
                disc = app.meta_discover(token)
                m2["ig_accounts"] = disc["ig_accounts"]
                m2["businesses"] = disc["businesses"]
                m2["pages"] = disc["pages"]
                app.save_meta(m2)
                self.root.after(
                    0, lambda: (top.destroy(),
                                self.fb_login_done(disc["ig_accounts"])))
            except Exception as e:
                if not stop.is_set():
                    msg = str(e)
                    self.root.after(0, lambda: (top.destroy(),
                                               self.fb_fail(msg)))

        threading.Thread(target=run, daemon=True).start()

    def fb_login_done(self, accs):
        self.fb_error.config(text="")
        self.update_fb_status()
        self.fb_refresh_accounts()
        if accs:
            self.status(f"Facebook login OK — {len(accs)} Instagram "
                        f"account(s) linked.")
            self._announce_meta_convert(
                app.convert_api_jobs_to_meta(accs))
        else:
            messagebox.showinfo(
                "No accounts",
                "Login worked, but no Instagram Business/Creator accounts "
                "were found on your Pages.\n\nCheck that each Instagram "
                "account is linked to a Facebook Page.")

    def fb_use_manual_token(self):
        m = app.load_meta()
        app_id = self.meta_app_id.get().strip() or m.get("app_id", "")
        app_secret = self.meta_app_secret.get().strip() or m.get("app_secret", "")
        short = self.meta_manual_token.get().strip()
        if not app_id or not app_secret:
            messagebox.showwarning(
                "Missing", "Enter your App ID and App Secret first.")
            return
        if not short:
            messagebox.showwarning("Missing", "Paste the token first.")
            return
        m["app_id"] = app_id
        m["app_secret"] = app_secret
        app.save_meta(m)
        self.fb_status.config(text="Checking token…")

        def run():
            try:
                token, exp = app.meta_to_long_lived(app_id, app_secret, short)
                m2 = app.load_meta()
                m2["access_token"] = token
                m2["expires_at"] = exp
                disc = app.meta_discover(token)
                m2["ig_accounts"] = disc["ig_accounts"]
                m2["businesses"] = disc["businesses"]
                m2["pages"] = disc["pages"]
                app.save_meta(m2)
                self.root.after(0, lambda: self.fb_login_done(disc["ig_accounts"]))
            except Exception as e:
                msg = str(e)
                self.root.after(0, lambda: self.fb_fail(msg))

        threading.Thread(target=run, daemon=True).start()

    # ---------------- accounts ----------------
    def meta_account_choices(self):
        return [("📘 " + a["username"], a["ig_id"])
                for a in app.load_meta().get("ig_accounts", [])
                if a.get("username") and a.get("ig_id")]

    def resolve_account(self, display):
        """(username, via, meta_ig_id) for a dropdown choice."""
        for label, ig_id in self.meta_account_choices():
            if display == label:
                return label[2:], "meta", ig_id
        return display, "api", ""

    def all_account_labels(self):
        """Every postable account's dropdown label (password + Meta)."""
        return app.load_accounts() + [label for label, _ in self.meta_account_choices()]

    def group_labels(self):
        return ["👥 " + g["name"] for g in app.load_groups()]

    def group_by_label(self, display):
        if display.startswith("👥 "):
            name = display[2:].strip()
            for g in app.load_groups():
                if g["name"] == name:
                    return g
        return None

    def refresh_accounts(self):
        """Account list with a live status icon per account.

        ✅ = active (saved session, or saved password so it can log
        itself in when posting). ⏻ = you logged it out. ⚠️ = login
        needed (last post failed for a login reason, or it has neither
        a session nor a saved password). Rebuilds only when the shown
        lines actually changed, and keeps the highlighted row.
        """
        accounts = app.load_accounts()
        # Numbered lines: the number IS the account's position, so the
        # total count and "which number is that account" are visible.
        # Selection stays index-based (via _acc_list_users), so the
        # numbers never disturb any button that acts on the selection.
        shown = [f"{i + 1}. {app.account_display(a)}"
                 for i, a in enumerate(accounts)]
        # Total count in the title + the Login-needed box. These update
        # even when the list itself is unchanged (early return below).
        if hasattr(self, "acc_frame"):
            self.acc_frame.config(text=f"Your accounts ({len(accounts)})")
        self._sync_login_needed_box(accounts)
        current = list(self.acc_list.get(0, "end"))
        if current == shown and getattr(self, "_acc_list_users", None) == list(accounts):
            return
        sel = self.acc_list.curselection()
        self._acc_list_users = list(accounts)
        self.acc_list.delete(0, "end")
        for line in shown:
            self.acc_list.insert("end", line)
        if sel and shown:
            self.acc_list.selection_set(min(sel[0], len(shown) - 1))
        self.refresh_account_choices()

    def _sync_login_needed_box(self, accounts):
        """Rebuild the Login-needed box only when its contents changed.

        Lists every account that cannot post right now (⚠️ login needed
        and ⏻ logged out — both need a 🔑 Login). Each row has its own
        Login button, so the fix is one click from here.
        """
        if not hasattr(self, "_login_needed_box"):
            return
        needy = []
        for a in accounts:
            st = app.account_status(a)
            if st != "active":
                needy.append((a, st))
        if needy == getattr(self, "_login_needed_shown", None):
            return
        self._login_needed_shown = needy
        for w in self._login_needed_box.winfo_children():
            w.destroy()
        # Compact box: show at most 4 rows, the rest via the scrollbar.
        if hasattr(self, "_login_needed_canvas"):
            self._login_needed_canvas.config(
                height=min(max(len(needy), 1), 4) * 32)
        if needy:
            self.login_needed_frame.config(
                text=f"🔑 Login chahiye ({len(needy)})")
            for name, st in needy:
                icon = "⚠️ " if st == "login_needed" else "⏻ "
                row = ttk.Frame(self._login_needed_box)
                row.pack(fill="x", pady=1)
                ttk.Label(row, text=f"{icon}@{name}",
                          font=("Segoe UI", 10)).pack(side="left")
                ttk.Button(row, text="🔑 Login",
                           command=lambda n=name: self._login_needed_login(n)
                           ).pack(side="left", padx=(8, 0))
                ttk.Button(row, text="🌐 Browser",
                           command=lambda n=name: self._login_needed_browser(n)
                           ).pack(side="left", padx=(4, 0))
        else:
            self.login_needed_frame.config(text="🔑 Login chahiye")
            ttk.Label(
                self._login_needed_box,
                text="✅ Sab accounts theek hain — kisi ko login nahi chahiye.",
                font=("Segoe UI", 9)).pack(anchor="w")

    def _login_needed_login(self, username):
        """From the Login-needed box: select the account, then re-login."""
        self._select_account(username)
        self.relogin_account()

    def _login_needed_browser(self, username):
        """Open Instagram in her browser for this account, so she can
        complete a confirmation there. Approve-in-app (Bloks/native)
        challenges can only be done in the Instagram app or browser —
        no software can do them — so this button is the way in."""
        webbrowser.open("https://www.instagram.com/accounts/login/")
        self.status(f"@{username} ke liye Instagram browser mein khul "
                    "raha hai — wahan login karo aur confirmation poori "
                    "karo, phir wapas aa kar 🔑 Login dabao.")

    def _find_chromium(self):
        """Chrome or Edge exe, or None. Both are Chromium and accept
        --user-data-dir + --window-size/--window-position."""
        for name in ("chrome.exe", "msedge.exe"):
            p = shutil.which(name)
            if p:
                return p
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pf86 = os.environ.get("ProgramFiles(x86)",
                              r"C:\Program Files (x86)")
        local = os.environ.get("LOCALAPPDATA", "")
        for c in (
            os.path.join(pf, "Google", "Chrome", "Application",
                         "chrome.exe"),
            os.path.join(pf86, "Google", "Chrome", "Application",
                         "chrome.exe"),
            os.path.join(local, "Google", "Chrome", "Application",
                         "chrome.exe"),
            os.path.join(pf, "Microsoft", "Edge", "Application",
                         "msedge.exe"),
            os.path.join(pf86, "Microsoft", "Edge", "Application",
                         "msedge.exe"),
            os.path.join(local, "Microsoft", "Edge", "Application",
                         "msedge.exe"),
        ):
            if c and os.path.exists(c):
                return c
        return None

    def _multi_view_dialog(self):
        """Pick up to 4 accounts to open side by side in the browser.

        Her 4 main accounts stay in front of her eyes on one screen,
        so she can see the views on each page. Each account opens in
        its own browser window (its own profile), arranged in a grid.
        """
        accounts = app.load_accounts()
        if not accounts:
            messagebox.showinfo(
                "4 accounts dekho",
                "Koi account add nahi hai — pehle account add karo.",
                parent=self.root)
            return
        saved = app.load_browser_accounts()
        top = tk.Toplevel(self.root)
        top.title("4 accounts dekho")
        top.attributes("-topmost", True)
        ttk.Label(top,
                  text="Kaun se accounts ek saath kholne hain? "
                       "(zyada se zyada 4)",
                  font=(self.font_name, 11, "bold"),
                  wraplength=430).pack(anchor="w", padx=10, pady=(10, 2))
        ttk.Label(top,
                  text="Har account apni alag browser window mein khule "
                       "ga — ek screen par 2x2, har window mein us "
                       "account ke Reels (views wahin nazar aayenge). "
                       "Pehli dafa har window mein Instagram login karna "
                       "hoga; phir browser yaad rakhe ga.",
                  wraplength=430).pack(anchor="w", padx=10)
        lst = tk.Listbox(top, selectmode="multiple",
                         height=min(len(accounts), 10))
        for a in accounts:
            lst.insert("end", "@" + a)
        for i, a in enumerate(accounts):
            if a in saved:
                lst.selection_set(i)
        lst.pack(fill="x", padx=10, pady=(8, 0))
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=10)

        def open_picked():
            sel = [accounts[i] for i in lst.curselection()]
            if not sel:
                messagebox.showwarning(
                    "4 accounts dekho", "Pehle koi account tick karo.",
                    parent=top)
                return
            if len(sel) > 4:
                messagebox.showwarning(
                    "4 accounts dekho",
                    "Zyada se zyada 4 accounts ek saath khul sakte hain.",
                    parent=top)
                return
            app.save_browser_accounts(sel)
            top.destroy()
            self._open_accounts_in_browser(sel)

        ttk.Button(btns, text="🌐 Kholo",
                   command=open_picked).pack(side="left")
        ttk.Button(btns, text="Cancel",
                   command=top.destroy).pack(side="left", padx=(6, 0))

    def _open_accounts_in_browser(self, usernames):
        """Open each account's Reels in its own browser window, grid."""
        exe = self._find_chromium()
        if not exe:
            messagebox.showinfo(
                "4 accounts dekho",
                "Chrome ya Edge nahi mila — pehle Chrome install karo, "
                "phir dobara dabao.",
                parent=self.root)
            self.status("4 accounts dekho: Chrome/Edge nahi mila.")
            return
        import subprocess
        sw = self.root.winfo_screenwidth()
        sh = max(self.root.winfo_screenheight() - 40, 400)
        n = len(usernames)
        cols = 2 if n > 1 else 1
        rows = (n + cols - 1) // cols
        cw, ch = sw // cols, sh // rows
        for i, username in enumerate(usernames):
            col, row = i % cols, i // cols
            profile = app.DATA / "browser_profiles" / username
            try:
                profile.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
            url = f"https://www.instagram.com/{username}/reels/"
            subprocess.Popen([exe, f"--user-data-dir={profile}",
                              f"--window-size={cw},{ch}",
                              f"--window-position={col * cw},{row * ch}",
                              "--new-window", url])
            time.sleep(0.3)
        self.status(f"{n} accounts browser mein khul rahe hain — har "
                    "window mein pehli dafa login karna hoga.")

    def selected_account(self):
        """Username picked in the accounts list, or None."""
        sel = self.acc_list.curselection()
        if not sel:
            return None
        users = getattr(self, "_acc_list_users", None) or app.load_accounts()
        idx = sel[0]
        if 0 <= idx < len(users):
            return users[idx]
        return None

    def _select_account(self, username):
        """Re-select a username in the accounts list after a refresh."""
        users = getattr(self, "_acc_list_users", None) or []
        if username in users:
            idx = users.index(username)
            self.acc_list.selection_clear(0, "end")
            self.acc_list.selection_set(idx)
            self.acc_list.see(idx)

    def refresh_account_choices(self):
        # Post tab stays basic: single accounts only (groups live in 👥 tab).
        choices = self.all_account_labels()
        self.post_account["values"] = choices
        if choices and (not self.post_account.get()
                        or self.post_account.get() not in choices):
            self.post_account.current(0)
        if hasattr(self, "sched_filter"):
            vals = ["All accounts"] + choices
            self.sched_filter["values"] = vals
            if self.sched_filter_var.get() not in vals:
                self.sched_filter_var.set("All accounts")
        self.refresh_link_group_choices()
        self.refresh_queue_filters()

    def _sched_sync_filter(self, _event=None):
        """New post form's account pick also filters the Schedule list
        below to that account's posts."""
        if not hasattr(self, "sched_filter_var"):
            return
        val = self.post_account.get().strip()
        if not val:
            return
        if val in (self.sched_filter["values"] or []):
            self.sched_filter_var.set(val)
            self.refresh_schedule_tab()

    def refresh_queue_filters(self):
        """Fill the Queue's 'Show' filter with All accounts + each account."""
        if not hasattr(self, "queue_filters"):
            return
        choices = ["All accounts"] + self.all_account_labels()
        for qf in self.queue_filters:
            qf["values"] = choices
            cur = self.queue_filter_var.get().strip()
            if not cur or cur not in choices:
                self.queue_filter_var.set("All accounts")

    def refresh_groups(self):
        names = self.group_labels()
        for combo in (self.grp_view_combo, self.gpost_group):
            combo["values"] = names
            if names:
                if not combo.get() or combo.get() not in names:
                    combo.current(0)
            else:
                combo.set("")
        self.refresh_group_members()
        self.refresh_group_post_accounts()
        self.refresh_link_group_choices()

    def refresh_group_members(self):
        self.grp_members_list.delete(0, "end")
        g = self.group_by_label(self.grp_view_combo.get().strip())
        if g:
            for a in g["accounts"]:
                self.grp_members_list.insert("end", a)

    def on_group_member_select(self, event=None):
        """Clicking a member also picks it in 'Post to group' below."""
        sel = self.grp_members_list.curselection()
        if not sel:
            return
        label = self.grp_members_list.get(sel[0])
        view_group = self.grp_view_combo.get().strip()
        if view_group and self.gpost_group.get().strip() != view_group:
            self.gpost_group.set(view_group)
            self.refresh_group_post_accounts()
        if label in self.gpost_account["values"]:
            self.gpost_account.set(label)

    def refresh_group_post_accounts(self):
        g = self.group_by_label(self.gpost_group.get().strip())
        members = [a for a in (g["accounts"] if g else [])
                   if a in set(self.all_account_labels())]
        self.gpost_account["values"] = members
        if members:
            if not self.gpost_account.get() or self.gpost_account.get() not in members:
                self.gpost_account.current(0)
        else:
            self.gpost_account.set("")

    def refresh_link_group_choices(self):
        names = ["All accounts"] + self.group_labels()
        for combo, refresh in ((self.link_group, self.refresh_link_accounts),
                               (self.bulk_group, self.refresh_bulk_accounts)):
            cur = combo.get().strip()
            combo["values"] = names
            if not cur or cur not in names:
                combo.current(0)
            refresh()

    def _accounts_for_group_label(self, label):
        g = self.group_by_label(label)
        if g:
            valid = set(self.all_account_labels())
            return [a for a in g["accounts"] if a in valid]
        return self.all_account_labels()

    def refresh_link_accounts(self):
        sel = self.link_group.get().strip() \
            if hasattr(self, "link_group") else ""
        choices = self._accounts_for_group_label(sel)
        self.link_account["values"] = choices
        cur = self.link_account.get().strip()
        if choices and (not cur or cur not in choices):
            self.link_account.current(0)

    def refresh_bulk_accounts(self):
        sel = self.bulk_group.get().strip() \
            if hasattr(self, "bulk_group") else ""
        choices = self._accounts_for_group_label(sel)
        self.bulk_account["values"] = choices
        cur = self.bulk_account.get().strip()
        if choices and (not cur or cur not in choices):
            self.bulk_account.current(0)
        self.autofill_bulk_link()

    def set_bulk_summary(self, text):
        w = self.bulk_summary
        w.configure(state="normal")
        w.delete("1.0", "end")
        w.insert("1.0", text)
        w.configure(state="disabled")

    def copy_bulk_summary(self):
        txt = self.bulk_summary.get("1.0", "end").strip()
        if txt:
            self.root.clipboard_clear()
            self.root.clipboard_append(txt)
            self.status("Summary copied to clipboard. 📋")

    def _dl_group_action(self, combo, action):
        g = self.group_by_label(combo.get().strip())
        if action == "new":
            self.group_dialog()
            return
        if not g:
            messagebox.showinfo(
                "Edit group" if action == "edit" else "Delete group",
                "Select a group first.")
            return
        if action == "edit":
            self.group_dialog(existing=g)
        else:
            if not messagebox.askyesno("Delete group",
                                        f"Delete group '{g['name']}'?"):
                return
            app.save_groups([x for x in app.load_groups()
                             if x["name"] != g["name"]])
            self.refresh_groups()
            self.status(f"Group '{g['name']}' deleted.")

    def link_new_group(self):
        self._dl_group_action(self.link_group, "new")

    def link_edit_group(self):
        self._dl_group_action(self.link_group, "edit")

    def link_delete_group(self):
        self._dl_group_action(self.link_group, "delete")

    def bulk_new_group(self):
        self._dl_group_action(self.bulk_group, "new")

    def bulk_edit_group(self):
        self._dl_group_action(self.bulk_group, "edit")

    def bulk_delete_group(self):
        self._dl_group_action(self.bulk_group, "delete")

    def link_selected_account(self):
        """The account picked in 'Download from a link'."""
        return self.link_account.get().strip()

    def bulk_selected_account(self):
        """The account picked in the Bulk section."""
        return self.bulk_account.get().strip()

    def refresh_attached_board(self):
        """Show the selected account's attached board link (or that
        none is attached) in the line under the link box."""
        try:
            if not hasattr(self, "bulk_attached_var"):
                return
            label = self.bulk_account.get().strip()
            if not label:
                self.bulk_attached_var.set("")
                return
            account = self.resolve_account(label)[0]
            saved = app.get_account_link(account)
            if saved:
                self.bulk_attached_var.set(f"📌 {account} ka board: "
                                           f"{saved}")
            else:
                self.bulk_attached_var.set(
                    f"📌 {account} ka koi board attach nahi hai.")
        except Exception:
            pass

    def autofill_bulk_link(self, force=False):
        """Refill the bulk link box with the link saved for the
        selected account.

        On an explicit account pick (force=True) the attached board
        ALWAYS shows when switching accounts: a stale board from
        another account must never linger, and an autofilled (not
        typed) box is cleared when the new account has no board.
        Re-picking the same account, and automatic refills (group
        change, refresh), never overwrite a link she typed herself.
        """
        try:
            if not force and not self.bulk_save_link.get():
                return
            label = self.bulk_account.get().strip()
            if not label:
                return
            account = self.resolve_account(label)[0]
            saved = app.get_account_link(account)
            cur = self.bulk_link.get().strip()
            autofilled = getattr(self, "_bulk_link_autofilled", "")
            switched = (label != getattr(self, "_bulk_last_account",
                                         ""))
            if force and switched:
                if saved:
                    self.bulk_link.delete(0, "end")
                    self.bulk_link.insert(0, saved)
                    self._bulk_link_autofilled = saved
                elif cur == autofilled:
                    # box holds an old autofill, not her typing —
                    # safe to clear so no wrong board shows
                    self.bulk_link.delete(0, "end")
                    self._bulk_link_autofilled = ""
            elif saved and (not cur or cur == autofilled):
                self.bulk_link.delete(0, "end")
                self.bulk_link.insert(0, saved)
                self._bulk_link_autofilled = saved
            self._bulk_last_account = label
            self.refresh_attached_board()
        except Exception:
            pass

    def add_account(self):
        u = self.acc_user.get().strip().lstrip("@")
        p = self.acc_pass.get()
        if not u or not p:
            messagebox.showwarning("Missing", "Enter a username and password.")
            return
        self._verify_and_save(u, p, on_done=lambda un: (
            self.acc_user.delete(0, "end"),
            self.acc_pass.delete(0, "end")))

    def add_via_session(self):
        """Add an account using a browser session ID (no password needed)."""
        u = self.acc_user.get().strip().lstrip("@")
        sid = self.acc_session.get().strip()
        if not u or not sid:
            messagebox.showwarning(
                "Missing",
                "Enter the username above and paste the session ID.")
            return
        progress = tk.Toplevel(self.root)
        progress.title("Logging in")
        progress.geometry("320x110")
        progress.transient(self.root)
        progress.grab_set()
        ttk.Label(progress, text=f"Logging in @{u}...",
                  font=("Segoe UI", 10)).pack(padx=16, pady=(16, 0))
        ttk.Label(progress, text="Please wait.").pack(padx=16, pady=(4, 0))

        def worker():
            try:
                cl = app.login_by_sessionid(u, sid)
                try:
                    user_id = cl.user_id
                except Exception:
                    user_id = None
            except Exception as e:
                msg = str(e)[:200]
                self.root.after(0, lambda: finish(False, msg))
                return
            self.root.after(0, lambda: finish(True, "", user_id))

        def finish(ok, msg, user_id=None):
            progress.destroy()
            if not ok:
                messagebox.showerror(
                    "Login failed",
                    f"Couldn't log in @{u}.\n{msg}\n\n"
                    "Make sure you copied the full 'sessionid' value "
                    "while logged in as this account in Chrome.")
                return
            accounts = app.load_accounts()
            existing = next((a for a in accounts
                             if a.lower() == u.lower()), None)
            name = existing or u
            was_present = name in accounts
            app.insert_account_ordered(accounts, name, ig_id=user_id)
            app.save_accounts(accounts)
            if user_id is not None:
                app.remember_account(name, ig_id=user_id)
            if not was_present:
                self._restore_groups_for(name)
            # no password to save; session file holds the login
            self.refresh_accounts()
            self.refresh_groups()
            self.acc_user.delete(0, "end")
            self.acc_session.delete(0, "end")
            self.status(f"Account @{name} added via session. ✅")

        threading.Thread(target=worker, daemon=True).start()

    def _ask_main(self, kind, title, prompt):
        """Ask the user something from a worker thread, on the main thread."""
        box = {}
        done = threading.Event()

        def run():
            try:
                if kind == "code":
                    box["v"] = simpledialog.askstring(title, prompt,
                                                      parent=self.root)
                else:
                    messagebox.showinfo(title, prompt, parent=self.root)
                    box["v"] = True
            finally:
                done.set()

        self.root.after(0, run)
        done.wait()
        return box.get("v")

    def _do_login(self, username, password):
        """Log in to Instagram, asking for the 2FA code if needed.

        If Instagram asks for a confirmation code (SMS/email
        challenge), the code is asked right here in the app — no
        browser, no hunting for the account. If Instagram instead
        wants an in-app approval (Bloks/native challenge), she
        approves it in the Instagram app or via the 🌐 Browser button
        in the Login chahiye box, then presses OK here.

        Returns the Instagram user id, or None if it could not be read.
        """
        from instagrapi.exceptions import TwoFactorRequired, ChallengeRequired
        code = ""
        cancelled = {"v": False}

        def ask_challenge_code(user, choice=None):
            try:
                where = choice.name  # "SMS" / "EMAIL"
            except Exception:
                where = "SMS/Email"
            entered = self._ask_main(
                "code", "Confirmation code",
                f"Instagram ne @{username} ke liye confirmation code "
                f"bheja hai ({where}).\nEnter it here:")
            if not entered:
                cancelled["v"] = True
                return ""
            return entered.strip()

        for _ in range(3):
            try:
                cl = app.login_client(username, password,
                                      verification_code=code,
                                      challenge_code_handler=ask_challenge_code)
                try:
                    return cl.user_id
                except Exception:
                    return None
            except TwoFactorRequired:
                code = self._ask_main(
                    "code", "Login code",
                    f"Instagram sent a 6-digit code for @{username}.\n"
                    "Enter it here:")
                if not code:
                    raise RuntimeError("Login cancelled - no code entered.")
            except ChallengeRequired:
                if cancelled["v"]:
                    raise RuntimeError("Login cancelled - no code entered.")
                self._ask_main(
                    "info", "Approve the login",
                    f"Instagram wants you to approve this login for "
                    f"@{username}.\nOpen the Instagram app, approve it — "
                    f"ya Login chahiye box mein 🌐 Browser dabao, wahan "
                    f"confirmation karo — phir OK dabao yahan.")
        raise RuntimeError("Too many login attempts.")

    def _verify_and_save(self, username, password, on_done=None):
        """Log in first (2FA now), and save the account only on success."""
        progress = tk.Toplevel(self.root)
        progress.title("Logging in")
        progress.geometry("320x110")
        progress.transient(self.root)
        progress.grab_set()
        ttk.Label(progress, text=f"Logging in @{username}...",
                  font=("Segoe UI", 10)).pack(padx=16, pady=(16, 0))
        ttk.Label(progress, text="Please wait.").pack(padx=16, pady=(4, 0))

        def worker():
            try:
                user_id = self._do_login(username, password)
            except Exception as e:
                msg = str(e)[:200]
                self.root.after(0, lambda: finish(False, msg))
                return
            self.root.after(0, lambda: finish(True, "", user_id))

        def finish(ok, msg, user_id=None):
            progress.destroy()
            if not ok:
                messagebox.showerror(
                    "Login failed",
                    f"Couldn't log in @{username}.\n{msg}\n\n"
                    "The account was NOT added.")
                return
            accounts = app.load_accounts()
            existing = next((a for a in accounts
                             if a.lower() == username.lower()), None)
            name = existing or username
            was_present = name in accounts
            app.insert_account_ordered(accounts, name, ig_id=user_id)
            app.save_accounts(accounts)
            if user_id is not None:
                app.remember_account(name, ig_id=user_id)
            if not was_present:
                self._restore_groups_for(name)
            pw = app.load_passwords()
            pw[name] = password
            app.save_passwords(pw)
            self.refresh_accounts()
            self.refresh_groups()
            self.status(f"Account @{name} logged in and added.")
            if on_done:
                on_done(name)

        threading.Thread(target=worker, daemon=True).start()

    def remove_account(self):
        u = self.selected_account()
        if not u:
            messagebox.showinfo("Remove", "Select an account first.")
            return
        if not messagebox.askyesno("Remove", f"Remove @{u}?"):
            return
        accounts = app.load_accounts()
        if u in accounts:
            # remember slot + groups so re-adding restores them
            groups = [g["name"] for g in app.load_groups()
                      if u in g.get("accounts", [])]
            app.remember_account(u, position=accounts.index(u), groups=groups)
        app.save_accounts([a for a in accounts if a != u])
        pw = app.load_passwords()
        pw.pop(u, None)
        app.save_passwords(pw)
        # drop the removed account from any groups
        groups = app.load_groups()
        changed = False
        for g in groups:
            if u in g["accounts"]:
                g["accounts"] = [a for a in g["accounts"] if a != u]
                changed = True
        if changed:
            app.save_groups(groups)
        self.refresh_accounts()
        self.refresh_groups()
        self.status(f"Account @{u} removed. Re-adding it restores its old position.")

    def logout_account(self):
        """Disconnect the session only — entry, order and posts stay."""
        u = self.selected_account()
        if not u:
            messagebox.showinfo("Logout", "Select an account first.")
            return
        app.logout_account(u)
        self.refresh_accounts()
        self._select_account(u)
        self.status(f"@{u} logged out — entry, order and posts stay. "
                    "Press 🔑 Login to reconnect.")

    def relogin_account(self):
        """One-tap re-login for the selected account, in its old slot."""
        u = self.selected_account()
        if not u:
            messagebox.showinfo("Login", "Select an account first.")
            return
        pw = app.load_passwords().get(u, "")
        sid = self.acc_session.get().strip()
        if pw:
            self.acc_user.delete(0, "end")
            self.acc_user.insert(0, u)
            self.acc_pass.delete(0, "end")
            self.acc_pass.insert(0, pw)
            self.add_account()
        elif sid:
            self.acc_user.delete(0, "end")
            self.acc_user.insert(0, u)
            self.add_via_session()
        else:
            messagebox.showinfo(
                "Login",
                f"@{u} has no saved password. Type its password above, "
                "or paste its Session ID below, then press Login again.")

    # ---------------- auto-update ----------------
    def _update_enabled(self):
        try:
            return bool(app.load_update_settings().get("enabled", True))
        except Exception:
            return True

    def _save_update_toggle(self):
        try:
            app.save_update_settings(
                {"enabled": bool(self.auto_update_var.get())})
        except Exception:
            pass

    def _update_bundle_dir(self):
        return Path(__file__).resolve().parent

    def manual_update_check(self):
        self.status("Update check ho raha hai…")
        threading.Thread(target=lambda: self.check_for_updates(manual=True),
                         daemon=True).start()

    def check_for_updates(self, manual=False):
        """Fetch version.json; if a newer build exists, download, verify
        and apply it to the running copy. The new code loads on the next
        launch. Never touches data/. Silent on failure unless manual."""
        import tempfile
        import urllib.request
        try:
            req = urllib.request.Request(
                UPDATE_VERSION_URL,
                headers={"User-Agent": "InstaUploader"})
            with urllib.request.urlopen(req, timeout=15) as r:
                info = json.loads(r.read().decode("utf-8"))
            remote_build = int(info.get("build", 0))
            marker = info.get("marker", "")
            pack_url = info.get("pack", "")
            if not pack_url or not marker or remote_build <= UPDATE_BUILD:
                if manual:
                    self.root.after(0, lambda: [
                        self.status("App latest hai. ✅"),
                        messagebox.showinfo("Update",
                                            "App latest hai. ✅")])
                return
            self.root.after(0, lambda: self.status(
                f"Naya update mil gaya ({marker}) — download ho raha hai…"))
            tmpdir = tempfile.mkdtemp()
            pack_path = os.path.join(tmpdir, "update.zip")
            req2 = urllib.request.Request(
                pack_url, headers={"User-Agent": "InstaUploader"})
            with urllib.request.urlopen(req2, timeout=180) as r, \
                    open(pack_path, "wb") as f:
                while True:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
            if not verify_update_pack(pack_path, marker):
                raise RuntimeError(
                    "Update pack verify nahi hua — is liye lagaya nahi.")
            apply_update_pack(pack_path, self._update_bundle_dir())
            msg = (f"Update lag gaya ({marker}) — naya code agle launch "
                   f"par chale ga. App band kar ke dobara kholein.")
            self.root.after(0, lambda: [
                self.status(msg),
                messagebox.showinfo("Update", msg)])
        except Exception as e:
            if manual:
                err = str(e)[:200]
                self.root.after(0, lambda: [
                    self.status("Update check nahi ho saka."),
                    messagebox.showwarning(
                        "Update", f"Update check nahi ho saka: {err}")])

    def move_account(self, delta):
        """Move the selected account one slot up (-1) or down (+1)."""
        u = self.selected_account()
        if not u:
            messagebox.showinfo("Move", "Select an account first.")
            return
        accounts = app.load_accounts()
        if u not in accounts:
            return
        idx = accounts.index(u)
        new = idx + delta
        if new < 0 or new >= len(accounts):
            self.status(f"@{u} is already at the "
                        f"{'top' if delta < 0 else 'bottom'}.")
            return
        accounts[idx], accounts[new] = accounts[new], accounts[idx]
        app.save_accounts(accounts)
        self.refresh_accounts()
        self.refresh_groups()
        self._select_account(u)
        self.status(f"@{u} moved to position {new + 1}.")

    def _restore_groups_for(self, username):
        """Put a freshly (re-)added account back into its old groups."""
        names = app.restore_account_groups(username)
        if not names:
            return
        groups = app.load_groups()
        changed = False
        for g in groups:
            if g["name"] in names and username not in g["accounts"]:
                g["accounts"].append(username)
                changed = True
        if changed:
            app.save_groups(groups)

    # ---------------- account groups ----------------
    def group_dialog(self, existing=None):
        top = tk.Toplevel(self.root)
        top.title("Edit group" if existing else "New group")
        top.geometry("420x580")
        top.transient(self.root)
        top.grab_set()
        ttk.Label(top, text="Group name:",
                  font=("Segoe UI", 10)).pack(anchor="w", padx=12, pady=(12, 0))
        name_entry = ttk.Entry(top, font=("Segoe UI", 10))
        name_entry.pack(fill="x", padx=12, pady=(4, 0))
        ttk.Label(top, text="Tick the accounts for this group:",
                  font=("Segoe UI", 10)).pack(anchor="w", padx=12, pady=(10, 0))
        # scrollable checkbox list
        cbox = ttk.Frame(top)
        cbox.pack(fill="both", expand=True, padx=12, pady=(4, 0))
        canvas = tk.Canvas(cbox, height=220, highlightthickness=0)
        vsb = ttk.Scrollbar(cbox, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        box = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=box, anchor="nw")
        box.bind("<Configure>",
                 lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        # mouse wheel scrolls the list
        canvas.bind("<MouseWheel>",
                    lambda e: canvas.yview_scroll(-1 if e.delta > 0 else 1,
                                                  "units"))
        box.bind("<MouseWheel>",
                 lambda e: canvas.yview_scroll(-1 if e.delta > 0 else 1,
                                               "units"))
        choices = self.all_account_labels()
        selected = set(existing["accounts"]) if existing else set()
        ticked = []
        for label in choices:
            v = tk.BooleanVar(value=label in selected)
            ticked.append((label, v))
            cb = ttk.Checkbutton(box, text=label, variable=v)
            cb.pack(anchor="w", pady=1)
            cb.bind("<MouseWheel>",
                    lambda e: canvas.yview_scroll(-1 if e.delta > 0 else 1,
                                                  "units"))

        # quick-add a brand-new account straight into this group
        qa = ttk.LabelFrame(top, text="Add a new account to this group",
                            padding=6)
        qa.pack(fill="x", padx=12, pady=(4, 0))
        qr = ttk.Frame(qa)
        qr.pack(fill="x")
        ttk.Label(qr, text="Username:").pack(side="left")
        quser = ttk.Entry(qr, width=12)
        quser.pack(side="left", padx=(4, 8))
        ttk.Label(qr, text="Password:").pack(side="left")
        qpass = ttk.Entry(qr, width=12, show="*")
        qpass.pack(side="left", padx=(4, 0))
        ttk.Button(qa, text="+ Add", command=lambda: quick_add()).pack(
            anchor="e", pady=(6, 0))

        def quick_add():
            u = quser.get().strip().lstrip("@")
            p = qpass.get()
            if not u or not p:
                messagebox.showwarning("Missing",
                                       "Enter a username and password.")
                return

            def tick_in(username):
                if not any(label == username for label, _ in ticked):
                    v = tk.BooleanVar(value=True)
                    ticked.append((username, v))
                    cb = ttk.Checkbutton(box, text=username, variable=v)
                    cb.pack(anchor="w", pady=1)
                    cb.bind("<MouseWheel>",
                            lambda e: canvas.yview_scroll(
                                -1 if e.delta > 0 else 1, "units"))
                else:
                    for label, v in ticked:
                        if label == username:
                            v.set(True)
                quser.delete(0, "end")
                qpass.delete(0, "end")
                self.status(f"Account @{username} logged in, "
                            "ticked into the group.")

            self._verify_and_save(u, p, on_done=tick_in)

        def save():
            name = name_entry.get().strip()
            if not name:
                messagebox.showwarning("Missing", "Give the group a name.")
                return
            if name.startswith("👥"):
                messagebox.showwarning("Invalid",
                                       "Group name can't start with 👥.")
                return
            picked = [label for label, v in ticked if v.get()]
            groups = app.load_groups()
            if existing:
                for g in groups:
                    if g["name"] == existing["name"]:
                        g["name"] = name
                        g["accounts"] = picked
                        break
            else:
                if any(g["name"].lower() == name.lower() for g in groups):
                    messagebox.showwarning("Exists",
                                           "A group with this name already exists.")
                    return
                groups.append({"name": name, "accounts": picked})
            app.save_groups(groups)
            self.refresh_groups()
            top.destroy()
            self.status(f"Group '{name}' saved ({len(picked)} accounts).")

        if existing:
            name_entry.insert(0, existing["name"])
        ttk.Button(top, text="Save group", style="Accent.TButton",
                   command=save).pack(pady=12)

    def selected_group(self):
        return self.group_by_label(self.grp_view_combo.get().strip())

    def new_group(self):
        self.group_dialog()

    def edit_group(self):
        g = self.selected_group()
        if not g:
            messagebox.showinfo("Edit group", "Select a group first.")
            return
        self.group_dialog(existing=g)

    def delete_group(self):
        g = self.selected_group()
        if not g:
            messagebox.showinfo("Delete group", "Select a group first.")
            return
        if not messagebox.askyesno("Delete group",
                                    f"Delete group '{g['name']}'?"):
            return
        app.save_groups([x for x in app.load_groups()
                         if x["name"] != g["name"]])
        self.refresh_groups()
        self.status(f"Group '{g['name']}' deleted.")

    def add_group_members(self):
        g = self.selected_group()
        if not g:
            messagebox.showinfo("Add accounts", "Select a group first.")
            return
        self.group_dialog(existing=g)

    def remove_group_member(self):
        g = self.selected_group()
        if not g:
            messagebox.showinfo("Remove account", "Select a group first.")
            return
        sel = self.grp_members_list.curselection()
        if not sel:
            messagebox.showinfo("Remove account",
                                "Select an account in the list first.")
            return
        label = self.grp_members_list.get(sel[0])
        if not messagebox.askyesno(
                "Remove account",
                f"Remove '{label}' from group '{g['name']}'?"):
            return
        groups = app.load_groups()
        for x in groups:
            if x["name"] == g["name"]:
                x["accounts"] = [a for a in x.get("accounts", [])
                                 if a != label]
        app.save_groups(groups)
        self.refresh_groups()
        self.status(f"Removed '{label}' from '{g['name']}'.")

    # ---------------- group posting ----------------
    def gchoose_file(self):
        f = filedialog.askopenfilename(
            title="Choose a photo or video",
            filetypes=[("Media", "*.jpg *.jpeg *.png *.mp4 *.mov"),
                       ("Photos", "*.jpg *.jpeg *.png"),
                       ("Videos", "*.mp4 *.mov"),
                       ("All files", "*.*")])
        if f:
            self.gchosen_file = f
            self.gfile_lbl.config(text=Path(f).name, font=("Segoe UI", 9))

    def add_group_post(self):
        raw_account = self.gpost_account.get().strip()
        if not raw_account:
            messagebox.showwarning("Missing",
                                   "Pick a group and an account first.")
            return
        if raw_account not in set(self.all_account_labels()):
            messagebox.showwarning("Missing",
                                   "This account was removed — pick another.")
            return
        self.queue_single_post(raw_account, getattr(self, "gchosen_file", None),
                               self.gcaption_text.get("1.0", "end").strip(),
                               self.gwhen_var.get(),
                               self.gsched_entry.get())
        self.gchosen_file = None
        self.gfile_lbl.config(text="no file chosen",
                              font=("Segoe UI", 9, "italic"))
        self.gcaption_text.delete("1.0", "end")

    def add_group_post_all(self):
        """Queue the same post for EVERY account in the chosen group."""
        gname = self.gpost_group.get().strip()
        if not gname:
            messagebox.showwarning("Missing", "Pick a group first.")
            return
        groups = app.load_groups()
        grp = next((g for g in groups if g.get("name") == gname), None)
        if not grp or not grp.get("accounts"):
            messagebox.showwarning("Empty",
                                   f"'{gname}' has no accounts in it.")
            return
        if not getattr(self, "gchosen_file", None):
            messagebox.showwarning("Missing", "Choose a photo/video first.")
            return
        members = [a for a in grp["accounts"]
                   if a in set(self.all_account_labels())]
        if not members:
            messagebox.showwarning("Missing",
                                   "No valid accounts left in this group.")
            return
        if not messagebox.askyesno(
                "Post to all?",
                f"Queue this post for all {len(members)} accounts in "
                f"'{gname}'?"):
            return
        for raw_account in members:
            self.queue_single_post(
                raw_account, getattr(self, "gchosen_file", None),
                self.gcaption_text.get("1.0", "end").strip(),
                self.gwhen_var.get(), self.gsched_entry.get())
        self.gchosen_file = None
        self.gfile_lbl.config(text="no file chosen",
                              font=("Segoe UI", 9, "italic"))
        self.gcaption_text.delete("1.0", "end")
        self.status(f"Queued for all {len(members)} accounts in '{gname}' ✅")

    # ---------------- queue ----------------
    def choose_file(self):
        f = filedialog.askopenfilename(
            title="Choose a photo or video",
            filetypes=[("Media", "*.jpg *.jpeg *.png *.mp4 *.mov"),
                       ("Photos", "*.jpg *.jpeg *.png"),
                       ("Videos", "*.mp4 *.mov"),
                       ("All files", "*.*")])
        if f:
            self.chosen_file = f
            self.carousel_files = []  # last pick wins, never both
            self.carousel_src = ""
            self.file_lbl.config(text=Path(f).name, font=("Segoe UI", 9))
            self._refresh_car_summary()

    def _refresh_car_summary(self):
        """Show (or hide) the live carousel summary under the pick
        row. Called on every pick change and on every Post now /
        Schedule / Story / time change, so the line always states
        what the picked carousel will actually do."""
        if not hasattr(self, "car_sum_lbl"):
            return
        if not self.carousel_files:
            self.car_sum_lbl.pack_forget()
            return
        when = self.when_var.get()
        if when == "later":
            t = self.sched_entry.get().strip()
            when_txt = f"Schedule: {t}" if t else "Schedule: time nahi chuna"
        else:
            when_txt = "Post now"
        story_txt = ("Story: lagegi ✅" if self.story_var.get()
                     else "Story: nahi lagegi")
        src = "zip se" if self.carousel_src == "zip" else "photos se"
        self.car_sum_lbl.config(
            text=f"🎠 Carousel: {len(self.carousel_files)} photos "
                 f"({src}) — {when_txt} • {story_txt}")
        self.car_sum_lbl.pack(side="left")

    def choose_carousel(self):
        """Pick 2–20 photos for ONE carousel post (photos only — a
        video can never join a carousel)."""
        fs = filedialog.askopenfilenames(
            title="Carousel photos chunein (kam se kam 2)",
            filetypes=[("Photos", "*.jpg *.jpeg *.png *.webp"),
                       ("All files", "*.*")])
        if not fs:
            return
        bad = [f for f in fs
               if Path(f).suffix.lower() not in app.IMAGE_EXTS]
        if bad:
            messagebox.showwarning(
                "Carousel",
                "Carousel mein sirf photos hoti hain — video nahi:\n"
                + ", ".join(Path(f).name for f in bad[:3])
                + "\n\nSirf photos chunein, phir dobara try karein.")
            return
        if len(fs) < 2:
            messagebox.showwarning(
                "Carousel",
                "Carousel ke liye kam se kam 2 photos chunein.")
            return
        if len(fs) > 20:
            messagebox.showwarning(
                "Carousel",
                "Instagram carousel mein zyada se zyada 20 photos "
                "hoti hain — pehli 20 rakh li hain.")
            fs = fs[:20]
        self.carousel_files = list(fs)
        self.carousel_src = "photos"
        self.chosen_file = None  # last pick wins, never both
        self.file_lbl.config(text=f"🎠 Carousel: {len(fs)} photos",
                             font=("Segoe UI", 9, "bold"))
        self._refresh_car_summary()

    def choose_carousel_zip(self):
        """Pick a zip of photos for ONE carousel post, separate from
        the bulk zip dialog: the zip's photos become the form's
        carousel pick, so the caption box and the Post now / Schedule
        controls below work exactly like a direct carousel pick.
        No bulk dialog, no ticking, no stagger."""
        z = filedialog.askopenfilename(
            parent=self.root,
            title="Carousel wali zip chunein",
            filetypes=[("Zip files", "*.zip"), ("All files", "*.*")])
        if not z:
            return
        try:
            media = app.extract_zip_media(z)
        except ValueError as e:
            messagebox.showwarning("Zip file", str(e), parent=self.root)
            return
        except Exception as e:
            messagebox.showerror("Zip file",
                                 f"Could not read the zip:\n{e}",
                                 parent=self.root)
            return
        photos = [m for m in media
                  if m.suffix.lower() in app.IMAGE_EXTS]
        bad = [m for m in media
               if m.suffix.lower() not in app.IMAGE_EXTS]
        if bad:
            messagebox.showwarning(
                "Carousel",
                "Carousel mein sirf photos hoti hain — video nahi:\n"
                + ", ".join(m.name for m in bad[:3])
                + "\n\nSirf photos wali zip chunein, phir dobara "
                  "try karein.")
            return
        if len(photos) < 2:
            messagebox.showwarning(
                "Carousel",
                "Carousel ke liye zip mein kam se kam 2 photos hon.")
            return
        if len(photos) > 20:
            messagebox.showwarning(
                "Carousel",
                "Instagram carousel mein zyada se zyada 20 photos "
                "hoti hain — pehli 20 rakh li hain.")
            photos = photos[:20]
        self.carousel_files = [str(m) for m in photos]
        self.carousel_src = "zip"
        self.chosen_file = None  # last pick wins, never both
        self.file_lbl.config(text=f"🎠 Carousel: {len(photos)} photos "
                                  "(zip se)",
                             font=("Segoe UI", 9, "bold"))
        self._refresh_car_summary()
        # Caption bonus: if the box is empty and the zip carries
        # captions.txt, prefill its first caption — never overwrite
        # a caption she already typed.
        if not self.caption_text.get("1.0", "end").strip():
            try:
                text = app.read_zip_captions(z)
                caps = app.split_captions(text) if text else []
                if caps:
                    self.caption_text.insert("1.0", caps[0])
            except Exception:
                pass

    def choose_zip(self):
        """Pick a zip of photos/videos: 1 file -> chosen directly,
        more files -> pick which ones to queue as separate posts."""
        z = filedialog.askopenfilename(
            parent=self.root,
            title="Choose a zip file of photos/videos",
            filetypes=[("Zip files", "*.zip"), ("All files", "*.*")])
        if not z:
            return
        try:
            media = app.extract_zip_media(z)
        except ValueError as e:
            messagebox.showwarning("Zip file", str(e), parent=self.root)
            return
        except Exception as e:
            messagebox.showerror("Zip file",
                                 f"Could not read the zip:\n{e}",
                                 parent=self.root)
            return
        if len(media) == 1:
            self.chosen_file = str(media[0])
            self.carousel_files = []  # last pick wins, never both
            self.carousel_src = ""
            self.file_lbl.config(text=media[0].name, font=("Segoe UI", 9))
            self._refresh_car_summary()
            self.status(f"1 file from zip: {media[0].name}")
        else:
            try:
                self.zip_media_dialog(z, media)
            except Exception as e:
                messagebox.showerror(
                    "Zip file",
                    f"Could not open the zip list:\n{e}\n\n"
                    "Iska screenshot bhej dein.",
                    parent=self.root)

    def recover_dialog(self):
        """Re-queue media that was queued before but never posted
        (e.g. after the queue list was lost). Candidates come from
        app.recoverable_uploads(); the tick-list mirrors the zip
        dialog, including its in-dialog schedule controls."""
        account = self.post_account.get().strip()
        try:
            acct_name = self.resolve_account(account)[0]
        except Exception:
            acct_name = account
        try:
            items = app.recoverable_uploads(acct_name)
        except Exception as e:
            messagebox.showerror(
                "Recover lost posts",
                f"List nahi ban saki:\n{e}", parent=self.root)
            return
        if not items:
            messagebox.showinfo(
                "Recover lost posts",
                "Uploads mein koi queue-wali photo/video nahi mili.",
                parent=self.root)
            return
        top = tk.Toplevel(self.root)
        top.title("♻️ Recover lost posts")
        top.geometry("680x500")
        top.transient(self.root)
        top.grab_set()
        ttk.Label(
            top,
            text=(f"{len(items)} photos/videos mili hain jo kabhi queue "
                  "mein lagi thi.\n"
                  f"Ye account pe dobara queue hongi: {account}\n"
                  "✅ ke saath wo account likha hai jahan video pehle "
                  "post hui thi.\n"
                  "Jo is account pe post hui thi wo unticked hai — "
                  "chaho to tick kar sakti ho.\n"
                  "Photo ke saath 👁 dabao to wo picture dikhegi."),
            font=("Segoe UI", 10)).pack(padx=12, pady=(12, 4))
        # Counts line: how many photos vs videos this list holds.
        _n_rimgs = sum(1 for _o, _p, *_r in items
                       if Path(_p).suffix.lower() in app.IMAGE_EXTS)
        _n_rvids = sum(1 for _o, _p, *_r in items
                       if Path(_p).suffix.lower() in app.VIDEO_EXTS)
        ttk.Label(
            top,
            text=f"📊 Is list mein: {_n_rimgs} photos | {_n_rvids} "
                 f"videos | {len(items)} total",
            font=("Segoe UI", 10, "bold")).pack(padx=12, anchor="w")
        selbar = ttk.Frame(top)
        selbar.pack(fill="x", padx=12, pady=(2, 0))
        count_lbl = ttk.Label(selbar, text="",
                              font=("Segoe UI", 10, "bold"))
        count_lbl.pack(side="left")
        cbox = ttk.Frame(top)
        cbox.pack(fill="both", expand=True, padx=12, pady=(4, 0))
        canvas = tk.Canvas(cbox, height=240, highlightthickness=0)
        vsb = ttk.Scrollbar(cbox, orient="vertical",
                            command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        box = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=box, anchor="nw")
        box.bind("<Configure>",
                 lambda e: canvas.configure(
                     scrollregion=canvas.bbox("all")))

        def wheel(e):
            canvas.yview_scroll(-1 if e.delta > 0 else 1, "units")
        canvas.bind("<MouseWheel>", wheel)
        box.bind("<MouseWheel>", wheel)

        rows = []  # dicts: frame, path, var, cap, here, ever, visible

        def refresh_count():
            vis = [r for r in rows if r["visible"]]
            k = sum(1 for r in vis if r["var"].get())
            hidden = len(rows) - len(vis)
            if not vis:
                count_lbl.config(
                    text="Koi unposted post nahi mili — 'Post ho chuki "
                         "bhi dikhao' wala tick lagao agar purani "
                         "dobara lagani hai")
            else:
                extra = (f"  ({hidden} post-ho-chuki chhupi hain)"
                         if hidden else "")
                count_lbl.config(text=f"{k} of {len(vis)} ticked{extra}")

        def toggle_row(v):
            v.set(not v.get())
            refresh_count()

        for orig, p, when, note, posted_here, ever_posted in items:
            r = ttk.Frame(box)
            r.pack(fill="x", pady=2)
            v = tk.BooleanVar(value=not posted_here)
            cb = ttk.Checkbutton(r, variable=v, command=refresh_count)
            cb.pack(side="left")
            cb.bind("<MouseWheel>", wheel)
            date_s = when.strftime("%d %b, %I:%M %p") if when else ""
            lbl_text = f"{orig}   ({date_s})"
            if note:
                lbl_text += f"   ✅ posted → {note}"
            lbl = ttk.Label(r, text=lbl_text,
                            font=("Segoe UI", 10), width=60, anchor="w")
            lbl.pack(side="left", padx=(2, 6))
            lbl.bind("<Button-1>", lambda e, v=v: toggle_row(v))
            if Path(p).suffix.lower() in app.IMAGE_EXTS:
                ttk.Button(
                    r, text="👁", width=3,
                    command=lambda pp=p: self.preview_image(
                        top, pp, warn=rec_warn)).pack(side="left",
                                                      padx=(4, 0))
            cap = ttk.Entry(r, font=("Segoe UI", 10))
            cap.pack(side="left", fill="x", expand=True)
            cap.bind("<MouseWheel>", wheel)
            rows.append({"frame": r, "path": p, "var": v, "cap": cap,
                         "here": posted_here, "ever": ever_posted,
                         "visible": True})

        def set_all(val):
            for r in rows:
                if r["visible"]:
                    r["var"].set(val)
            refresh_count()
        ttk.Button(selbar, text="Select all",
                   command=lambda: set_all(True)).pack(side="right")
        ttk.Button(selbar, text="Clear",
                   command=lambda: set_all(False)).pack(side="right",
                                                        padx=(0, 6))

        # default view: only media that never posted anywhere — the
        # genuinely lost posts. Already-posted media appears only on
        # request (for deliberate re-posts to another account).
        show_posted = tk.BooleanVar(value=False)
        filbar = ttk.Frame(top)
        filbar.pack(fill="x", padx=12, pady=(4, 0), before=cbox)

        def apply_filter():
            sp = show_posted.get()
            for r in rows:
                show = sp or not r["ever"]
                r["visible"] = show
                if show:
                    r["frame"].pack(fill="x", pady=2)
                else:
                    r["frame"].pack_forget()
            refresh_count()
        ttk.Checkbutton(
            filbar,
            text="Post ho chuki bhi dikhao (purani dobara lagane ke liye)",
            variable=show_posted, command=apply_filter).pack(side="left")
        apply_filter()

        # schedule controls INSIDE the dialog (same reason as the zip
        # dialog: the main tab's sit behind this modal)
        sched_bar = ttk.Frame(top)
        sched_bar.pack(fill="x", padx=12, pady=(6, 0))
        zwhen = tk.StringVar(value=self.when_var.get())
        ttk.Radiobutton(sched_bar, text="Post now", variable=zwhen,
                        value="now").pack(side="left")
        ttk.Radiobutton(sched_bar, text="Schedule:", variable=zwhen,
                        value="later").pack(side="left", padx=(10, 4))
        zsched = ttk.Entry(sched_bar, width=16, font=("Segoe UI", 10))
        zsched.pack(side="left")
        zsched.insert(0, self.sched_entry.get())
        ttk.Button(sched_bar, text="📅", width=3,
                   command=lambda: DateTimePicker(top, zsched,
                                                  self.theme)).pack(
                       side="left", padx=(4, 0))
        ttk.Label(sched_bar, text="every",
                  font=("Segoe UI", 9)).pack(side="left", padx=(8, 2))
        zhours = ttk.Entry(sched_bar, width=4, font=("Segoe UI", 10))
        zhours.pack(side="left")
        zhours.insert(0, self.hours_entry.get())
        ttk.Label(sched_bar, text="hours apart",
                  font=("Segoe UI", 9)).pack(side="left", padx=(2, 0))
        zstory = tk.BooleanVar(value=self.story_var.get())
        ttk.Checkbutton(sched_bar, text="📱 Story too",
                        variable=zstory).pack(side="left", padx=(12, 0))

        def rec_warn(title, msg):
            try:
                top.grab_release()
            except Exception:
                pass
            messagebox.showwarning(title, msg)
            try:
                top.grab_set()
            except Exception:
                pass

        def do_queue():
            try:
                _do_queue_inner()
            except Exception as e:
                import traceback
                err = traceback.format_exc()
                try:
                    (app.DATA / "recover_error.log").write_text(
                        err, encoding="utf-8")
                except Exception:
                    pass
                try:
                    top.grab_release()
                except Exception:
                    pass
                messagebox.showerror(
                    "Recover error",
                    "Kuch garbar hui hai. Is message ka screenshot "
                    "bhej dein taake theek kar sakun:\n\n"
                    f"{type(e).__name__}: {e}",
                    parent=self.root)
                try:
                    if top.winfo_exists():
                        top.grab_set()
                except Exception:
                    pass

        def _do_queue_inner():
            chosen = [(r["path"], r["cap"]) for r in rows
                      if r["visible"] and r["var"].get()]
            if not chosen:
                rec_warn("Recover lost posts",
                         "Tick at least one file first.")
                return
            if account not in set(self.all_account_labels()):
                rec_warn("Missing", "Add an account first.")
                return
            # capture plain values NOW — the widgets die with the dialog
            when = zwhen.get()
            sched_text = zsched.get()
            hours_text = zhours.get()
            to_story = zstory.get()
            try:
                gap = int((hours_text or "0").strip() or "0")
            except ValueError:
                gap = 0
            base = None
            if gap > 0:
                if when == "later":
                    base = parse_datetime(sched_text)
                    if not base:
                        rec_warn("Missing",
                                 "Enter a date and time like "
                                 "2026-10-17 10:30.")
                        return
                else:
                    base = datetime.now()
            if chosen and all(app.day_number(p.name) is not None
                              for p, _c in chosen):
                chosen.sort(key=lambda t: app.day_number(t[0].name))
            n, failed = 0, []
            for i, (p, cap) in enumerate(chosen):
                w, s = when, sched_text
                if gap > 0:
                    dt = base + timedelta(hours=gap * i)
                    w, s = "later", dt.strftime("%Y-%m-%d %H:%M")
                ok, err = self.make_queue_job(account, str(p),
                                              cap.get().strip(), w, s,
                                              to_story, kind="recover")
                if ok:
                    n += 1
                else:
                    failed.append(f"{p.name}: {err}")
            top.destroy()
            if n:
                self.when_var.set(when)
                self.sched_entry.delete(0, "end")
                self.sched_entry.insert(0, sched_text)
                self.hours_entry.delete(0, "end")
                self.hours_entry.insert(0, hours_text)
                self.story_var.set(to_story)
                try:
                    self.refresh_queue()
                except Exception:
                    pass
                try:
                    self.refresh_schedule_tab()
                except Exception:
                    pass
            if failed:
                messagebox.showwarning(
                    "Recover lost posts",
                    f"{n} post(s) queued, {len(failed)} failed:\n" +
                    "\n".join(failed[:5]), parent=self.root)
            if n:
                extra = f" — every {gap} hours" if gap > 0 else ""
                self.status(f"Recovered {n} post(s) into the queue "
                            f"♻️{extra}")
        br = ttk.Frame(top)
        br.pack(fill="x", padx=12, pady=(8, 12))
        ttk.Button(br, text="Queue selected as separate posts",
                   style="Accent.TButton",
                   command=do_queue).pack(side="right")
        ttk.Button(br, text="Cancel",
                   command=top.destroy).pack(side="right", padx=(0, 8))

    def preview_image(self, parent, path, warn=None):
        """Show an image in a small window (PIL); if that fails, open
        it in the OS viewer; if that fails too, warn with the path."""
        try:
            from PIL import Image, ImageTk
            im = Image.open(path)
            im.thumbnail((520, 520))
            pv = tk.Toplevel(parent)
            pv.title("Preview — " + Path(path).name)
            pv.transient(parent)
            tkimg = ImageTk.PhotoImage(im)
            ttk.Label(pv, image=tkimg).pack(padx=10, pady=10)
            ttk.Label(pv, text=Path(path).name,
                      font=("Segoe UI", 9)).pack(pady=(0, 10))
            pv._img = tkimg  # keep a reference
        except Exception:
            try:
                os.startfile(str(path))
            except Exception:
                if warn:
                    warn("Preview",
                         "Picture nahi khul saki:\n" + str(path))

    def zip_media_dialog(self, zip_path, media):
        """Tick files from the zip; each gets its own caption, then all
        selected are queued as separate posts (optionally hours apart)."""
        top = tk.Toplevel(self.root)
        top.title("Zip contents")
        top.geometry("620x480")
        top.transient(self.root)
        top.grab_set()
        ttk.Label(
            top,
            text=(f"{len(media)} photos/videos found in "
                  f"{Path(zip_path).name}\n"
                  "Tick the ones to queue — each becomes a separate post.\n"
                  "Edit the caption of any file below before queueing.\n"
                  "🖼 Jis photo ka naam kisi video jaisa ho, wo us video "
                  "ki cover hai — naam na mile to tartib se lag jayegi "
                  "(pehli video ko pehli photo, dusri ko dusri).\n"
                  "Har video ke saath 🖼 Cover… button se alag cover "
                  "bhi laga sakti hain.\n"
                  "Cover ke naam pe click karein to wo picture dikhegi.\n"
                  "(Tip: click a file's name to tick/untick it.)\n"
                  "Kisi row ka tick hatayengi to uska cover aur "
                  "caption bhi hat jayega — dobara tick par Covers "
                  "zip… / Captions zip… se wapas lagayein."),
            font=("Segoe UI", 10)).pack(padx=12, pady=(12, 4))
        cap_note = ttk.Label(top, text="", font=("Segoe UI", 9))
        cap_note.pack(padx=12, anchor="w")
        # Counts line: so she can see at a glance how many videos,
        # cover photos and captions this zip actually holds.
        counts_lbl = ttk.Label(top, text="", font=("Segoe UI", 10, "bold"))
        counts_lbl.pack(padx=12, anchor="w")
        # select-all / clear + live count, so the tick state is unmistakable
        selbar = ttk.Frame(top)
        selbar.pack(fill="x", padx=12, pady=(2, 0))
        count_lbl = ttk.Label(selbar, text="", font=("Segoe UI", 10, "bold"))
        count_lbl.pack(side="left")
        # scrollable rows: tick + filename + own caption box
        cbox = ttk.Frame(top)
        cbox.pack(fill="both", expand=True, padx=12, pady=(4, 0))
        canvas = tk.Canvas(cbox, height=240, highlightthickness=0)
        vsb = ttk.Scrollbar(cbox, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        box = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=box, anchor="nw")
        box.bind("<Configure>",
                 lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        def wheel(e):
            canvas.yview_scroll(-1 if e.delta > 0 else 1, "units")
        canvas.bind("<MouseWheel>", wheel)
        box.bind("<MouseWheel>", wheel)

        shared_caption = self.caption_text.get("1.0", "end").strip()
        # A photo whose name matches a video's name is that video's
        # cover (dress1.jpg covers dress1.mp4). Cover photos start
        # unticked — they are covers, not separate posts (she can
        # still tick one to post it as a photo too).
        by_stem = {}
        for p in media:
            by_stem.setdefault(p.stem.lower(), []).append(p)
        cover_of = {}
        for p in media:
            if p.suffix.lower() in app.VIDEO_EXTS:
                for q in by_stem.get(p.stem.lower(), []):
                    if q.suffix.lower() in app.IMAGE_EXTS:
                        cover_of[p] = q
                        break
        # Day-number pass: a video and a cover sharing a day number
        # belong together even when their names differ otherwise
        # ("Day 01 FIXED.mp4" + "Day 01 cover.jpg"). Runs after stem
        # matches, so an exact name match still wins.
        _day_imgs = {}
        for q in media:
            if q.suffix.lower() in app.IMAGE_EXTS:
                d = app.day_number(q.name)
                if d is not None:
                    _day_imgs.setdefault(d, q)
        for p in media:
            if p.suffix.lower() in app.VIDEO_EXTS and p not in cover_of:
                d = app.day_number(p.name)
                if d is not None and d in _day_imgs:
                    cover_of[p] = _day_imgs[d]
        # Leftovers pair up in name order: 1st unmatched video gets
        # the 1st unmatched photo, 2nd gets the 2nd, and so on — so a
        # zip of 30 videos + 30 covers just works even when the file
        # names differ. Each video row shows its cover, and the
        # 🖼 Cover… button can fix any wrong pairing before queueing.
        _used = set(cover_of.values())
        _free_vids = sorted(
            (p for p in media
             if p.suffix.lower() in app.VIDEO_EXTS and p not in cover_of),
            key=lambda p: p.name.lower())
        _free_imgs = sorted(
            (p for p in media
             if p.suffix.lower() in app.IMAGE_EXTS and p not in _used),
            key=lambda p: p.name.lower())
        for _v, _im in zip(_free_vids, _free_imgs):
            cover_of[_v] = _im
        cover_images = set(cover_of.values())
        rows = []  # dicts: p, v, cap, cover

        def refresh_count():
            # Hidden carousel members don't count: they queue inside
            # their group row, never on their own.
            vis = [r for r in rows if not r.get("grouped")]
            k = sum(1 for r in vis if r["v"].get())
            count_lbl.config(text=f"{k} of {len(vis)} ticked — "
                                  "these will be queued")
            _refresh_counts()

        def on_row_toggle(rowd):
            # Unticking a row takes its cover and caption with it —
            # they must not linger on a video that won't be queued.
            # (Re-tick, then Covers zip… / Captions zip… puts them
            # back with one click each.)
            if not rowd["v"].get():
                rowd["cover"] = None
                if rowd.get("clbl"):
                    rowd["clbl"].config(text="")
                rowd["cap"].delete(0, "end")
            refresh_count()

        def toggle_row(rowd):
            rowd["v"].set(not rowd["v"].get())
            on_row_toggle(rowd)

        for p in media:
            r = ttk.Frame(box)
            r.pack(fill="x", pady=2)
            v = tk.BooleanVar(value=p not in cover_images)
            rowd = {"p": p, "v": v, "cap": None,
                    "cover": cover_of.get(p), "clbl": None,
                    "frame": r, "grouped": False}
            rows.append(rowd)
            cb = ttk.Checkbutton(
                r, variable=v,
                command=lambda rowd=rowd: on_row_toggle(rowd))
            cb.pack(side="left")
            cb.bind("<MouseWheel>", wheel)
            lbl = ttk.Label(r, text=p.name, font=("Segoe UI", 10),
                            width=22, anchor="w")
            lbl.pack(side="left", padx=(2, 6))
            lbl.bind("<Button-1>", lambda e, rowd=rowd: toggle_row(rowd))
            cap = ttk.Entry(r, font=("Segoe UI", 10))
            cap.pack(side="left", fill="x", expand=True)
            cap.insert(0, shared_caption)
            cap.bind("<MouseWheel>", wheel)
            rowd["cap"] = cap
            if p in cover_images:
                ttk.Label(r, text="🖼 cover",
                          font=("Segoe UI", 8)).pack(side="left",
                                                      padx=(4, 0))
            if p.suffix.lower() in app.VIDEO_EXTS:
                clbl = ttk.Label(r, text="", font=("Segoe UI", 8),
                                 width=15, anchor="w")
                clbl.pack(side="left", padx=(4, 0))

                def _set_cover(rowd=rowd, clbl=clbl):
                    f = filedialog.askopenfilename(
                        parent=top, title="Cover photo chunein",
                        filetypes=[("Images",
                                    "*.jpg *.jpeg *.png *.webp"),
                                   ("Zip files", "*.zip"),
                                   ("All files", "*.*")])
                    if not f:
                        return
                    if Path(f).suffix.lower() == ".zip":
                        img = app.first_image_in_zip(f)
                        if not img:
                            zip_warn(
                                "Cover",
                                "Is zip file mein koi photo nahi mili.")
                            return
                        f = img
                    rowd["cover"] = Path(f)
                    clbl.config(text="🖼 " + Path(f).name[:13])

                ttk.Button(r, text="🖼 Cover…",
                           command=_set_cover).pack(side="left")
                if rowd["cover"]:
                    clbl.config(text="🖼 " + rowd["cover"].name[:13])
                rowd["clbl"] = clbl

                def _show_cover(rowd=rowd):
                    # Clicking a video's cover name shows that picture,
                    # so she can check it is the right one for that day.
                    p = rowd.get("cover")
                    if not p:
                        zip_warn("Cover",
                                 "Is video ki koi cover nahi lagi.")
                        return
                    self.preview_image(top, p, warn=zip_warn)

                clbl.config(cursor="hand2")
                clbl.bind("<Button-1>",
                          lambda e, rowd=rowd: _show_cover(rowd))

        def set_all(val):
            # Same one rule as a single untick: an unticked row keeps
            # no cover and no caption (re-tick, then Covers zip… /
            # Captions zip… puts them back). Hidden carousel members
            # are skipped entirely — ticking them would queue their
            # photo twice (once alone, once inside the carousel).
            for r in rows:
                if r.get("grouped"):
                    continue
                r["v"].set(val)
                if not val:
                    r["cover"] = None
                    if r.get("clbl"):
                        r["clbl"].config(text="")
                    r["cap"].delete(0, "end")
            refresh_count()

        ttk.Button(selbar, text="Select all",
                   command=lambda: set_all(True)).pack(side="right")
        ttk.Button(selbar, text="Clear",
                   command=lambda: set_all(False)).pack(side="right",
                                                       padx=(0, 6))
        # ---- day-wise caption/cover matching ----
        # Captions and covers may arrive in their OWN zips; they are
        # matched to the videos by day number (Day 1 video + Day 1
        # caption + Day 1 cover). A day missing on one side gets NO
        # caption/cover and a warning — never a wrong file.
        cap_count = [0]

        def _refresh_counts():
            # The tally follows the tick: unticking a video drops its
            # cover and caption from the count too, so this line always
            # shows what will actually be queued — and never a negative
            # "alag photos" when covers arrive in their own zip.
            # Carousel group rows count as one queued job each.
            ticked = [r for r in rows if r["v"].get()]
            singles = [r for r in ticked if not r.get("carousel")]
            _nv = sum(1 for r in singles
                      if r["p"].suffix.lower() in app.VIDEO_EXTS)
            _nc = sum(1 for r in singles if r["cover"])
            _ni = sum(1 for r in singles
                      if r["p"].suffix.lower() in app.IMAGE_EXTS
                      and r["p"] not in cover_images)
            _ncap = sum(1 for r in ticked if r["cap"].get().strip())
            txt = (f"📊 Queue hoga: {_nv} videos | {_nc} cover "
                   f"photos | {_ni} alag photos | {_ncap} captions")
            _cars = [r for r in ticked if r.get("carousel")]
            if _cars:
                _cp = sum(len(r["carousel"]) for r in _cars)
                txt += f" | 🎠 {len(_cars)} carousel ({_cp} photos)"
            counts_lbl.config(text=txt)

        def _apply_captions(caps):
            """Fill post rows' captions from [(day|None, text)].
            Day numbers match strictly; with no day numbers at all,
            captions pair up in order. Returns (filled, missing)."""
            # Carousel group rows keep their own single caption —
            # never overwrite it from a captions file.
            targets = [r for r in rows
                       if not r.get("carousel")
                       and r["p"] not in cover_images]
            by_day = {}
            for d, t in caps:
                if d is not None:
                    by_day.setdefault(d, t)
            filled, missing = 0, []
            if by_day and any(app.day_number(r["p"].name) is not None
                              for r in targets):
                row_days = {app.day_number(r["p"].name) for r in targets}
                for r in targets:
                    d = app.day_number(r["p"].name)
                    if d is not None and d in by_day:
                        r["cap"].delete(0, "end")
                        r["cap"].insert(0, by_day[d])
                        filled += 1
                    elif d is not None:
                        missing.append(f"{r['p'].name} (Day {d})")
                extra = sorted(d for d in by_day if d not in row_days)
                if extra:
                    missing.append(
                        f"(aur {len(extra)} captions aisi hain jin ki "
                        "video nahi mili)")
            else:
                for r, (_d, t) in zip(targets, caps):
                    r["cap"].delete(0, "end")
                    r["cap"].insert(0, t)
                    filled += 1
            return filled, missing

        def _missing_warn(kind, missing):
            if missing:
                zip_warn(kind,
                         f"In ki {kind.lower()} nahi mili (ghalat "
                         "lagane ke bajaye khaali chhoda hai):\n" +
                         "\n".join(missing[:10]))

        def _load_captions_zip():
            f = filedialog.askopenfilename(
                parent=top, title="Captions wali zip chunein",
                filetypes=[("Zip files", "*.zip"),
                           ("All files", "*.*")])
            if not f:
                return
            caps = app.read_zip_captions_all(f)
            if not caps:
                zip_warn("Captions",
                         "Is zip mein koi caption file nahi mili.")
                return
            cap_count[0] = len(caps)
            filled, missing = _apply_captions(caps)
            _refresh_counts()
            if filled:
                cap_note.config(
                    text=f"📝 Captions zip se {filled} captions lag "
                         "gayi hain — check kar lein, koi badalna ho "
                         "to us ki line mein badal dein.")
            _missing_warn("Captions", missing)

        def _load_covers_zip():
            f = filedialog.askopenfilename(
                parent=top, title="Covers wali zip chunein",
                filetypes=[("Zip files", "*.zip"),
                           ("All files", "*.*")])
            if not f:
                return
            try:
                imgs = app.extract_zip_images(f)
            except Exception as e:
                zip_warn("Covers", f"Zip nahi khul saki:\n{e}")
                return
            if not imgs:
                zip_warn("Covers", "Is zip mein koi photo nahi mili.")
                return
            vid_rows = [r for r in rows
                        if not r.get("carousel")
                        and r["p"].suffix.lower() in app.VIDEO_EXTS]
            by_day = {}
            for p in imgs:
                d = app.day_number(p.name)
                if d is not None:
                    by_day.setdefault(d, p)
            n_set, missing = 0, []
            if by_day and any(app.day_number(r["p"].name) is not None
                              for r in vid_rows):
                for r in vid_rows:
                    d = app.day_number(r["p"].name)
                    if d is not None and d in by_day:
                        r["cover"] = by_day[d]
                        if r.get("clbl"):
                            r["clbl"].config(
                                text="🖼 " + by_day[d].name[:13])
                        n_set += 1
                    elif d is not None and not r["cover"]:
                        missing.append(f"{r['p'].name} (Day {d})")
            else:
                for r, p in zip(vid_rows, imgs):
                    r["cover"] = p
                    if r.get("clbl"):
                        r["clbl"].config(text="🖼 " + p.name[:13])
                    n_set += 1
            _refresh_counts()
            if n_set:
                cap_note.config(
                    text=f"🖼 Covers zip se {n_set} covers lag gayi "
                         "hain — kisi video ki cover dekhni ho to us "
                         "ke cover naam pe click karein.")
            _missing_warn("Covers", missing)

        def _create_carousel_group(photos):
            """Build ONE carousel group row from the given photo rows
            (already validated). The group row's own tick then
            controls queueing, like any other row; its member photos
            are hidden and never queue on their own again."""
            first_cap = photos[0]["cap"].get()
            gf = ttk.Frame(box)
            try:
                gf.pack(fill="x", pady=2, before=photos[0]["frame"])
            except Exception:
                gf.pack(fill="x", pady=2)
            gv = tk.BooleanVar(value=True)
            ttk.Checkbutton(gf, variable=gv,
                            command=refresh_count).pack(side="left")
            glbl = ttk.Label(gf, text=f"🎠 Carousel: {len(photos)} photos",
                             font=("Segoe UI", 10, "bold"),
                             width=22, anchor="w")
            glbl.pack(side="left", padx=(2, 6))

            def _gtoggle():
                gv.set(not gv.get())
                refresh_count()
            glbl.bind("<Button-1>", lambda e: _gtoggle())
            gcap = ttk.Entry(gf, font=("Segoe UI", 10))
            gcap.pack(side="left", fill="x", expand=True)
            gcap.insert(0, first_cap)
            gcap.bind("<MouseWheel>", wheel)
            for r in photos:
                r["grouped"] = True
                r["v"].set(False)
                r["frame"].pack_forget()
            rows.append({"p": None, "v": gv, "cap": gcap, "cover": None,
                         "clbl": None,
                         "carousel": [r["p"] for r in photos],
                         "frame": gf, "grouped": False})
            refresh_count()

        def _make_carousel_group():
            """Merge the ticked photos into ONE carousel group row.
            Videos can never join a carousel — if any ticked row is
            a video, refuse outright and name the reason."""
            ticked = [r for r in rows
                      if r["v"].get() and not r.get("carousel")]
            if any(r["p"] is not None
                   and r["p"].suffix.lower() in app.VIDEO_EXTS
                   for r in ticked):
                zip_warn("Carousel",
                         "Carousel mein sirf photos hoti hain — "
                         "video nahi.\n\nPehle videos ka tick hatayein, "
                         "phir Carousel banaein.")
                return
            photos = [r for r in ticked
                      if r["p"] is not None
                      and r["p"].suffix.lower() in app.IMAGE_EXTS]
            if len(photos) < 2:
                zip_warn("Carousel",
                         "Carousel ke liye kam se kam 2 photos tick "
                         "karein.")
                return
            _create_carousel_group(photos)

        def _auto_group_by_order():
            """One-go month setup: chunk the ticked photos IN DIALOG
            ORDER into consecutive carousels of `per_entry` photos
            each. A trailing single photo stays a single row (it
            cannot be a carousel); ticked videos stay single too;
            already-grouped rows are never touched twice, so
            clicking again adds nothing."""
            photos = [r for r in rows
                      if r["v"].get() and not r.get("carousel")
                      and not r.get("grouped")
                      and r["p"] is not None
                      and r["p"].suffix.lower() in app.IMAGE_EXTS]
            if len(photos) < 2:
                zip_warn("Auto-group",
                         "Auto-group ke liye kam se kam 2 photos tick "
                         "karein.")
                return
            chunks = chunk_consecutive(photos, per_entry.get())
            made = 0
            for chunk in chunks:
                if len(chunk) < 2:
                    continue
                _create_carousel_group(chunk)
                made += 1
            grouped_n = sum(len(c) for c in chunks if len(c) >= 2)
            leftover = len(photos) - grouped_n
            videos = [r for r in rows
                      if r["v"].get() and not r.get("carousel")
                      and r["p"] is not None
                      and r["p"].suffix.lower() in app.VIDEO_EXTS]
            note = f"🎠 Auto-group: {made} carousels ban gaye"
            if leftover:
                note += (f" • {leftover} photo single reh gayi "
                         "(aakhri group mein 1 photo thi)")
            if videos:
                note += (f" • {len(videos)} video single rahengi "
                         "(carousel mein sirf photos)")
            note += " — Queue se pehle group rows check kar lein."
            cap_note.config(text=note)

        zipbar = ttk.Frame(top)
        zipbar.pack(fill="x", padx=12, pady=(4, 0), before=cbox)
        ttk.Button(zipbar, text="📝 Captions zip…",
                   command=_load_captions_zip).pack(side="left")
        ttk.Button(zipbar, text="🖼 Covers zip…",
                   command=_load_covers_zip).pack(side="left", padx=(8, 0))
        ttk.Button(zipbar, text="🎠 Carousel banaein",
                   command=_make_carousel_group).pack(side="left",
                                                     padx=(8, 0))
        ttk.Label(zipbar, text="Har carousel:",
                  font=("Segoe UI", 9)).pack(side="left", padx=(12, 2))
        per_entry = ttk.Spinbox(zipbar, from_=2, to=20, width=3)
        per_entry.pack(side="left")
        per_entry.delete(0, "end")
        per_entry.insert(0, "4")
        ttk.Label(zipbar, text="photos",
                  font=("Segoe UI", 9)).pack(side="left", padx=(2, 0))
        ttk.Button(zipbar, text="🎠 Auto-group (tartib se)",
                   command=_auto_group_by_order).pack(side="left",
                                                      padx=(8, 0))
        # Captions from the videos zip itself (captions.txt, or
        # separate .txt files) fill the post rows' caption boxes —
        # cover photos get none, they are not posts.
        _caps_all = app.read_zip_captions_all(zip_path)
        if _caps_all:
            cap_count[0] = len(_caps_all)
            _filled, _missing = _apply_captions(_caps_all)
            if _filled:
                cap_note.config(
                    text=f"📝 Captions se {_filled} captions khud "
                         "bhar di hain — check kar lein, koi badalna "
                         "ho to us ki line mein badal dein.")
            _missing_warn("Captions", _missing)
        _refresh_counts()
        refresh_count()

        # Schedule controls INSIDE the dialog — the main tab's ones sit
        # behind this modal dialog, so without these the zip flow would
        # silently use whatever "Post now / Schedule" was last set.
        sched_bar = ttk.Frame(top)
        sched_bar.pack(fill="x", padx=12, pady=(6, 0))
        zwhen = tk.StringVar(value=self.when_var.get())
        ttk.Radiobutton(sched_bar, text="Post now", variable=zwhen,
                        value="now").pack(side="left")
        ttk.Radiobutton(sched_bar, text="Schedule:", variable=zwhen,
                        value="later").pack(side="left", padx=(10, 4))
        zsched = ttk.Entry(sched_bar, width=16, font=("Segoe UI", 10))
        zsched.pack(side="left")
        zsched.insert(0, self.sched_entry.get())
        ttk.Button(sched_bar, text="📅", width=3,
                   command=lambda: DateTimePicker(top, zsched,
                                                 self.theme)).pack(
                       side="left", padx=(4, 0))
        ttk.Label(sched_bar, text="every",
                  font=("Segoe UI", 9)).pack(side="left", padx=(8, 2))
        zhours = ttk.Entry(sched_bar, width=4, font=("Segoe UI", 10))
        zhours.pack(side="left")
        zhours.insert(0, self.hours_entry.get())
        ttk.Label(sched_bar, text="hours apart",
                  font=("Segoe UI", 9)).pack(side="left", padx=(2, 0))
        zstory = tk.BooleanVar(value=self.story_var.get())
        ttk.Checkbutton(sched_bar, text="📱 Story too",
                        variable=zstory).pack(side="left", padx=(12, 0))
        zcover = tk.BooleanVar(value=True)
        ttk.Checkbutton(sched_bar, text="🖼 Cover too",
                        variable=zcover).pack(side="left", padx=(12, 0))

        def zip_warn(title, msg):
            # Never pop a messagebox while this dialog holds the input
            # grab — on Windows it can land behind the dialog and the
            # app looks frozen. Release the grab first, then re-grab.
            try:
                top.grab_release()
            except Exception:
                pass
            messagebox.showwarning(title, msg)
            try:
                top.grab_set()
            except Exception:
                pass

        def do_queue():
            # Any unexpected error must NEVER be silent — show it so it can
            # be reported (a silent button press is the worst outcome).
            try:
                _do_queue_inner()
            except Exception as e:
                import traceback
                err = traceback.format_exc()
                try:
                    (app.DATA / "zip_error.log").write_text(
                        err, encoding="utf-8")
                except Exception:
                    pass
                try:
                    top.grab_release()
                except Exception:
                    pass
                messagebox.showerror(
                    "Zip error",
                    "Kuch garbar hui hai. Is message ka screenshot bhej "
                    "dein taake theek kar sakun:\n\n"
                    f"{type(e).__name__}: {e}",
                    parent=self.root)
                try:
                    if top.winfo_exists():
                        top.grab_set()
                except Exception:
                    pass

        def _do_queue_inner():
            # One ordered item per ticked row: a single post, or a
            # whole carousel group (which queues as ONE job).
            items = []
            for r in rows:
                if not r["v"].get():
                    continue
                if r.get("carousel"):
                    items.append(("carousel", r["carousel"], r["cap"],
                                  None))
                else:
                    items.append(("single", r["p"], r["cap"],
                                  r["cover"]))
            if not items:
                zip_warn("Zip contents", "Tick at least one file first.")
                return
            account = self.post_account.get().strip()
            if account not in set(self.all_account_labels()):
                zip_warn("Missing", "Add an account first.")
                return
            # schedule comes from THIS dialog's controls (the main tab's
            # are unreachable behind the modal)
            when = zwhen.get()
            sched_text = zsched.get()
            # capture plain values NOW — the dialog (and its widgets)
            # is destroyed below, after which zhours.get() would crash
            hours_text = zhours.get()
            to_story = zstory.get()
            use_cover = zcover.get()
            try:
                gap = int((hours_text or "0").strip() or "0")
            except ValueError:
                gap = 0
            base = None
            if gap > 0:
                if when == "later":
                    base = parse_datetime(sched_text)
                    if not base:
                        zip_warn("Missing", "Enter a date and time like "
                                            "2026-10-17 10:30.")
                        return
                else:
                    base = datetime.now()
            # Day order first: when every chosen single carries a day
            # number, stagger by day (Day 1 first) even if the file
            # names sort differently ("Day 10" before "Day 2"). A
            # carousel has no single day, so with any carousel present
            # the dialog order is kept instead.
            if (not any(it[0] == "carousel" for it in items)
                    and all(app.day_number(it[1].name) is not None
                            for it in items)):
                items.sort(key=lambda it: app.day_number(it[1].name))
            n, failed = 0, []
            for i, (kind, p, cap, cov) in enumerate(items):
                w, s = when, sched_text
                if gap > 0:
                    dt = base + timedelta(hours=gap * i)
                    w, s = "later", dt.strftime("%Y-%m-%d %H:%M")
                if kind == "carousel":
                    ok, err = self.make_carousel_job(
                        account, [str(x) for x in p],
                        cap.get().strip(), w, s, to_story)
                    if ok:
                        n += 1
                    else:
                        failed.append(f"Carousel: {err}")
                else:
                    ok, err = self.make_queue_job(
                        account, str(p), cap.get().strip(), w, s,
                        to_story,
                        cover=str(cov) if (use_cover and cov) else "",
                        kind="zip")
                    if ok:
                        n += 1
                    else:
                        failed.append(f"{p.name}: {err}")
            top.destroy()  # releases the grab before any summary popup
            if n:
                # keep the main tab in sync with what was just used
                self.when_var.set(when)
                self.sched_entry.delete(0, "end")
                self.sched_entry.insert(0, sched_text)
                self.hours_entry.delete(0, "end")
                self.hours_entry.insert(0, hours_text)
                self.story_var.set(to_story)
                # show the new posts in the Queue table immediately
                try:
                    self.refresh_queue()
                except Exception:
                    pass
                try:
                    self.refresh_schedule_tab()
                except Exception:
                    pass
            if failed:
                messagebox.showwarning(
                    "Zip contents",
                    f"{n} post(s) queued, {len(failed)} failed:\n" +
                    "\n".join(failed[:5]))
            if n:
                self.caption_text.delete("1.0", "end")
                extra = f" — every {gap} hours" if gap > 0 else ""
                self.status(f"Queued {n} post(s) from zip ✅{extra}")
        br = ttk.Frame(top)
        br.pack(fill="x", padx=12, pady=(8, 12))
        ttk.Button(br, text="Queue selected",
                   style="Accent.TButton",
                   command=do_queue).pack(side="right")
        ttk.Button(br, text="Cancel",
                   command=top.destroy).pack(side="right", padx=(0, 8))

    def make_queue_job(self, display_label, chosen_file, caption,
                       when_value, sched_text, to_story=False, cover="",
                       kind="single"):
        """Build and enqueue one post. Shows NO popups (safe to call in a
        loop or while another dialog holds the input grab).

        `cover` is an optional image path used as the video's cover.
        `kind` records where the post came from ("zip", "single",
        "recover") — the Schedule tab only lists "zip" posts.
        Returns (True, "") on success, (False, error_message) on failure.
        """
        if display_label not in set(self.all_account_labels()):
            return False, "Add an account first."
        if not chosen_file:
            return False, "Choose a photo or video first."
        sched = ""
        if when_value == "later":
            dt = parse_datetime(sched_text)
            if not dt:
                return False, "Enter a date and time like 2026-10-17 10:30."
            sched = dt.strftime("%Y-%m-%dT%H:%M")
        account, via, meta_ig_id = self.resolve_account(display_label)
        src = Path(chosen_file)
        if not src.is_file():
            return False, f"File not found:\n{src.name}"
        safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", src.name)
        dest = app.UPLOADS / f"{int(time.time())}_{safe}"
        try:
            shutil.copy(src, dest)
        except Exception as e:
            return False, f"Could not copy file:\n{e}"
        cover_dest = ""
        if cover:
            csrc = Path(cover)
            if not csrc.is_file():
                return False, f"Cover photo not found:\n{csrc.name}"
            csafe = re.sub(r"[^a-zA-Z0-9_.-]", "_", csrc.name)
            cdest = app.UPLOADS / f"{int(time.time())}_cover_{csafe}"
            try:
                shutil.copy(csrc, cdest)
                cover_dest = str(cdest)
            except Exception as e:
                return False, f"Could not copy cover photo:\n{e}"
        job = {"id": secrets.token_hex(6), "account": account,
               "filename": src.name, "filepath": str(dest),
               "caption": caption, "status": "waiting", "message": "",
               "link": "", "code": "", "scheduled_at": sched,
               "via": via, "meta_ig_id": meta_ig_id,
               "to_story": bool(to_story), "cover": cover_dest,
               "kind": kind}
        with app.QUEUE_LOCK:
            app.QUEUE.append(job)
        app.save_queue()
        return True, ""

    def make_carousel_job(self, display_label, filepaths, caption,
                          when_value, sched_text, to_story=False):
        """Build and enqueue ONE carousel job for many photos. Shows
        NO popups (safe to call from the zip dialog too).
        The job carries "files": [paths...] and filepath/filename of
        the first photo, so queue + schedule lists show it as one
        "Carousel (N photos)" row with the first photo as thumbnail.
        Returns (True, "") on success, (False, error) on failure.
        """
        if display_label not in set(self.all_account_labels()):
            return False, "Add an account first."
        if not filepaths or len(filepaths) < 2:
            return False, "Carousel ke liye kam se kam 2 photos chahiye."
        if len(filepaths) > 20:
            return False, ("Instagram carousel mein zyada se zyada "
                           "20 photos hoti hain.")
        bad = [p for p in filepaths
               if Path(p).suffix.lower() not in app.IMAGE_EXTS]
        if bad:
            return False, ("Carousel mein sirf photos hoti hain — "
                           "video nahi: "
                           + ", ".join(Path(p).name for p in bad[:3]))
        sched = ""
        if when_value == "later":
            dt = parse_datetime(sched_text)
            if not dt:
                return False, "Enter a date and time like 2026-10-17 10:30."
            sched = dt.strftime("%Y-%m-%dT%H:%M")
        account, via, meta_ig_id = self.resolve_account(display_label)
        dests = []
        for src_path in filepaths:
            src = Path(src_path)
            if not src.is_file():
                return False, f"File not found:\n{src.name}"
            safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", src.name)
            dest = app.UPLOADS / f"{int(time.time())}_{safe}"
            try:
                shutil.copy(src, dest)
            except Exception as e:
                return False, f"Could not copy file:\n{e}"
            dests.append(str(dest))
        job = {"id": secrets.token_hex(6), "account": account,
               "filename": f"Carousel ({len(dests)} photos)",
               "filepath": dests[0], "files": dests,
               "caption": caption, "status": "waiting", "message": "",
               "link": "", "code": "", "scheduled_at": sched,
               "via": via, "meta_ig_id": meta_ig_id,
               "to_story": bool(to_story), "cover": "",
               "kind": "carousel"}
        with app.QUEUE_LOCK:
            app.QUEUE.append(job)
        app.save_queue()
        return True, ""

    def queue_carousel_post(self, display_label, filepaths, caption,
                            when_value, sched_text, to_story=False):
        """Queue one carousel post for a single account dropdown label.
        Returns True on success."""
        ok, err = self.make_carousel_job(display_label, filepaths,
                                         caption, when_value, sched_text,
                                         to_story)
        if not ok:
            messagebox.showwarning("Missing", err)
            return False
        self.status("Carousel added to queue. 🎠"
                    + (" Scheduled." if when_value == "later" else "")
                    + (" + Story 📱" if to_story else ""))
        return True

    def queue_single_post(self, display_label, chosen_file, caption,
                          when_value, sched_text, to_story=False,
                          cover=""):
        """Queue one post for a single account dropdown label.

        Returns True on success.
        """
        ok, err = self.make_queue_job(display_label, chosen_file, caption,
                                      when_value, sched_text, to_story,
                                      cover)
        if not ok:
            messagebox.showwarning("Missing", err)
            return False
        self.status("Added to queue."
                    + (" Scheduled." if when_value == "later" else "")
                    + (" + Story 📱" if to_story else "")
                    + (" + Cover 🖼" if cover else ""))
        return True

    def choose_cover_zip(self):
        p = filedialog.askopenfilename(
            title="Cover wali zip file chunein",
            filetypes=[("Zip files", "*.zip"),
                       ("All files", "*.*")])
        if not p:
            return
        img = app.first_image_in_zip(p)
        if not img:
            messagebox.showwarning(
                "Cover", "Is zip file mein koi photo nahi mili.")
            return
        self.cover_path = img
        self.cover_var.set(True)
        self.cover_lbl.config(text=Path(img).name)

    def load_caption_from_zip(self):
        p = filedialog.askopenfilename(
            title="Captions wali zip file chunein",
            filetypes=[("Zip files", "*.zip"),
                       ("All files", "*.*")])
        if not p:
            return
        text = app.read_zip_captions(p)
        if not text:
            messagebox.showwarning(
                "Caption",
                "Is zip file mein captions.txt nahi mili.")
            return
        caps = app.split_captions(text)
        if not caps:
            messagebox.showwarning(
                "Caption", "captions.txt khaali hai.")
            return
        self.caption_text.delete("1.0", "end")
        self.caption_text.insert("1.0", caps[0])

    def choose_cover(self):
        p = filedialog.askopenfilename(
            title="Cover photo chunein (photo ya zip file)",
            filetypes=[("Images", "*.jpg *.jpeg *.png *.webp"),
                       ("Zip files", "*.zip"),
                       ("All files", "*.*")])
        if not p:
            return
        if Path(p).suffix.lower() == ".zip":
            img = app.first_image_in_zip(p)
            if not img:
                messagebox.showwarning(
                    "Cover", "Is zip file mein koi photo nahi mili.")
                return
            p = img
        self.cover_path = p
        self.cover_var.set(True)
        self.cover_lbl.config(text=Path(p).name)

    def add_post(self):
        caption = self.caption_text.get("1.0", "end").strip()
        if self.carousel_files:
            # Carousel: no cover applies (a carousel has no thumbnail
            # of its own), the single-photo flow below is untouched.
            ok = self.queue_carousel_post(
                self.post_account.get().strip(), self.carousel_files,
                caption, self.when_var.get(), self.sched_entry.get(),
                self.story_var.get())
            if ok:
                self.carousel_files = []
                self.carousel_src = ""
                self.file_lbl.config(text="no file chosen",
                                     font=("Segoe UI", 9, "italic"))
                self.caption_text.delete("1.0", "end")
                self._refresh_car_summary()
            return
        cover = ""
        if self.cover_var.get():
            if not self.cover_path:
                messagebox.showwarning(
                    "Cover", "Pehle cover photo chunein — "
                             "“Cover photo…” wala button dabayein.")
                return
            cover = self.cover_path
        ok = self.queue_single_post(
            self.post_account.get().strip(), self.chosen_file,
            caption,
            self.when_var.get(), self.sched_entry.get(),
            self.story_var.get(), cover)
        if ok:
            self.chosen_file = None
            self.file_lbl.config(text="no file chosen",
                                 font=("Segoe UI", 9, "italic"))
            self.caption_text.delete("1.0", "end")

    def select_all_queue(self):
        """Tick/untick every job currently shown in the Queue.

        Acts on the filtered view: with an account filter on, only
        that account's jobs are ticked. Toggles: if everything shown
        is already ticked, unticks it all instead — so one button
        serves both "check all" and "clear all ticks".
        """
        if not self.queue_trees:
            return
        shown = list(self.queue_trees[0].get_children())
        if not shown:
            return
        if all(rid in self.queue_checked for rid in shown):
            self.queue_checked -= set(shown)
        else:
            self.queue_checked |= set(shown)
        self.refresh_queue()

    def _save_post_gap(self):
        """Save the posting-gap spinbox value (0-60 minutes)."""
        try:
            app.save_post_gap_minutes(int(self.post_gap_var.get()))
        except Exception:
            self.post_gap_var.set(str(app.load_post_gap_minutes()))

    def post_now(self):
        n = len(app.due_jobs(only_due=False))
        if not n:
            self.status("Nothing to post right now.")
            return
        app.start_batch_thread(only_due=False)
        self.status(f"Posting {n}…")

    def post_filtered_now(self):
        """Post the FILTERED account's waiting posts right now.

        The mirror of clear_all_queue's safety rule: with "All
        accounts" shown this does nothing except ask for an account
        first — posting thousands of jobs at once would be exactly
        the burst the posting gap was built to prevent. With an
        account filtered, its waiting jobs post in queue order, one
        by one with the posting gap, after a confirmation naming the
        account and the count. Paused jobs are left alone; a job that
        fails lands in Failed for a manual Retry.
        """
        filt = self.queue_filter_var.get().strip() \
            if hasattr(self, "queue_filter_var") else "All accounts"
        if not filt or filt == "All accounts":
            messagebox.showinfo(
                "Abhi post karo",
                "Pehle Show mein koi account chuno — ye button sirf "
                "selected account ki posts abhi post karta hai, "
                "taake ghalti se sab accounts ki posts ek saath na "
                "chal paren.")
            self.status("Abhi post karne ke liye pehle koi account chuno.")
            return
        scope, selected_mode, paused, matched = \
            self._filtered_waiting_scope(filt)
        # Selected mode: if she ticked (✓) or highlighted any rows of
        # this account, ONLY those post — never the whole account.
        # (The first version posted all 456 of farida949771's waiting
        # posts when she only meant her selected ones.)
        if selected_mode and not scope:
            self.status("Selected posts mein koi waiting post nahi "
                        "hai — done/paused posts abhi nahi chal "
                        "sakti.")
            return
        if not scope:
            self.status(f"Abhi post karne ko kuch nahi hai — {filt} ki "
                        "koi waiting post nahi hai.")
            return
        gap = app.load_post_gap_minutes()
        if selected_mode:
            msg = (f"{filt} ki {len(scope)} selected posts abhi post "
                   "karein?\n\n"
                   "Sirf selected (✓ tick / neeli highlight wali) "
                   "posts post hongi, baaki schedule par hi rahengi "
                   f"(har post ke darmiyan {gap} minute ka waqfa). "
                   "Fail hone wali post Failed mein nazar aaye gi.")
        else:
            msg = (f"{filt} ki {len(scope)} waiting posts abhi post "
                   "karein?\n\n"
                   "Ye posts apne schedule time ka intezar kiye "
                   "baghair, tartib se post hongi (har post ke "
                   f"darmiyan {gap} minute ka waqfa). Fail hone wali "
                   "post Failed mein nazar aaye gi.")
        if paused and not selected_mode:
            msg += f"\n\n{paused} paused posts nahi chalengi."
        if not messagebox.askyesno("Abhi post karo", msg):
            return
        ids = [j.get("id") for j in scope]
        threading.Thread(target=self._run_filtered_now,
                         args=(ids, filt), daemon=True).start()
        self.status(f"{filt} ki {len(scope)} posts abhi post ho rahi "
                    "hain…")

    def _run_filtered_now(self, ids, filt):
        ok = app.run_job_list(ids)
        if ok:
            msg = f"{filt} ki abhi-post batch khatam ho gayi."
        else:
            msg = ("Ek batch pehle se chal raha hai — ye posts abhi "
                   "nahi chali. Us ke khatam hone ke baad dobara "
                   "dabayein.")
        self.root.after(0, lambda: self.status(msg))

    def _filtered_waiting_scope(self, filt):
        """Shared scope for Abhi post / Start posting (bulk-action rule).

        Returns (scope, selected_mode, paused, matched): scope is
        the waiting jobs to act on, in queue order; ticked (✓) or
        highlighted rows of the filtered account win over the whole
        filter; matched is every job of the filter (any status);
        paused counts the paused ones among them.
        """
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        scope = []
        paused = 0
        matched = []
        for j in jobs:
            acc = j.get("account", "")
            if j.get("via") == "meta":
                acc = "📘 " + acc
            if acc != filt:
                continue
            matched.append(j)
            if j.get("status") == "waiting":
                scope.append(j)
            elif j.get("status") == "paused":
                paused += 1
        selected_ids = (set(self.queue_checked)
                        | {j.get("id") for j in self.selected_jobs()})
        selected_here = selected_ids & {j.get("id") for j in matched}
        selected_mode = bool(selected_here)
        if selected_mode:
            scope = [j for j in scope if j.get("id") in selected_here]
        return scope, selected_mode, paused, matched

    def start_all_posting(self):
        """Post waiting jobs in small batches, asking between batches.

        "Start all posting": one press starts posting the filtered
        account's waiting jobs (or only the selected ones), batch
        by batch. She tells it how many posts per batch (default 5)
        and picks "ask after each batch" (the run waits for her Yes
        before the next batch) or "all by itself" (every batch runs
        on its own). Same scope rule as Abhi post: selected rows
        win; with no selection the filtered account's waiting jobs;
        with "All accounts" and no selection nothing starts. Only
        waiting jobs post — paused jobs are left alone, failed jobs
        stay for Retry.
        """
        filt = self.queue_filter_var.get().strip() \
            if hasattr(self, "queue_filter_var") else "All accounts"
        if not filt or filt == "All accounts":
            messagebox.showinfo(
                "Start posting",
                "Pehle Show mein koi account chuno — ye button sirf "
                "selected account ki posts batch mein post karta hai, "
                "taake ghalti se sab accounts ki posts ek saath na "
                "chal paren.")
            self.status("Start posting ke liye pehle koi account chuno.")
            return
        scope, selected_mode, paused, matched = \
            self._filtered_waiting_scope(filt)
        if selected_mode and not scope:
            self.status("Selected posts mein koi waiting post nahi "
                        "hai — done/paused posts abhi nahi chal "
                        "sakti.")
            return
        if not scope:
            self.status(f"Start posting ko kuch nahi hai — {filt} ki "
                        "koi waiting post nahi hai.")
            return
        self._start_posting_dialog(scope, filt, selected_mode, paused)

    def _start_posting_dialog(self, scope, filt, selected_mode, paused):
        """Dialog: batch size + ask-after-each-batch or all-by-itself."""
        gap = app.load_post_gap_minutes()
        n = len(scope)
        est_min = n * gap
        if est_min >= 60:
            est = f"{est_min // 60} ghante {est_min % 60} minute"
        else:
            est = f"{est_min} minute"
        top = tk.Toplevel(self.root)
        top.title("Start posting")
        label = f"▶️ {filt} ki {n} waiting posts"
        if selected_mode:
            label += " (selected)"
        ttk.Label(top, text=label,
                  font=(self.font_name, 11, "bold")).pack(
                      anchor="w", padx=10, pady=(10, 2))
        ttk.Label(top, text=f"Taqreeban {est} lage ga — har post ke "
                            f"darmiyan {gap} minute ka waqfa.",
                  wraplength=430).pack(anchor="w", padx=10)
        if paused and not selected_mode:
            ttk.Label(top, text=f"({paused} paused posts nahi "
                                "chalengi.)").pack(anchor="w", padx=10)
        row = ttk.Frame(top)
        row.pack(fill="x", padx=10, pady=(8, 0))
        ttk.Label(row, text="Har batch mein kitni posts:").pack(
            side="left")
        batch_var = tk.StringVar(value="5")
        ttk.Spinbox(row, from_=1, to=50, width=5,
                    textvariable=batch_var).pack(side="left", padx=(6, 0))
        mode_var = tk.StringVar(value="ask")
        ttk.Radiobutton(top, text="Har batch ke baad poochho (agle "
                                 "batch se pehle Yes dabao)",
                        variable=mode_var, value="ask").pack(
                            anchor="w", padx=10, pady=(8, 0))
        ttk.Radiobutton(top, text="Sab ek saath, bina poochhe (khud "
                                 "hi ek ke baad ek)",
                        variable=mode_var, value="all").pack(
                            anchor="w", padx=10)
        ttk.Label(top, text="Batch ke darmiyan rukne par baaki posts "
                            "schedule par hi rahengi. App band karne "
                            "par batch ruk jaye ga; jo post adhoori "
                            "reh gayi wo agle launch par dobara "
                            "waiting ho jaye gi.",
                  wraplength=430).pack(anchor="w", padx=10, pady=(8, 0))
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=10)

        def start():
            try:
                batch_size = int(batch_var.get().strip())
            except ValueError:
                batch_size = 5
            batch_size = max(1, min(50, batch_size))
            ask_each = (mode_var.get() == "ask")
            ids = [j.get("id") for j in scope]
            threading.Thread(target=self._run_start_posting,
                             args=(ids, batch_size, ask_each, filt),
                             daemon=True).start()
            self.status(f"Start posting: {filt} ki {len(ids)} posts "
                        f"{batch_size} ke batch mein post ho rahi "
                        "hain…")
            top.destroy()

        ttk.Button(btns, text="▶️ Shuru karo",
                   command=start).pack(side="left")
        ttk.Button(btns, text="Cancel",
                   command=top.destroy).pack(side="left", padx=(6, 0))

    def _run_start_posting(self, ids, batch_size, ask_each, filt):
        confirm = self._ask_next_batch if ask_each else None
        res = app.run_job_list_batched(ids, batch_size, confirm)
        if res is None:
            msg = ("Ek batch pehle se chal raha hai — ye posts abhi "
                   "nahi chali. Us ke khatam hone ke baad dobara "
                   "dabayein.")
        else:
            attempted, stopped_early = res
            with app.QUEUE_LOCK:
                remaining = sum(1 for j in app.QUEUE
                                if j.get("id") in set(ids)
                                and j.get("status") == "waiting")
            if stopped_early:
                msg = (f"Start posting ruk gayi — {attempted} posts "
                       f"ho gayi, {remaining} baaki hain (schedule "
                       "par).")
            else:
                msg = (f"Start posting khatam — {attempted} posts ho "
                       f"gayi, {remaining} baaki hain (schedule "
                       "par).")
        self.root.after(0, lambda: self.status(msg))

    def _ask_main_thread(self, title, msg):
        """Ask a Yes/No question on the MAIN thread, from a worker.

        The dialog runs on the main thread (tkinter rule) and the
        worker waits on an event for the answer. If the app closes
        while waiting, the worker (daemon) dies with it.
        """
        ev = threading.Event()
        ans = {"yes": False}

        def _show():
            try:
                ans["yes"] = messagebox.askyesno(title, msg)
            finally:
                ev.set()

        try:
            self.root.after(0, _show)
        except Exception:
            # Event loop not running (never in the real app, where
            # mainloop is always up) — stop cleanly instead of the
            # worker dying silently mid-run with no status update.
            ev.set()
            return False
        ev.wait()
        return ans["yes"]

    def _ask_next_batch(self, batch_no, attempted, remaining):
        """Ask on the MAIN thread whether the next batch should run."""
        return self._ask_main_thread(
            "Agla batch?",
            f"Batch {batch_no} done — {attempted} posts ho gayi, "
            f"{remaining} baaki hain.\n\nAgla batch chalao?")

    def _sync_sched_toggle(self):
        """Toggle button text follows the scheduler state (both queues
        + the Posting tab)."""
        text = ("▶️ Posting shuru karo" if app.scheduler_paused()
                else "⏸ Posting roko")
        for btn in getattr(self, "_sched_toggle_btns", []):
            try:
                btn.config(text=text)
            except Exception:
                pass
        if hasattr(self, "_posting_sched_var"):
            self._posting_sched_var.set(
                "Posting chal rahi hai ✅"
                if not app.scheduler_paused()
                else "Posting ruki hui hai ⏸ — ▶️ Posting shuru karo "
                     "dabao jab shuru karni ho.")

    def _toggle_scheduler(self):
        """Start or stop automatic posting, by her choice."""
        paused = app.scheduler_paused()
        app.set_scheduler_paused(not paused)
        self._sync_sched_toggle()
        if paused:
            self.status("Posting shuru ho gayi — due posts apne time "
                        "par post hongi.")
        else:
            self.status("Posting ruk gayi — ▶️ Posting shuru karo "
                        "dabao jab shuru karni ho.")

    def _ask_startup_posting(self):
        """Ask before ANY automatic posting runs (missed days first).

        The app used to start posting by itself within 30 seconds
        of opening — she opens it to fix accounts first, so now it
        asks. The scheduler starts PAUSED (app.py default). Missed
        = waiting jobs scheduled before today. No due posts at all
        -> the scheduler just starts, no dialog.
        """
        from datetime import datetime
        today = datetime.now().strftime("%Y-%m-%d")
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        missed = {}
        for j in jobs:
            if j.get("status") != "waiting":
                continue
            sched = (j.get("scheduled_at") or "").strip()
            if len(sched) >= 10 and sched[4:5] == "-" \
                    and sched[7:8] == "-":
                if sched[:10] < today:
                    missed.setdefault(sched[:10], []).append(j)
        if missed:
            self._missed_day_dialog(missed)
            return
        self._today_start_dialog()

    def _missed_day_dialog(self, missed):
        """'Kal ki posting nahi hui — karna hai ya skip karna hai?'

        Non-modal, stays on top: she can look at the queue first.
        Yes -> scheduler starts (missed posts are overdue, so they
        post first). Skip -> missed jobs are PAUSED (resumable with
        Resume), then today's question follows. Closing the dialog
        leaves everything as-is: missed stay waiting, posting paused.
        """
        top = tk.Toplevel(self.root)
        top.title("Kal ki posting?")
        top.attributes("-topmost", True)
        total = sum(len(v) for v in missed.values())
        lines = [f"• {day}: {len(v)} posts"
                 for day, v in sorted(missed.items())]
        ttk.Label(top, text="Kal ki posting nahi hui — karna hai ya "
                            "skip karna hai?",
                  font=(self.font_name, 11, "bold"),
                  wraplength=430).pack(anchor="w", padx=10, pady=(10, 2))
        ttk.Label(top, text="\n".join(lines),
                  wraplength=430).pack(anchor="w", padx=10)
        ttk.Label(top, text=f"Kul {total} posts reh gayi hain.",
                  wraplength=430).pack(anchor="w", padx=10, pady=(4, 0))
        ttk.Label(top, text="Skip karne par ye posts paused ho jayen "
                            "gi — kabhi bhi Resume se wapas chala "
                            "sakti ho.",
                  wraplength=430).pack(anchor="w", padx=10, pady=(4, 0))
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=10)

        def do_yes():
            app.set_scheduler_paused(False)
            self._sync_sched_toggle()
            self.status("Posting shuru ho gayi — kal ki reh gayi "
                        "posts pehle post hongi, phir aaj ki.")
            top.destroy()

        def do_skip():
            with app.QUEUE_LOCK:
                for v in missed.values():
                    for j in v:
                        live = next((q for q in app.QUEUE
                                     if q.get("id") == j.get("id")), None)
                        if live and live.get("status") == "waiting":
                            live["status"] = "paused"
                            live["message"] = "Skip — missed day"
            app.save_queue()
            self.refresh_queue()
            top.destroy()
            self._today_start_dialog()

        ttk.Button(btns, text="✅ Haan, kar lo",
                   command=do_yes).pack(side="left")
        ttk.Button(btns, text="⏭ Skip karo",
                   command=do_skip).pack(side="left", padx=(6, 0))

    def _today_start_dialog(self):
        """'Aaj ki saari schedule posting start karun?' (Yes/No/Accounts)."""
        from datetime import datetime
        today = datetime.now().strftime("%Y-%m-%d")
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        order, plan = app.today_posting_plan(jobs, today)
        rows = [job for slot in order for job in plan.get(slot, [])]
        accts = set()
        done = failed = postable = 0
        for job in rows:
            acct = job.get("account", "")
            if job.get("via") == "meta":
                acct = "📘 " + acct
            accts.add(acct)
            if job.get("status") == "done":
                done += 1
            elif job.get("status") == "failed":
                failed += 1
            if job.get("status") in ("waiting", "uploading",
                                     "needs_code"):
                postable += 1
        if postable <= 0:
            # Nothing due today — nothing to decide; just start.
            app.set_scheduler_paused(False)
            self._sync_sched_toggle()
            return
        baaki = len(rows) - done - failed
        top = tk.Toplevel(self.root)
        top.title("Aaj ki posting?")
        top.attributes("-topmost", True)
        ttk.Label(top, text="Aaj ki saari schedule posting start "
                            "karun?",
                  font=(self.font_name, 11, "bold"),
                  wraplength=430).pack(anchor="w", padx=10, pady=(10, 2))
        txt = (f"Aaj: {len(accts)} accounts • {len(rows)} posts • "
               f"✅ {done} done • ⏳ {baaki} baaki")
        if failed:
            txt += f" • ❌ {failed} failed"
        ttk.Label(top, text=txt, wraplength=430).pack(anchor="w", padx=10)
        ttk.Label(top, text="No dabao to posting ruki rahe gi — pehle "
                            "jis account ki posting pehle karni ho, wo "
                            "Abhi post karo ya Accounts batch se kar lo, "
                            "phir ▶️ Posting shuru karo dabao.",
                  wraplength=430).pack(anchor="w", padx=10, pady=(6, 0))
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=10)

        def do_yes():
            app.set_scheduler_paused(False)
            self._sync_sched_toggle()
            self.status("Posting shuru ho gayi — aaj ki schedule "
                        "posts apne time par post hongi.")
            top.destroy()

        def do_accounts():
            top.destroy()
            self._account_batch_dialog()

        def do_no():
            self.status("Posting ruki hui hai — ▶️ Posting shuru karo "
                        "dabao jab shuru karni ho.")
            top.destroy()

        ttk.Button(btns, text="✅ Haan, start karo",
                   command=do_yes).pack(side="left")
        ttk.Button(btns, text="📋 Accounts se karo",
                   command=do_accounts).pack(side="left", padx=(6, 0))
        ttk.Button(btns, text="⏸ Nahi, ruko",
                   command=do_no).pack(side="left", padx=(6, 0))

    def _due_accounts_ordered(self):
        """(username, due-count) for accounts with due jobs, in
        account-list order (her fixed slots = her priority order),
        then any job-only accounts, A-Z."""
        due = app.due_jobs(only_due=True)
        counts = {}
        for j in due:
            acct = j.get("account", "")
            counts[acct] = counts.get(acct, 0) + 1
        ordered = []
        seen = set()
        for label in self.all_account_labels():
            username, _via, _ig = self.resolve_account(label)
            key = username.lower()
            if key in seen:
                continue
            for acct, c in counts.items():
                if acct.lower() == key:
                    ordered.append((username, c))
                    seen.add(key)
                    break
        for acct in sorted(counts):
            if acct.lower() not in seen:
                ordered.append((acct, counts[acct]))
                seen.add(acct.lower())
        return ordered

    def _account_batch_dialog(self):
        """Post due jobs account by account: N accounts, then ask."""
        ordered = self._due_accounts_ordered()
        if not ordered:
            messagebox.showinfo("Accounts batch",
                                "Abhi koi due posting nahi hai — koi "
                                "account post karne ko tayyar nahi.")
            self.status("Accounts batch: abhi koi due posting nahi hai.")
            return
        total_posts = sum(c for _u, c in ordered)
        top = tk.Toplevel(self.root)
        top.title("Accounts batch")
        top.attributes("-topmost", True)
        ttk.Label(top, text="Accounts batch — due posting accounts se",
                  font=(self.font_name, 11, "bold"),
                  wraplength=430).pack(anchor="w", padx=10, pady=(10, 2))
        ttk.Label(top, text=f"Kul: {len(ordered)} accounts • "
                            f"{total_posts} posts",
                  wraplength=430).pack(anchor="w", padx=10)
        ttk.Label(top, text="Tartib: accounts ki list wali (Up/Down se "
                            "badal sakti ho). Batch ke darmiyan posting "
                            "rukti hai — tab kharab account theek kar "
                            "sakti ho (🔑 Login), phir agla batch.",
                  wraplength=430).pack(anchor="w", padx=10, pady=(4, 0))
        row = ttk.Frame(top)
        row.pack(fill="x", padx=10, pady=(8, 0))
        ttk.Label(row, text="Ek batch mein kitne accounts:").pack(
            side="left")
        per_var = tk.StringVar(value="5")
        ttk.Spinbox(row, from_=1, to=20, width=5,
                    textvariable=per_var).pack(side="left", padx=(6, 0))
        lst = tk.Listbox(top, height=min(len(ordered), 8))
        for i, (u, c) in enumerate(ordered, 1):
            lst.insert("end", f"{i}. @{u} — {c} posts")
        lst.pack(fill="x", padx=10, pady=(8, 0))
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=10)

        def start():
            try:
                per = int(per_var.get().strip())
            except ValueError:
                per = 5
            per = max(1, min(20, per))
            usernames = [u for u, _c in ordered]
            threading.Thread(target=self._run_account_batches,
                             args=(usernames, per), daemon=True).start()
            self.status(f"Accounts batch: {len(usernames)} accounts ki "
                        f"due posting {per} ke batch mein shuru…")
            top.destroy()

        ttk.Button(btns, text="▶️ Shuru karo",
                   command=start).pack(side="left")
        ttk.Button(btns, text="Cancel",
                   command=top.destroy).pack(side="left", padx=(6, 0))

    def _run_account_batches(self, usernames, per_batch, confirm="ask"):
        """Run an accounts batch in a worker thread.

        confirm="ask" (default, the Notifications dialog) asks before
        each next batch; confirm=None runs the whole list without
        asking (the Posting tab's amount mode)."""
        if confirm == "ask":
            confirm = self._ask_next_account_batch
        res = app.run_due_jobs_by_account(usernames, per_batch,
                                          confirm)
        if res is None:
            msg = ("Ek batch pehle se chal raha hai — ye accounts abhi "
                   "nahi chale. Us ke khatam hone ke baad dobara "
                   "dabayein.")
        else:
            attempted, stopped_early = res
            if stopped_early:
                msg = (f"Accounts batch ruk gaya — {attempted} posts ho "
                       "gayi. Baaki accounts ki posting schedule par "
                       "hai.")
            else:
                msg = (f"Accounts batch khatam — {attempted} posts ho "
                       "gayi.")
        self.root.after(0, lambda: self.status(msg))
        if hasattr(self, "_posting_list"):
            self.root.after(0, self.refresh_posting_tab)

    def _ask_next_account_batch(self, batch_no, done_accts, left_accts,
                                attempted):
        """Ask on the MAIN thread whether the next account batch runs."""
        return self._ask_main_thread(
            "Agla batch?",
            f"Accounts batch {batch_no} done — {done_accts} accounts ho "
            f"gaye, {left_accts} baaki hain ({attempted} posts ho "
            f"gayi).\n\nAgla batch chalao?")

    def build_posting_tab(self):
        """Separate Posting tab: start/stop + how many accounts, or all.

        She stopped posting from the queue and wanted one place to
        handle posting: start/stop here, type how many accounts to
        post (1, 2, 3...), or tick Sab for all of them. Number mode
        posts exactly that many accounts in one go; Sab mode posts
        all accounts in batches of that size, asking between batches
        so a broken account can be fixed in between."""
        ttk.Label(self.posting_tab, text="▶️ Posting control",
                  font=(self.font_name, 12, "bold")).pack(anchor="w")
        ttk.Label(self.posting_tab,
                  text="Yahan se posting start/stop karein aur kitne "
                       "accounts ki posting karni hai, wo chunein.",
                  wraplength=600).pack(anchor="w", pady=(0, 8))

        # --- Start / Stop (same switch as the queue-row buttons) ---
        box = ttk.LabelFrame(self.posting_tab, text="Posting on/off",
                             padding=10)
        box.pack(fill="x", pady=(0, 10))
        if not hasattr(self, "_sched_toggle_btns"):
            self._sched_toggle_btns = []
        _ptoggle = ttk.Button(box, text="▶️ Posting shuru karo",
                              command=self._toggle_scheduler)
        _ptoggle.pack(side="left")
        self._sched_toggle_btns.append(_ptoggle)
        self._posting_sched_var = tk.StringVar(value="")
        ttk.Label(box, textvariable=self._posting_sched_var).pack(
            side="left", padx=(10, 0))
        self._sync_sched_toggle()

        # --- How many accounts ---
        box2 = ttk.LabelFrame(
            self.posting_tab,
            text="Kitne accounts ki posting karni hai?",
            padding=10)
        box2.pack(fill="x", pady=(0, 10))
        row = ttk.Frame(box2)
        row.pack(fill="x")
        ttk.Label(row, text="Amount likho:").pack(side="left")
        self._posting_amount_var = tk.StringVar(value="5")
        ttk.Spinbox(row, from_=1, to=20, width=5,
                    textvariable=self._posting_amount_var).pack(
                        side="left", padx=(6, 0))
        ttk.Label(row, text="accounts").pack(side="left", padx=(4, 0))
        self._posting_all_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row, text="✅ Sab accounts ki posting karo",
                        variable=self._posting_all_var).pack(
                            side="left", padx=(16, 0))
        ttk.Label(box2,
                  text="• Sab band ho to: itne accounts ki due posting "
                       "hogi, phir ruk jaye gi.\n"
                       "• Sab tick ho to: har batch mein itne accounts "
                       "post honge, har batch ke baad poochha jaye ga — "
                       "beech mein kharab account theek kar sakti ho "
                       "(🔑 Login).",
                  wraplength=600).pack(anchor="w", pady=(6, 0))
        self._posting_totals_var = tk.StringVar(value="")
        ttk.Label(box2, textvariable=self._posting_totals_var,
                  font=(self.font_name, 10, "bold")).pack(anchor="w",
                                                          pady=(6, 0))
        self._posting_list = tk.Listbox(box2, height=8)
        self._posting_list.pack(fill="x", pady=(0, 6))
        btns = ttk.Frame(box2)
        btns.pack(fill="x")
        ttk.Button(btns, text="▶️ Shuru karo",
                   command=self._posting_start_run).pack(side="left")
        ttk.Button(btns, text="🔄 Refresh",
                   command=self.refresh_posting_tab).pack(side="left",
                                                          padx=(6, 0))
        self._posting_run_var = tk.StringVar(value="")
        ttk.Label(box2, textvariable=self._posting_run_var).pack(
            anchor="w", pady=(6, 0))
        ttk.Label(self.posting_tab,
                  text="Tartib: accounts ki list wali (Up/Down se badal "
                       "sakti ho). Posts ke darmiyan waqfa (gap) wahi "
                       "rahe ga jo Post tab mein set hai. App band karne "
                       "par batch ruk jaye ga — baaki posts schedule par "
                       "rahengi.",
                  wraplength=600).pack(anchor="w")
        self.notebook.bind("<<NotebookTabChanged>>",
                           self._on_tab_changed_posting, add="+")
        self.refresh_posting_tab()

    def _on_tab_changed_posting(self, _event=None):
        try:
            if self.notebook.select() == getattr(self, "posting_tab_id",
                                                 None):
                self.refresh_posting_tab()
        except Exception:
            pass

    def refresh_posting_tab(self):
        """Due-accounts preview for the Posting tab."""
        if not hasattr(self, "_posting_list"):
            return
        ordered = self._due_accounts_ordered()
        total_posts = sum(c for _u, c in ordered)
        self._posting_totals_var.set(
            f"Due: {len(ordered)} accounts • {total_posts} posts")
        self._posting_list.delete(0, "end")
        for i, (u, c) in enumerate(ordered, 1):
            self._posting_list.insert("end", f"{i}. @{u} — {c} posts")
        if not ordered:
            self._posting_list.insert(
                "end", "(Abhi koi due posting nahi hai)")

    def _posting_start_run(self):
        """Start posting from the Posting tab: N accounts, or all."""
        ordered = self._due_accounts_ordered()
        if not ordered:
            messagebox.showinfo(
                "Posting",
                "Abhi koi due posting nahi hai — koi account post "
                "karne ko tayyar nahi.",
                parent=self.root)
            self.status("Posting tab: abhi koi due posting nahi hai.")
            return
        try:
            amount = int(self._posting_amount_var.get().strip())
        except ValueError:
            amount = 5
        amount = max(1, min(20, amount))
        usernames = [u for u, _c in ordered]
        if self._posting_all_var.get():
            # Sab: har batch mein `amount` accounts, har batch ke baad
            # poochho (beech mein account theek karne ka mauqa).
            threading.Thread(target=self._run_account_batches,
                             args=(usernames, amount),
                             daemon=True).start()
            self.status(f"Posting tab: {len(usernames)} accounts ki due "
                        f"posting {amount} ke batch mein shuru…")
        else:
            # Sirf `amount` accounts, ek batch, bina poochhe.
            picked = usernames[:amount]
            threading.Thread(target=self._run_account_batches,
                             args=(picked, len(picked), None),
                             daemon=True).start()
            self.status(f"Posting tab: {len(picked)} accounts ki due "
                        "posting shuru…")

    def retime_queue_jobs(self):
        """Change the schedule of ALREADY-QUEUED posts, by hand.

        Scope follows the bulk-action rule: ticked (✓) or highlighted
        rows win over the filter; with no selection, the filtered
        account's waiting jobs are the scope (shown with its count
        in the dialog, and applied only when she presses Lagao);
        with neither a filter nor a selection, nothing happens
        except asking for a scope first. A selection that points
        outside the filter is refused instead of guessed at. Only
        waiting jobs are re-timed — done/failed/paused jobs are
        never touched. The new times are written in queue order:
        first job at the chosen start, each next one stagger-hours
        later (0 = all at the same time).
        """
        filt = self.queue_filter_var.get().strip() \
            if hasattr(self, "queue_filter_var") else "All accounts"
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        matched = []
        for j in jobs:
            acc = j.get("account", "")
            if j.get("via") == "meta":
                acc = "📘 " + acc
            if filt and filt != "All accounts" and acc != filt:
                continue
            matched.append(j)
        selected_ids = (set(self.queue_checked)
                        | {j.get("id") for j in self.selected_jobs()})
        selected_here = selected_ids & {j.get("id") for j in matched}
        if selected_ids and filt != "All accounts" \
                and not selected_here:
            messagebox.showinfo(
                "Time badlo",
                "Selected posts aur filter alag accounts ke hain — "
                "pehle Show mein wohi account chuno jis ki posts "
                "select ki hain, ya selection hata do.")
            self.status("Time badlo: filter aur selection ek nahi hain.")
            return
        if selected_here:
            scope = [j for j in matched
                     if j.get("id") in selected_here
                     and j.get("status") == "waiting"]
            scope_label = f"{len(scope)} selected posts"
            paused_sel = sum(1 for j in matched
                             if j.get("id") in selected_here
                             and j.get("status") == "paused")
            if not scope:
                self.status("Selected posts mein koi waiting post nahi "
                            "hai — done/paused posts ki time nahi badli "
                            "ja sakti.")
                return
        elif filt and filt != "All accounts":
            scope = [j for j in matched
                     if j.get("status") == "waiting"]
            scope_label = f"{len(scope)} posts — {filt}"
            paused_sel = 0
            if not scope:
                self.status(f"Time badalne ko kuch nahi hai — {filt} ki "
                            "koi waiting post nahi hai.")
                return
        else:
            messagebox.showinfo(
                "Time badlo",
                "Pehle koi account chuno (Show) ya posts tick / "
                "highlight karo — warna pata nahi chalega kin ki "
                "time badalni hai.")
            self.status("Time badalne ke liye pehle scope chuno.")
            return
        self._retime_dialog([j.get("id") for j in scope], scope_label,
                            paused_sel, scope[0])

    def _retime_dialog(self, ids, scope_label, paused_sel, first_job):
        """Dialog: new start date/time + stagger, applied on Lagao."""
        from datetime import datetime
        top = tk.Toplevel(self.root)
        top.title("Time badlo")
        sched = (first_job.get("scheduled_at") or "").strip()
        d0, t0 = "", ""
        if len(sched) >= 16 and sched[4:5] == "-" and sched[7:8] == "-":
            d0, t0 = sched[:10], sched[11:16]
        if not d0:
            d0 = datetime.now().strftime("%Y-%m-%d")
        if not t0:
            t0 = "20:30"
        ttk.Label(top, text=f"⏳ {scope_label} ki time badlo",
                  font=(self.font_name, 11, "bold")).pack(
                      anchor="w", padx=10, pady=(10, 2))
        if paused_sel:
            ttk.Label(top, text=f"({paused_sel} paused posts ki time "
                                "nahi badli jaye gi.)").pack(
                                    anchor="w", padx=10)
        row = ttk.Frame(top)
        row.pack(fill="x", padx=10, pady=(8, 0))
        ttk.Label(row, text="Pehli post:").pack(side="left")
        date_var = tk.StringVar(value=d0)
        ttk.Entry(row, textvariable=date_var, width=12).pack(
            side="left", padx=(6, 0))
        ttk.Label(row, text="(YYYY-MM-DD)").pack(side="left", padx=(4, 0))
        time_var = tk.StringVar(value=t0)
        ttk.Entry(row, textvariable=time_var, width=7).pack(
            side="left", padx=(6, 0))
        ttk.Label(row, text="(HH:MM)").pack(side="left", padx=(4, 0))
        row2 = ttk.Frame(top)
        row2.pack(fill="x", padx=10, pady=(8, 0))
        ttk.Label(row2, text="Har agli post ke darmiyan:").pack(
            side="left")
        stag_var = tk.StringVar(value="24")
        ttk.Spinbox(row2, from_=0, to=168, width=5,
                    textvariable=stag_var).pack(side="left", padx=(6, 0))
        ttk.Label(row2, text="ghante (0 = sab ek hi time par)").pack(
            side="left", padx=(4, 0))
        ttk.Label(top, text="Tartib wahi rahe gi jo queue mein hai — "
                            "pehli post naye waqt par, har agli us se "
                            "itne ghante baad.",
                  wraplength=430).pack(anchor="w", padx=10, pady=(8, 0))
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=10)

        def apply_retime():
            from datetime import datetime as dt
            try:
                start = dt.strptime(date_var.get().strip() + " "
                                    + time_var.get().strip(),
                                    "%Y-%m-%d %H:%M")
                stag = int(stag_var.get().strip())
                if stag < 0 or stag > 168:
                    raise ValueError
            except ValueError:
                messagebox.showwarning(
                    "Time badlo",
                    "Date YYYY-MM-DD aur time HH:MM mein likho, aur "
                    "waqfa 0–168 ghante ke darmiyan rakho.")
                return
            self._retime_apply(ids, start, stag)
            top.destroy()

        ttk.Button(btns, text="✅ Lagao",
                   command=apply_retime).pack(side="left")
        ttk.Button(btns, text="Cancel",
                   command=top.destroy).pack(side="left", padx=(6, 0))

    def _retime_apply(self, ids, start, stagger_hours):
        """Rewrite scheduled_at for the given jobs, in queue order."""
        from datetime import timedelta
        with app.QUEUE_LOCK:
            by_id = {j.get("id"): j for j in app.QUEUE}
            n = 0
            for jid in ids:
                job = by_id.get(jid)
                if not job or job.get("status") != "waiting":
                    continue
                when = start + timedelta(hours=stagger_hours * n)
                job["scheduled_at"] = when.strftime("%Y-%m-%dT%H:%M")
                n += 1
        app.save_queue()
        self.refresh_queue()
        self.status(f"{n} posts ki time badal di gayi — pehli "
                    f"{start.strftime('%Y-%m-%d %H:%M')} par.")

    def move_account_jobs(self):
        """Move ALREADY-QUEUED posts to another account, by hand.

        Scope follows the bulk-action rule (same as Time badlo):
        ticked (✓) or highlighted rows win over the filter; with no
        selection, the filtered account's waiting jobs are the scope
        (shown with its count in the dialog, and moved only when she
        presses Lagao); with neither a filter nor a selection,
        nothing happens except asking for a scope first. A selection
        that points outside the filter is refused instead of guessed
        at. Only waiting jobs move — done/failed/paused jobs are
        never touched. Times, captions, covers and videos stay
        exactly as queued; moving to a 📘 Meta account also switches
        those jobs to the Meta route (via + ig_id), moving to a plain
        account switches them back to the API route.
        """
        filt = self.queue_filter_var.get().strip() \
            if hasattr(self, "queue_filter_var") else "All accounts"
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        matched = []
        for j in jobs:
            acc = j.get("account", "")
            if j.get("via") == "meta":
                acc = "📘 " + acc
            if filt and filt != "All accounts" and acc != filt:
                continue
            matched.append(j)
        selected_ids = (set(self.queue_checked)
                        | {j.get("id") for j in self.selected_jobs()})
        selected_here = selected_ids & {j.get("id") for j in matched}
        if selected_ids and filt != "All accounts" \
                and not selected_here:
            messagebox.showinfo(
                "Account badlo",
                "Selected posts aur filter alag accounts ke hain — "
                "pehle Show mein wohi account chuno jis ki posts "
                "select ki hain, ya selection hata do.")
            self.status("Account badlo: filter aur selection ek nahi hain.")
            return
        if selected_here:
            scope = [j for j in matched
                     if j.get("id") in selected_here
                     and j.get("status") == "waiting"]
            scope_label = f"{len(scope)} selected posts"
            paused_sel = sum(1 for j in matched
                             if j.get("id") in selected_here
                             and j.get("status") == "paused")
            if not scope:
                self.status("Selected posts mein koi waiting post nahi "
                            "hai — done/paused posts move nahi ho sakti.")
                return
        elif filt and filt != "All accounts":
            scope = [j for j in matched
                     if j.get("status") == "waiting"]
            scope_label = f"{len(scope)} posts — {filt}"
            paused_sel = 0
            if not scope:
                self.status(f"Move karne ko kuch nahi hai — {filt} ki "
                            "koi waiting post nahi hai.")
                return
        else:
            messagebox.showinfo(
                "Account badlo",
                "Pehle koi account chuno (Show) ya posts tick / "
                "highlight karo — warna pata nahi chalega kin ki "
                "account badalni hai.")
            self.status("Account badalne ke liye pehle scope chuno.")
            return
        self._accmove_dialog([j.get("id") for j in scope], scope_label,
                             paused_sel)

    def _accmove_dialog(self, ids, scope_label, paused_sel):
        """Dialog: pick the target account, applied on Lagao."""
        top = tk.Toplevel(self.root)
        top.title("Account badlo")
        ttk.Label(top, text=f"🔄 {scope_label} kis account par le jao?",
                  font=(self.font_name, 11, "bold")).pack(
                      anchor="w", padx=10, pady=(10, 2))
        if paused_sel:
            ttk.Label(top, text=f"({paused_sel} paused posts nahi "
                                "hilengi.)").pack(anchor="w", padx=10)
        row = ttk.Frame(top)
        row.pack(fill="x", padx=10, pady=(8, 0))
        ttk.Label(row, text="Naya account:").pack(side="left")
        target_var = tk.StringVar(value="")
        combo = ttk.Combobox(row, textvariable=target_var,
                             state="readonly", width=30)
        combo["values"] = self.all_account_labels()
        combo.pack(side="left", padx=(6, 0))
        ttk.Label(top, text="Time, caption aur video wahi rahen ge. "
                            "📘 Meta account par le jane se woh posts "
                            "Meta route se post hon gi (video covers "
                            "Meta par nahi lagte).",
                  wraplength=430).pack(anchor="w", padx=10, pady=(8, 0))
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=10)

        def apply_move():
            target = target_var.get().strip()
            if not target:
                messagebox.showwarning(
                    "Account badlo", "Target account chuno.")
                return
            self._accmove_apply(ids, target)
            top.destroy()

        ttk.Button(btns, text="✅ Lagao",
                   command=apply_move).pack(side="left")
        ttk.Button(btns, text="Cancel",
                   command=top.destroy).pack(side="left", padx=(6, 0))

    def _accmove_apply(self, ids, target_display):
        """Move the given jobs to the target account (live lookup)."""
        username, via, meta_ig_id = self.resolve_account(target_display)
        with app.QUEUE_LOCK:
            by_id = {j.get("id"): j for j in app.QUEUE}
            n = 0
            for jid in ids:
                job = by_id.get(jid)
                if not job or job.get("status") != "waiting":
                    continue
                if (job.get("account") == username
                        and job.get("via") == via
                        and job.get("meta_ig_id") == meta_ig_id):
                    continue
                job["account"] = username
                job["via"] = via
                job["meta_ig_id"] = meta_ig_id
                n += 1
        app.save_queue()
        self.refresh_queue()
        if n:
            self.status(f"{n} posts {target_display} par kar di gayi.")
        else:
            self.status("Koi post nahi hili — woh pehle se isi "
                        "account par hain.")

    def retry_job(self):
        job = self.selected_job()
        if not job:
            # Forgiving fallback: a ticked (✓) failed row counts too, so
            # ticking a failed post and pressing Retry just works.
            checked = [j for j in self.checked_jobs()
                       if j.get("status") == "failed"]
            job = checked[0] if checked else None
        if not job:
            messagebox.showinfo("Retry", "Select a post in the queue first.")
            return
        if job.get("status") == "needs_code":
            self.status("Enter the login code in the box above, then press Send code.")
            return
        job["status"] = "waiting"
        job["message"] = ""
        job["code"] = ""
        app.save_queue()
        app.start_single_job(job)
        self.status("Retrying…")

    def remove_job(self):
        jobs = self.checked_jobs() or self.selected_jobs()
        if not jobs:
            messagebox.showinfo(
                "Stop / Delete",
                "Tick the ✓ box on the posts you want to stop, "
                "then press this button again.")
            return
        ids = {j["id"] for j in jobs}
        with app.QUEUE_LOCK:
            app.QUEUE[:] = [j for j in app.QUEUE if j.get("id") not in ids]
        self.queue_checked -= ids
        app.save_queue()
        self.refresh_queue()
        self.status(f"Stopped & deleted {len(jobs)} post(s). 🛑")

    def clear_finished(self):
        with app.QUEUE_LOCK:
            app.QUEUE[:] = [j for j in app.QUEUE
                            if j.get("status") not in ("done", "failed")]
        app.save_queue()

    def clear_all_queue(self):
        """Clear ONE account's posts — never all accounts at once.

        The old "Clear ALL" wiped every account's queue in one click,
        which once destroyed a whole multi-account queue in a minute.
        That option is gone on purpose: with "All accounts" shown,
        this button deletes NOTHING and only asks the user to pick
        an account first. With an account filter on, it clears just
        that account's posts, with a confirmation naming the account
        and the count.
        """
        filt = self.queue_filter_var.get().strip() \
            if hasattr(self, "queue_filter_var") else "All accounts"
        if not filt or filt == "All accounts":
            messagebox.showinfo(
                "Clear account",
                "Sab accounts ki posts ek saath delete karne ka option "
                "khatam kar diya gaya hai — ye bahut risky tha.\n\n"
                "Pehle Show mein koi account chuno, phir Clear dabao — "
                "sirf us account ki posts delete hongi.")
            self.status("Clear karne ke liye pehle koi account chuno.")
            return
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        scope = []
        for j in jobs:
            acc = j.get("account", "")
            if j.get("via") == "meta":
                acc = "📘 " + acc
            if acc != filt:
                continue
            scope.append(j)
        if not scope:
            self.status(f"Clear karne ko kuch nahi hai — {filt} ki koi "
                        "post nahi hai.")
            return
        n = len(scope)
        if not messagebox.askyesno(
                f"Clear {filt}",
                f"Delete {n} posts of {filt}?\n\n"
                "Sirf is account ki posts delete hongi, baaki "
                "accounts ki posts mehfooz rahein gi."):
            return
        drop = {j.get("id") for j in scope}
        with app.QUEUE_LOCK:
            app.QUEUE[:] = [j for j in app.QUEUE
                            if j.get("id") not in drop]
        self.queue_checked -= drop
        app.save_queue()
        self.refresh_queue()
        self.status(f"Cleared {n} posts of {filt}.")

    def refresh_queue(self):
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        live = {j.get("id") for j in jobs}
        self.queue_checked &= live  # drop ticks for jobs that are gone
        # account filter: show only the picked account's jobs
        filt = self.queue_filter_var.get().strip() \
            if hasattr(self, "queue_filter_var") else "All accounts"
        # The Clear button's label follows the filter, so it always
        # shows what it will actually clear.
        if hasattr(self, "clear_all_btn"):
            self.clear_all_btn.config(
                text=f"🗑 Clear {filt}" if filt != "All accounts"
                else "🗑 Clear account")
        rows = []
        shown = []
        for j in jobs:
            acc = j.get("account", "")
            if j.get("via") == "meta":
                acc = "📘 " + acc
            if filt and filt != "All accounts" and acc != filt:
                continue
            shown.append(j)
            st = j.get("status", "")
            label = {"waiting": "⏳ waiting", "uploading": "📤 uploading",
                     "done": "✅ posted", "failed": "❌ failed",
                     "needs_code": "📱 code needed"}.get(st, st)
            when = j.get("scheduled_at") or "Now"
            if when != "Now":
                when = when.replace("T", " ")
            rows.append((j["id"], acc, short(j.get("filename")),
                         when, f"{label} {j.get('message','')}".strip()))
        for tree in self.queue_trees:
            tree.delete(*tree.get_children())
            for rid, acc, fn, when, status in rows:
                mark = "☑" if rid in self.queue_checked else "☐"
                tree.insert("", "end", iid=rid,
                            values=(mark, acc, fn, when, status))
        # posted vs remaining counter (respects the account filter)
        if hasattr(self, "queue_count_var"):
            done = sum(1 for j in shown if j.get("status") == "done")
            remaining = sum(1 for j in shown
                            if j.get("status") in ("waiting", "uploading",
                                                   "needs_code"))
            failed = sum(1 for j in shown if j.get("status") == "failed")
            txt = f"✅ {done} posted • ⏳ {remaining} remaining"
            if failed:
                txt += f" • ❌ {failed} failed"
            self.queue_count_var.set(txt)

    # ---------------- account schedule overview ----------------
    def show_account_schedule(self):
        """One window: every account with posted / remaining / paused /
        failed counts and its next scheduled post.

        Double-click a row (or 'Queue mein dikhao') to jump the Queue
        filter to that account.
        """
        top = tk.Toplevel(self.root)
        top.title("Accounts ka schedule")
        top.geometry("980x460")
        self._sched_top = top
        ttk.Label(top, text="Har account ki posts — kitni ho gayin, "
                  "kitni baaki hain.",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10,
                                                     pady=(10, 2))
        self._sched_summary_var = tk.StringVar()
        ttk.Label(top, textvariable=self._sched_summary_var).pack(anchor="w",
                                                                 padx=10)
        cols = ("account", "posted", "remaining", "paused", "failed",
                "next", "board")
        wrap = ttk.Frame(top)
        wrap.pack(fill="both", expand=True, padx=10, pady=8)
        tree = ttk.Treeview(wrap, columns=cols, show="headings", height=14)
        self._sched_tree = tree
        for c, t, w in (("account", "Account", 180),
                        ("posted", "✅ Posted", 75),
                        ("remaining", "⏳ Baaki", 75),
                        ("paused", "⏸ Paused", 75),
                        ("failed", "❌ Failed", 75),
                        ("next", "🕐 Agli post", 140),
                        ("board", "📌 Board", 300)):
            tree.heading(c, text=t)
            tree.column(c, width=w,
                        anchor="center"
                        if c not in ("account", "board") else "w")
        vsb = ttk.Scrollbar(wrap, orient="vertical",
                            command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        tree.bind("<Double-1>", lambda _e: self._sched_show_in_queue())
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=(0, 10))
        ttk.Button(btns, text="🔄 Refresh",
                   command=self._fill_account_schedule).pack(side="left")
        ttk.Button(btns, text="Queue mein dikhao",
                   command=self._sched_show_in_queue).pack(side="left",
                                                          padx=(6, 0))
        ttk.Button(btns, text="📌 Boards",
                   command=self._sched_show_boards).pack(side="left",
                                                        padx=(6, 0))
        ttk.Button(btns, text="Band karein",
                   command=top.destroy).pack(side="right")
        ttk.Label(top, text="Row par double-click karein to Queue mein "
                  "us account ki posts dikh jayein gi. Boards dekhne / "
                  "copy karne ke liye row select kar ke 📌 Boards dabayein.",
                  font=("Segoe UI", 8), foreground="gray").pack(anchor="w",
                                                               padx=10,
                                                               pady=(0, 8))
        self._fill_account_schedule()

    def _fill_account_schedule(self):
        tree = self._sched_tree
        tree.delete(*tree.get_children())
        with app.QUEUE_LOCK:
            jobs = list(app.QUEUE)
        stats = {}

        def row_for(label):
            return stats.setdefault(label, {"posted": 0, "remaining": 0,
                                            "paused": 0, "failed": 0,
                                            "next": None, "now": False})

        for j in jobs:
            acc = j.get("account", "")
            label = ("📘 " + acc) if j.get("via") == "meta" else acc
            row = row_for(label)
            st = j.get("status", "")
            if st == "done":
                row["posted"] += 1
            elif st == "failed":
                row["failed"] += 1
            elif st == "paused":
                row["paused"] += 1
            elif st in ("waiting", "uploading", "needs_code"):
                row["remaining"] += 1
            if st in ("waiting", "paused"):
                when = j.get("scheduled_at") or ""
                if not when:
                    row["now"] = True
                elif row["next"] is None or when < row["next"]:
                    row["next"] = when
        # listed accounts first, in list order, then job-only accounts
        ordered = []
        for a in app.load_accounts():
            ordered.append((a, app.account_display(a)))
        seen = set(app.load_accounts())
        for label in stats:
            raw = label[3:] if label.startswith("📘 ") else label
            if raw not in seen:
                ordered.append((raw, label))
        self._sched_filter = {}
        total = {"posted": 0, "remaining": 0, "paused": 0, "failed": 0}
        with_scheduled = 0
        for raw, shown in ordered:
            label = ("📘 " + raw) if shown.startswith("📘 ") else raw
            row = {"posted": 0, "remaining": 0, "paused": 0, "failed": 0,
                   "next": None, "now": False}
            for key in (raw, "📘 " + raw):
                r = stats.get(key)
                if not r:
                    continue
                for k in ("posted", "remaining", "paused", "failed"):
                    row[k] += r[k]
                row["now"] = row["now"] or r["now"]
                if r["next"] and (row["next"] is None
                                  or r["next"] < row["next"]):
                    row["next"] = r["next"]
            for k in total:
                total[k] += row[k]
            if row["remaining"] + row["paused"] > 0:
                with_scheduled += 1
            if row["now"]:
                nxt = "foran (abhi)"
            elif row["next"]:
                nxt = row["next"].replace("T", " ")
            elif row["posted"] + row["failed"] > 0:
                nxt = "— (koi baaki nahi)"
            else:
                nxt = "— (koi post nahi)"
            saved = app.get_account_links(raw)
            if saved:
                board = app.board_short_link(raw) or "—"
                if len(saved) > 1:
                    board += f" (+{len(saved) - 1})"
            else:
                board = "—"
            iid = tree.insert("", "end", values=(shown, row["posted"],
                                                 row["remaining"],
                                                 row["paused"], row["failed"],
                                                 nxt, board))
            self._sched_filter[iid] = label
        none_count = len(ordered) - with_scheduled
        self._sched_summary_var.set(
            f"📊 {with_scheduled} accounts mein posts baaki hain • "
            f"{none_count} accounts mein koi post schedule nahi\n"
            f"Kul: ✅ {total['posted']} posted • ⏳ {total['remaining']} "
            f"baaki • ⏸ {total['paused']} paused • "
            f"❌ {total['failed']} failed")

    def _sched_show_in_queue(self):
        sel = self._sched_tree.selection()
        if not sel:
            return
        label = self._sched_filter.get(sel[0])
        if label and hasattr(self, "queue_filter_var"):
            self.queue_filter_var.set(label)
            self.refresh_queue()
        if hasattr(self, "_sched_top"):
            self._sched_top.destroy()

    def _sched_show_boards(self):
        sel = self._sched_tree.selection()
        if not sel:
            return
        label = self._sched_filter.get(sel[0], "")
        raw = label[3:] if label.startswith("📘 ") else label
        if raw:
            self.show_account_boards(raw)

    def show_account_boards(self, account):
        """Every saved board link for one account, selectable + copyable."""
        links = app.get_account_links(account)
        top = tk.Toplevel(self.root)
        top.title(f"{account} ke boards")
        top.geometry("640x380")
        self._boards_top = top
        ttk.Label(top, text=f"@{account} ke save hue boards "
                  f"({len(links)})",
                  font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10,
                                                     pady=(10, 2))
        if not links:
            ttk.Label(top, text="Is account ke liye koi board save nahi "
                      "hai.\nBulk section mein board link save karein to "
                      "woh yahan aaye ga.").pack(anchor="w", padx=10,
                                                 pady=8)
            ttk.Button(top, text="Band karein",
                       command=top.destroy).pack(padx=10, pady=8,
                                                 anchor="w")
            return
        wrap = ttk.Frame(top)
        wrap.pack(fill="both", expand=True, padx=10, pady=8)
        lb = tk.Listbox(wrap, height=12)
        self._boards_listbox = lb
        for l in links:
            lb.insert("end", l)
        vsb = ttk.Scrollbar(wrap, orient="vertical",
                            command=lb.yview)
        lb.configure(yscrollcommand=vsb.set)
        lb.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        lb.bind("<Double-1>", lambda _e: self._copy_board_link())
        self._boards_status_var = tk.StringVar()
        ttk.Label(top, textvariable=self._boards_status_var).pack(anchor="w",
                                                                 padx=10)
        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=10, pady=(0, 10))
        ttk.Button(btns, text="📋 Copy",
                   command=self._copy_board_link).pack(side="left")
        ttk.Button(btns, text="Band karein",
                   command=top.destroy).pack(side="right")

    def _copy_board_link(self):
        sel = self._boards_listbox.curselection()
        if not sel:
            self._boards_status_var.set("Pehle koi board select karein.")
            return
        link = self._boards_listbox.get(sel[0])
        self.root.clipboard_clear()
        self.root.clipboard_append(link)
        self._boards_status_var.set("Copy ho gaya — ab bulk box mein "
                                    "paste kar sakte hain.")

    # ---------------- links ----------------
    def detect_platform(self, _event=None):
        name = app.link_source_name(self.link_entry.get())
        self.platform_var.set(f"({name})" if name else "")

    def add_link(self):
        link = self.link_entry.get().strip()
        raw_account = self.link_selected_account()
        caption = self.link_caption.get("1.0", "end").strip()
        mode = self.link_mode.get()
        if not app.link_source_name(link):
            messagebox.showwarning(
                "Link", "Paste an Instagram, TikTok, YouTube or Pinterest link.")
            return
        account, via, meta_ig_id = self.resolve_account(raw_account)
        if via == "api" and not app.account_can_post(account):
            messagebox.showwarning("Account", "Add this account first.")
            return
        if via == "meta" and "instagram.com" in link.lower():
            messagebox.showwarning(
                "Link",
                "Downloading from Instagram links needs a password account. "
                "Pick a regular account for Instagram links, or use a "
                "TikTok/YouTube/Pinterest link with the Facebook account.")
            return
        if mode == "daily":
            t = parse_time(self.link_daily.get())
            if not t:
                messagebox.showwarning("Time", "Enter a daily time like 10:00.")
                return
            w = {"id": secrets.token_hex(6), "link": link, "account": account,
                 "caption": caption, "daily_time": t, "last_run": "",
                 "status": "active", "message": "Will download and post daily.",
                 "via": via, "meta_ig_id": meta_ig_id}
            with app.QUEUE_LOCK:
                app.WATCHES.append(w)
            app.save_watches()
            self.status(f"Daily repost set for @{account} at {t}.")
        else:
            sched = ""
            if mode == "once":
                dt = parse_datetime(self.link_sched.get())
                if not dt:
                    messagebox.showwarning(
                        "Time", "Enter a date and time like 2026-10-17 10:30.")
                    return
                sched = dt.strftime("%Y-%m-%dT%H:%M")
            task = {"id": secrets.token_hex(6), "link": link,
                    "account": account, "caption": caption, "mode": mode,
                    "scheduled_at": sched, "status": "waiting",
                    "message": "Waiting to download…",
                    "via": via, "meta_ig_id": meta_ig_id}
            app.LINK_TASKS.append(task)
            threading.Thread(target=app.process_link, args=(task,),
                             daemon=True).start()
            self.status("Download started — watch its progress below.")
        self.link_entry.delete(0, "end")
        self.link_caption.delete("1.0", "end")
        self.platform_var.set("")

    def add_links(self):
        """Add several post links at once — one download task per link."""
        raw = self.links_text.get("1.0", "end").strip().splitlines()
        links = [l.strip() for l in raw if l.strip()]
        if not links:
            messagebox.showwarning("Links", "Paste one or more links first.")
            return
        raw_account = self.link_selected_account()
        caption = self.link_caption.get("1.0", "end").strip()
        mode = self.links_mode.get()
        account, via, meta_ig_id = self.resolve_account(raw_account)
        if via == "api" and not app.account_can_post(account):
            messagebox.showwarning("Account", "Add this account first.")
            return
        if mode == "daily":
            t = parse_time(self.links_daily.get())
            if not t:
                messagebox.showwarning("Time", "Enter a daily time like 10:00 AM.")
                return
        elif mode == "once":
            dt = parse_datetime(self.links_sched.get())
            if not dt:
                messagebox.showwarning(
                    "Time", "Enter a date and time like 2026-10-18 10:30 AM.")
                return
            try:
                every = max(1, min(48, int(self.links_every.get())))
            except Exception:
                every = 2
        else:
            every = 0
        added = 0
        for link in links:
            if not app.link_source_name(link):
                continue
            if via == "meta" and "instagram.com" in link.lower():
                continue
            if mode == "daily":
                w = {"id": secrets.token_hex(6), "link": link,
                     "account": account, "caption": caption, "daily_time": t,
                     "last_run": "", "status": "active",
                     "message": "Will download and post daily.",
                     "via": via, "meta_ig_id": meta_ig_id}
                with app.QUEUE_LOCK:
                    app.WATCHES.append(w)
                added += 1
                continue
            # "Schedule from": space links out every N hours from start time
            link_sched = ""
            if mode == "once":
                from datetime import timedelta
                link_sched = (dt + timedelta(hours=added * every)).strftime(
                    "%Y-%m-%dT%H:%M")
            task = {"id": secrets.token_hex(6), "link": link,
                    "account": account, "caption": caption, "mode": mode,
                    "scheduled_at": link_sched, "status": "waiting",
                    "message": "Waiting to download…",
                    "via": via, "meta_ig_id": meta_ig_id}
            app.LINK_TASKS.append(task)
            threading.Thread(target=app.process_link, args=(task,),
                             daemon=True).start()
            added += 1
        self.links_text.delete("1.0", "end")
        if mode == "daily":
            app.save_watches()
        if added:
            self.status(f"{added} links added — downloading… ✅")
        else:
            messagebox.showwarning("Links", "No valid links found.")

    @staticmethod
    def pinterest_source_name(url):
        """'pinterest.com/username' -> '@username',
        'pinterest.com/username/board' -> '@username/board'."""
        import re
        m = re.match(
            r"https?://(?:www\.)?pinterest\.[a-z.]+/([^/?#]+)(?:/([^/?#]+))?",
            url.strip(), re.I)
        if not m:
            return url.strip()
        name = "@" + m.group(1)
        slug = (m.group(2) or "").lower()
        if slug and slug != "pins":
            name += "/" + m.group(2)
        return name

    def bulk_history_dialog(self):
        """📋 Which Pinterest link was bulk-run for which account.

        Two parts: saved bulk runs (recorded from now on — one click
        refills the link + account above) and, for older work, the
        per-account posted-pin record rebuilt from posted.json, so
        she can open a sample pin on Pinterest and see its board.
        """
        runs = app.load_bulk_history()
        summary = app.posted_summary()
        top = tk.Toplevel(self.root)
        top.title("📋 Purane bulk links")
        top.geometry("680x520")
        top.transient(self.root)
        top.grab_set()
        ttk.Label(
            top,
            text=("Kis account pe konsa Pinterest link chalaya tha — "
                  "ye raha record.\n"
                  "Dobara chalana ho to 'Bhar do' dabao, link, "
                  "account aur pin range khud bhar jayegi."),
            font=("Segoe UI", 10)).pack(padx=12, pady=(12, 4))
        cbox = ttk.Frame(top)
        cbox.pack(fill="both", expand=True, padx=12, pady=(4, 0))
        canvas = tk.Canvas(cbox, highlightthickness=0)
        vsb = ttk.Scrollbar(cbox, orient="vertical",
                            command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        box = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=box, anchor="nw")
        box.bind("<Configure>",
                 lambda e: canvas.configure(
                     scrollregion=canvas.bbox("all")))

        def wheel(e):
            canvas.yview_scroll(-1 if e.delta > 0 else 1, "units")
        canvas.bind("<MouseWheel>", wheel)
        box.bind("<MouseWheel>", wheel)

        copied_lbl = ttk.Label(top, text="", font=("Segoe UI", 9))

        def copy_link(url):
            try:
                self.root.clipboard_clear()
                self.root.clipboard_append(url)
                self.root.update_idletasks()
                copied_lbl.config(
                    text="✅ Copy ho gaya — browser mein ja ke "
                         "paste (Ctrl+V) karo")
            except Exception:
                pass

        def fmt_at(iso):
            try:
                return datetime.fromisoformat(iso).strftime(
                    "%d %b, %I:%M %p")
            except Exception:
                return iso or ""

        def refill(link, account, start_pin=1, max_pins=0):
            self.bulk_link.delete(0, "end")
            self.bulk_link.insert(0, link)
            self.bulk_start.delete(0, "end")
            self.bulk_start.insert(0, str(start_pin or 1))
            self.bulk_limit.delete(0, "end")
            self.bulk_limit.insert(0, str(max_pins or 0))
            self._bulk_link_autofilled = link
            picked = False
            try:
                for val in self.bulk_account.cget("values"):
                    if val == account or \
                            self.resolve_account(val)[0] == account:
                        self.bulk_account.set(val)
                        picked = True
                        break
            except Exception:
                pass
            self._bulk_last_account = self.bulk_account.get().strip()
            self.refresh_attached_board()
            top.destroy()
            self.status(f"Bulk link bhar diya: {account}"
                        + ("" if picked else
                           " — account khud select kar lena"))

        ttk.Label(box, text="Chalaye hue bulk links:",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w",
                                                      pady=(2, 4))
        if runs:
            for run in runs:
                r = ttk.Frame(box)
                r.pack(fill="x", pady=2)
                txt = (f"{fmt_at(run.get('at', ''))}  •  "
                       f"{run.get('account', '')}\n{run.get('link', '')}"
                       f"   (queue: {run.get('queued', 0)}, "
                       f"pehle se posted skip: {run.get('skipped', 0)})")
                _sp = run.get("start_pin", 1) or 1
                _mp = run.get("max_pins", 0) or 0
                if _sp > 1 or _mp > 0:
                    _end = _sp + _mp - 1 if _mp else "aakhir tak"
                    txt += f"   pins {_sp}–{_end}"
                lbl = ttk.Label(r, text=txt, font=("Segoe UI", 9))
                lbl.pack(side="left")
                lbl.bind("<MouseWheel>", wheel)
                ttk.Button(
                    r, text="Bhar do",
                    command=lambda l=run.get("link", ""),
                    a=run.get("account", ""),
                    s=run.get("start_pin", 1),
                    m=run.get("max_pins", 0): refill(l, a, s, m)).pack(
                        side="right")
                ttk.Button(
                    r, text="📋 Copy",
                    command=lambda l=run.get("link", ""): copy_link(l)
                    ).pack(side="right", padx=(0, 4))
        else:
            ttk.Label(
                box,
                text=("(Abhi koi bulk run save nahi hai. Aaj ke baad "
                      "jo bulk chalaogi,\nwo yahan khud save ho "
                      "jayega — phir kabhi yaad nahi rakhna padega.)"),
                font=("Segoe UI", 9)).pack(anchor="w")
        ttk.Label(box, text="Har account pe post hui pins (purana record):",
                  font=("Segoe UI", 11, "bold")).pack(anchor="w",
                                                      pady=(12, 4))
        if summary:
            for acct in sorted(summary):
                e = summary[acct]
                ttk.Label(
                    box,
                    text=(f"• {acct} — {e['count']} pins post huin "
                          f"({fmt_at(e['first'])} se "
                          f"{fmt_at(e['last'])} tak)"),
                    font=("Segoe UI", 10, "bold")).pack(anchor="w")
                for src in e["samples"]:
                    sr = ttk.Frame(box)
                    sr.pack(fill="x")
                    sl = ttk.Label(sr, text=f"     {src}",
                                   font=("Segoe UI", 8))
                    sl.pack(side="left")
                    sl.bind("<MouseWheel>", wheel)
                    ttk.Button(
                        sr, text="📋 Copy",
                        command=lambda s=src: copy_link(s)).pack(
                            side="left", padx=(6, 0))
        else:
            ttk.Label(box, text="(Abhi koi pin post nahi hui.)",
                      font=("Segoe UI", 9)).pack(anchor="w")
        ttk.Label(
            top,
            text=("Tip: kisi bhi pin link ko browser mein kholo gi to "
                  "Pinterest pe us ka board/profile nazar aa jayega —\n"
                  "wahi link dobara bulk mein use karna hai."),
            font=("Segoe UI", 9)).pack(padx=12, pady=(8, 4))
        copied_lbl.pack(padx=12, pady=(0, 2))
        ttk.Button(top, text="Band karo",
                   command=top.destroy).pack(pady=(0, 10))

    def cancel_bulk(self):
        """Stop ALL running bulk downloads after the current pin.

        To stop just one run, use that run's own ⛔ Roko button in
        its row below — the other runs keep going.
        """
        for rs in self.bulk_runs.values():
            if not rs["done"]:
                rs["cancel"] = True
        self.bulk_progress.config(text="Cancelling…")
        self.status("Bulk download cancelling… ⛔")

    def check_pinterest_count(self):
        """Show how many pins a Pinterest profile/board has (no download)."""
        link = self.bulk_link.get().strip()
        if "pinterest." not in link.lower():
            messagebox.showwarning(
                "Link", "Paste your Pinterest profile or board link first.")
            return
        self.bulk_progress.config(text="Counting pins…")
        self.set_bulk_summary("Counting pins, please wait…")

        def run():
            try:
                pins = app.list_pinterest_pins(link)
                vids = sum(1 for p in pins if p["is_video"])
                # pidgets mislabels some videos; for small accounts verify
                # via pin pages (fast), for large ones skip (too slow)
                if len(pins) <= 20:
                    for p in pins:
                        if not p["is_video"] and p.get("url"):
                            try:
                                if app._pinterest_page_video_url(p["url"]):
                                    vids += 1
                                    p["is_video"] = True
                            except Exception:
                                pass
                photos = len(pins) - vids
                src = self.pinterest_source_name(link)
                msg = (f"📌 Pinterest {src}\n"
                       f"Found {len(pins)} pins "
                       f"({photos} photos, {vids} videos).\n"
                       f"Set 'Download only the first N pins' above, then press\n"
                       f"'⬇ Download all pins & queue them'.")
                self.root.after(0, lambda: [
                    self.bulk_progress.config(
                        text=f"Found {len(pins)} pins."),
                    self.set_bulk_summary(msg)])
            except Exception as e:
                err = str(e)
                self.root.after(0, lambda: [
                    self.bulk_progress.config(text=""),
                    self.set_bulk_summary(f"Couldn't read that link:\n{err}")])

        threading.Thread(target=run, daemon=True).start()

    def start_bulk(self):
        link = self.bulk_link.get().strip()
        raw_account = self.bulk_selected_account()
        caption = self.link_caption.get("1.0", "end").strip()
        mode = self.bulk_mode.get()
        kind = {"Both": "both", "Videos only": "videos",
                "Photos only": "photos"}[self.bulk_kind.get()]
        if "pinterest." not in link.lower():
            messagebox.showwarning(
                "Link", "Paste your Pinterest profile or board link.")
            return
        account, via, meta_ig_id = self.resolve_account(raw_account)
        if via == "api" and not app.account_can_post(account):
            messagebox.showwarning("Account", "Add this account first.")
            return
        start_at = None
        try:
            every = max(1, min(48, int(self.bulk_every.get())))
        except ValueError:
            every = 2
        # Pin range for this run: start_pin is 1-based (pin #1 is the
        # first pin fetched from the board, within the chosen kind).
        # Read once here so every run keeps its own range even when
        # several runs go at once.
        try:
            start_pin = int(self.bulk_start.get() or 1)
        except ValueError:
            start_pin = 1
        if start_pin < 1:
            start_pin = 1
        try:
            max_pins = int(self.bulk_limit.get() or 0)
        except ValueError:
            max_pins = 0
        if max_pins < 0:
            max_pins = 0
        if start_pin > 1 and max_pins > 0:
            range_note = f" • pins {start_pin}–{start_pin + max_pins - 1}"
        elif start_pin > 1:
            range_note = f" • pins {start_pin} se aakhir tak"
        elif max_pins > 0:
            range_note = f" • pins 1–{max_pins}"
        else:
            range_note = ""
        if mode == "schedule":
            start_at = parse_datetime(self.bulk_sched.get())
            if not start_at:
                messagebox.showwarning(
                    "Time", "Pick a start date and time with the 📅 button.")
                return
        self.bulk_progress.config(text="Reading your Pinterest…")
        self.status("Bulk download started…")
        # This run's own state and row: its progress and its stop
        # button belong to it alone, so the next account's run can
        # start right away without touching this one.
        self._bulk_run_seq += 1
        _rid = self._bulk_run_seq
        _rs = {"cancel": False, "done": False}
        _row = ttk.Frame(self.bulk_runs_frame)
        _row.pack(fill="x", pady=1)
        _lbl = ttk.Label(_row, text=f"⏳ {account}: shuru ho raha hai…",
                         font=("Segoe UI", 9))
        _lbl.pack(side="left", fill="x", expand=True)

        def _cancel_this_run(rs=_rs, lbl=_lbl):
            rs["cancel"] = True
            lbl.config(text=lbl.cget("text") + " (ruk raha hai… ⛔)")

        _cbtn = ttk.Button(_row, text="⛔ Roko", width=8,
                           command=_cancel_this_run)
        _cbtn.pack(side="right")
        _rs.update({"row": _row, "lbl": _lbl, "btn": _cbtn})
        self.bulk_runs[_rid] = _rs

        def _finish_run_row(queued, was_cancelled, err=""):
            _rs["done"] = True
            if err:
                _lbl.config(text=f"❌ {account}: {err}")
            elif was_cancelled:
                _lbl.config(text=f"⛔ Cancelled — {account}: "
                                 f"{queued} queued")
            else:
                _lbl.config(text=f"✅ Done — {account}: {queued} queued"
                                 f"{range_note}")
            _cbtn.config(
                text="✖",
                command=lambda: (self.bulk_runs.pop(_rid, None),
                                 _row.destroy()))
        try:
            if self.bulk_save_link.get():
                app.set_account_link(account, link)
                self._bulk_link_autofilled = link
                self.refresh_attached_board()
        except Exception:
            pass

        def progress(done, total, msg):
            def _upd():
                _lbl.config(text=f"{account}: {done}/{total} — {msg}")
                self.bulk_progress.config(text=f"{done}/{total} — {msg}")
            self.root.after(0, _upd)

        def run():
            try:
                queued, fetched, skipped = app.bulk_pinterest_queue(
                    link, account, caption, mode, start_at, every, kind,
                    progress_cb=progress, via=via, meta_ig_id=meta_ig_id,
                    max_pins=max_pins, start_pin=start_pin,
                    cancel_check=lambda: _rs["cancel"],
                    use_pin_caption=self.bulk_use_caption.get())
                src = self.pinterest_source_name(link)
                kind_word = {"videos": "videos", "photos": "photos",
                             "both": "pins"}[kind]
                summary = (f"📌 Pinterest {src}  →  📷 Instagram "
                           f"{account}\n"
                           f"{fetched} {kind_word} fetched • {queued} queued")
                if skipped:
                    summary += f" • {skipped} skipped (already posted)"
                summary += range_note
                was_cancelled = _rs["cancel"]
                if was_cancelled:
                    summary += "\n⛔ Cancelled by you."
                self.root.after(0, lambda: [
                    self.bulk_progress.config(
                        text=(f"Cancelled — {queued} queued. ⛔"
                              if was_cancelled else
                              f"Done — {queued} posts queued! ✅")),
                    self.set_bulk_summary(summary),
                    self.status(f"Bulk done: {queued} posts queued for "
                                f"{account}."),
                    _finish_run_row(queued, was_cancelled)])
            except Exception as e:
                err = str(e)
                self.root.after(0, lambda: [
                    self.bulk_progress.config(text=""),
                    messagebox.showerror("Bulk download", err),
                    self.status("Bulk download failed."),
                    _finish_run_row(0, False, err)])

        threading.Thread(target=run, daemon=True).start()

    def remove_watch(self):
        sel = self.watch_tree.selection()
        if not sel:
            return
        wid = sel[0]
        with app.QUEUE_LOCK:
            app.WATCHES[:] = [w for w in app.WATCHES if w.get("id") != wid]
        app.save_watches()
        self.status("Daily repost removed.")

    def refresh_downloads(self):
        self.dl_tree.delete(*self.dl_tree.get_children())
        for t in list(app.LINK_TASKS):
            self.dl_tree.insert("", "end", iid="t" + t["id"],
                                values=(short(t.get("link"), 40),
                                        t.get("account"),
                                        f"{t.get('status')} {t.get('message','')}".strip()))

    def refresh_watches(self):
        self.watch_tree.delete(*self.watch_tree.get_children())
        with app.QUEUE_LOCK:
            watches = list(app.WATCHES)
        for w in watches:
            msg = w.get("message") or w.get("status")
            if w.get("last_run"):
                msg += f" (last: {w['last_run']})"
            self.watch_tree.insert("", "end", iid=w["id"],
                                   values=(short(w.get("link"), 32),
                                           w.get("account"),
                                           w.get("daily_time"), msg))

    def refresh_history(self):
        self.hist_list.delete(0, "end")
        for h in app.read_history(15):
            self.hist_list.insert("end", h)

    # ---------------- 2FA codes (persistent box, never disappears) ----------------
    def refresh_codes(self):
        with app.QUEUE_LOCK:
            needy = [j for j in app.QUEUE if j.get("status") == "needs_code"]
        needy_ids = {j["id"] for j in needy}
        for jid in list(self.code_rows):
            if jid not in needy_ids:
                self.code_rows[jid][0].destroy()
                del self.code_rows[jid]
        for job in needy:
            if job["id"] not in self.code_rows:
                row = ttk.Frame(self.code_frame)
                row.pack(fill="x", pady=3)
                ttk.Label(row, text=f"@{job['account']} needs a code:",
                          font=("Segoe UI", 10, "bold")).pack(side="left")
                entry = ttk.Entry(row, width=12)
                entry.pack(side="left", padx=(8, 6))
                ttk.Button(row, text="Send code", style="Accent.TButton",
                           command=lambda jid=job["id"], e=entry:
                           self.send_code(jid, e)).pack(side="left")
                self.code_rows[job["id"]] = (row, entry)
        if self.code_rows:
            self.code_frame.pack(fill="x", pady=(8, 0), before=self.queue_frame)
        else:
            self.code_frame.pack_forget()

    def send_code(self, jid, entry):
        code = entry.get().strip()
        if not code:
            return
        with app.QUEUE_LOCK:
            job = next((j for j in app.QUEUE if j.get("id") == jid), None)
        if not job:
            return
        job["code"] = code
        job["status"] = "waiting"
        job["message"] = ""
        app.save_queue()
        app.start_single_job(job)
        self.status("Code sent — posting…")

    # ---------------- main loop ----------------
    def refresh(self):
        try:
            self.refresh_accounts()
            self.refresh_queue()
            self.refresh_downloads()
            self.refresh_watches()
            self.refresh_history()
            self.refresh_codes()
            # Only the small today-plan section refreshes live; the
            # big notification lists still rebuild on manual Refresh.
            self._refresh_today_plan()
        except Exception:
            pass
        finally:
            self.root.after(2500, self.refresh)


def main():
    app.load_queue()
    app.load_watches()
    threading.Thread(target=app.scheduler_loop, daemon=True).start()
    root = tk.Tk()
    root.withdraw()
    DesktopApp(root)
    if root.winfo_exists():
        root.deiconify()
        root.mainloop()


if __name__ == "__main__":
    main()
