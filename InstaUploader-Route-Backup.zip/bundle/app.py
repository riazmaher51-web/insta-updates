#!/usr/bin/env python3
"""
InstaUploader (portable) - post photos & videos to your Instagram accounts.

Just double-click run.bat. A page opens in your browser. No installation.
Queue up multiple posts (different accounts, different media) and post them
all at the same time. Your logins are stored ONLY on this computer.
"""

import hashlib
import html
import json
import re
import secrets
import shutil
import threading
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs
import zipfile

from PIL import Image

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
(SESSIONS := DATA / "sessions").mkdir(exist_ok=True)
(UPLOADS := DATA / "uploads").mkdir(exist_ok=True)
(ZIPMEDIA := DATA / "zipmedia").mkdir(exist_ok=True)
ACCOUNTS_FILE = DATA / "accounts.json"
PASSWORDS_FILE = DATA / "passwords.json"
QUEUE_FILE = DATA / "queue.json"
HISTORY_FILE = DATA / "history.log"
GROUPS_FILE = DATA / "groups.json"
POSTED_FILE = DATA / "posted.json"  # sources already posted, per account

# Fixed account order: every account keeps its slot, even across logout,
# removal and re-login. The registry is never shipped in any pack and is
# never deleted by logout or removal — that memory is the whole point.
ACCOUNT_REGISTRY_FILE = DATA / "account_registry.json"


def load_registry():
    try:
        data = json.loads(ACCOUNT_REGISTRY_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_registry(reg):
    ACCOUNT_REGISTRY_FILE.write_text(json.dumps(reg, indent=2),
                                     encoding="utf-8")


def _registry_key(username):
    return (username or "").strip().lower()


def registry_record(username):
    """The saved record for an account, or None."""
    reg = load_registry()
    rec = reg.get(_registry_key(username))
    return rec if isinstance(rec, dict) else None


def remember_account(username, position=None, ig_id=None, groups=None,
                     logged_out=None, login_failed=None,
                     login_failed_msg=None):
    """Record an account's slot, identity, groups and login state.

    Removal never deletes the record, so re-adding the same account
    restores its old slot and groups instead of appending at the bottom.
    """
    reg = load_registry()
    key = _registry_key(username)
    rec = reg.get(key) if isinstance(reg.get(key), dict) else {}
    rec["username"] = username
    if position is not None:
        rec["position"] = int(position)
    if ig_id is not None:
        rec["ig_id"] = str(ig_id)
    if groups is not None:
        rec["groups"] = list(groups)
    if logged_out is not None:
        rec["logged_out"] = bool(logged_out)
    if login_failed is not None:
        rec["login_failed"] = bool(login_failed)
    if login_failed_msg is not None:
        rec["login_failed_msg"] = str(login_failed_msg)
    reg[key] = rec
    save_registry(reg)
    return rec


def sync_registry_positions(accounts):
    """After any accounts save, refresh every listed account's slot."""
    reg = load_registry()
    changed = False
    for idx, username in enumerate(accounts):
        key = _registry_key(username)
        rec = reg.get(key) if isinstance(reg.get(key), dict) else {}
        if rec.get("position") != idx or rec.get("username") != username:
            rec["username"] = username
            rec["position"] = idx
            reg[key] = rec
            changed = True
    if changed:
        save_registry(reg)


def account_insert_position(username, accounts, ig_id=None):
    """Where a (re-)added account belongs: its remembered slot, else end."""
    reg = load_registry()
    rec = reg.get(_registry_key(username))
    if isinstance(rec, dict) and isinstance(rec.get("position"), int):
        return max(0, min(rec["position"], len(accounts)))
    if ig_id is not None:
        for other in reg.values():
            if isinstance(other, dict) and other.get("ig_id") == str(ig_id) \
                    and isinstance(other.get("position"), int):
                return max(0, min(other["position"], len(accounts)))
    return len(accounts)


def insert_account_ordered(accounts, username, ig_id=None):
    """Insert username at its remembered slot; never a duplicate."""
    if username.lower() in [a.lower() for a in accounts]:
        return accounts
    pos = account_insert_position(username, accounts, ig_id=ig_id)
    accounts.insert(pos, username)
    return accounts


def restore_account_groups(username):
    """Group names the account belonged to when it was last saved."""
    rec = registry_record(username)
    if rec and isinstance(rec.get("groups"), list):
        return [g for g in rec["groups"] if isinstance(g, str)]
    return []


def is_logged_out(username):
    rec = registry_record(username)
    return bool(rec and rec.get("logged_out"))


def set_logged_out(username, logged_out):
    remember_account(username, logged_out=logged_out)


def logout_account(username):
    """Disconnect an account's session only.

    The entry, password, position, groups, queue, posting history and
    uploads are all untouched — only the session file goes, so the next
    login starts fresh.
    """
    session_file = SESSIONS / f"{username}.json"
    try:
        if session_file.exists():
            session_file.unlink()
    except Exception:
        pass
    # A deliberate disconnect is not a failure: clear any stale failure mark.
    remember_account(username, logged_out=True, login_failed=False)
    return True


def mark_login_ok(username):
    """A login just succeeded: clear the logged-out and failure marks."""
    remember_account(username, logged_out=False, login_failed=False)


def mark_login_failed(username, message=""):
    """A post failed for a login reason: the account needs attention."""
    remember_account(username, login_failed=True,
                     login_failed_msg=(message or "")[:120])


_LOGIN_FAILURE_WORDS = (
    "login_required", "login required", "login", "log in", "logged out",
    "not logged in", "challenge", "checkpoint", "two-factor", "two factor",
    "bad credentials", "invalid password", "session expired",
    "suspicious login", "verification required",
    # A disabled account fails its posts but never logs in again, so it
    # must land in the Login-needed box instead of staying green.
    "disabled",
)


def looks_like_login_failure(message):
    """True when a failure message points at an auth/login problem.

    Heuristic on purpose: only job-failure messages reach this, and a
    network or media error never contains these words.
    """
    msg = (message or "").lower()
    return any(w in msg for w in _LOGIN_FAILURE_WORDS)


def account_status(username):
    """One of 'active', 'logged_out', 'login_needed'.

    Local state only — no Instagram call is made to compute it, so the
    list can refresh freely without risking the accounts. 'active' means
    the account can post right now (saved session) or can log itself in
    when a post runs (saved password). 'login_needed' means it can do
    neither, or its last post failed for a login reason.
    """
    rec = registry_record(username)
    if rec and rec.get("logged_out"):
        return "logged_out"
    if rec and rec.get("login_failed"):
        return "login_needed"
    if (SESSIONS / f"{username}.json").exists():
        return "active"
    if username in load_passwords():
        return "active"
    return "login_needed"


def account_display(username):
    """Listbox line for an account: status icon + @name."""
    prefix = {"active": "✅ ", "logged_out": "⏻ ",
              "login_needed": "⚠️ "}[account_status(username)]
    return prefix + "@" + username

# Dost-access (friend-copy activation): credentials the owner issues to a
# friend. The password is NEVER stored — only its hash. The access file is
# NOT shipped in any pack; the owner sends it to the friend herself.
ACCESS_FILE = DATA / "dost-access.json"
UPDATE_SETTINGS_FILE = DATA / "update_settings.json"


def load_update_settings():
    """Auto-update toggle, kept on this laptop only (never shipped)."""
    try:
        d = json.loads(UPDATE_SETTINGS_FILE.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return d
    except Exception:
        pass
    return {}


def save_update_settings(settings):
    try:
        UPDATE_SETTINGS_FILE.write_text(json.dumps(settings, indent=2),
                                        encoding="utf-8")
    except Exception:
        pass


POST_GAP_FILE = DATA / "post_gap.json"


def load_post_gap_minutes():
    """Gap between posts in a batch, in minutes (default 5, clamped 0-60).

    Read from the file (never the GUI widget) so even a batch started
    before the window opens uses the saved gap.
    """
    try:
        v = json.loads(POST_GAP_FILE.read_text(encoding="utf-8")).get(
            "gap_minutes", 5)
        return max(0, min(60, int(v)))
    except Exception:
        return 5


def save_post_gap_minutes(minutes):
    try:
        POST_GAP_FILE.write_text(
            json.dumps({"gap_minutes": max(0, min(60, int(minutes)))}),
            encoding="utf-8")
    except Exception:
        pass


BROWSER_ACCOUNTS_FILE = DATA / "browser_accounts.json"


def load_browser_accounts():
    """Usernames for the 4-account browser view (max 4, saved pick)."""
    try:
        data = json.loads(BROWSER_ACCOUNTS_FILE.read_text(
            encoding="utf-8"))
        if isinstance(data, list):
            return [str(a) for a in data][:4]
    except Exception:
        pass
    return []


def save_browser_accounts(usernames):
    try:
        BROWSER_ACCOUNTS_FILE.write_text(
            json.dumps([str(u) for u in usernames][:4]),
            encoding="utf-8")
    except Exception:
        pass


ACTIVATED_FILE = DATA / "activated.json"
ACTIVATION_MARKER = BASE / "friend-copy.txt"  # present only in friend packs


def hash_access_password(password):
    """SHA-256 of the access password (never store the password itself)."""
    return hashlib.sha256((password or "").encode("utf-8")).hexdigest()


def make_access_key():
    """A typable key: 3 groups of 4 letters/digits, no confusing chars."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "-".join("".join(secrets.choice(alphabet) for _ in range(4))
                    for _ in range(3))


def make_access_record(username, key, password):
    return {"username": (username or "").strip(),
            "key": (key or "").strip().upper(),
            "password_hash": hash_access_password(password or "")}


def verify_access(username, key, password, record):
    """True only when all three typed values match the issued record."""
    if not isinstance(record, dict):
        return False
    return ((username or "").strip() == record.get("username", "")
            and (key or "").strip().upper() == record.get("key", "")
            and hash_access_password(password or "") == record.get("password_hash", ""))


def needs_activation():
    """A friend copy (marker file present) that has never been unlocked."""
    return ACTIVATION_MARKER.exists() and not ACTIVATED_FILE.exists()

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
VIDEO_EXTS = {".mp4", ".mov"}
MAX_WORKERS = 3

QUEUE = []          # list of job dicts
_REBASED_COUNT = 0  # queue file paths re-pointed at load (folder move)
QUEUE_LOCK = threading.Lock()
WATCHES_FILE = DATA / "watches.json"
WATCHES = []          # daily link reposts
LINK_TASKS = []       # one-off link downloads in progress


# ------------------------------------------------------------- storage

def load_accounts():
    try:
        return json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_accounts(accounts):
    ACCOUNTS_FILE.write_text(json.dumps(accounts, indent=2), encoding="utf-8")
    try:
        sync_registry_positions(accounts)
    except Exception:
        pass


def load_groups():
    """Account groups: [{"name": str, "accounts": [display label, ...]}]."""
    try:
        data = json.loads(GROUPS_FILE.read_text(encoding="utf-8"))
        groups = data.get("groups", []) if isinstance(data, dict) else []
        out = []
        for g in groups:
            if isinstance(g, dict) and g.get("name"):
                g.setdefault("accounts", [])
                out.append(g)
        return out
    except Exception:
        return []


def save_groups(groups):
    GROUPS_FILE.write_text(json.dumps({"groups": groups}, indent=2),
                           encoding="utf-8")


POSTED_LOCK = threading.Lock()


def load_posted():
    """List of {"source": str, "account": str} already posted."""
    try:
        data = json.loads(POSTED_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def was_posted(source, account):
    if not source:
        return False
    with POSTED_LOCK:
        return any(p.get("source") == source and p.get("account") == account
                   for p in load_posted())


def mark_posted(source, account):
    if not source:
        return
    with POSTED_LOCK:
        posted = load_posted()
        if not any(p.get("source") == source and p.get("account") == account
                   for p in posted):
            posted.append({"source": source, "account": account,
                           "at": datetime.now().isoformat(timespec="seconds")})
            POSTED_FILE.write_text(json.dumps(posted, indent=2),
                                   encoding="utf-8")


STORY_POSTS_FILE = DATA / "story_posts.json"


def load_story_posts():
    """{post link: {story_id, account}} for stories this app posted.

    Only stories posted from here on are recorded — a post's Story
    can only be deleted if its story id was captured at upload time
    (old posts have no record; that is expected, not an error).
    history.log itself is never touched by this file.
    """
    try:
        data = json.loads(STORY_POSTS_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_story_posts(data):
    try:
        STORY_POSTS_FILE.write_text(
            json.dumps(data, ensure_ascii=False, indent=1),
            encoding="utf-8")
    except Exception:
        pass


def record_story(post_link, account, story_id):
    """Remember a post's story id. Only called on story success."""
    if not post_link or not story_id:
        return
    data = load_story_posts()
    data[post_link] = {"story_id": str(story_id), "account": account}
    save_story_posts(data)


def drop_story(post_link):
    data = load_story_posts()
    if post_link in data:
        del data[post_link]
        save_story_posts(data)


BULK_HISTORY_FILE = DATA / "bulk_history.json"


def load_bulk_history():
    """Past Pinterest bulk runs: [{"at", "link", "account", "queued",
    "fetched", "skipped"}], newest first."""
    try:
        data = json.loads(BULK_HISTORY_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, list) else []
    except Exception:
        return []


def record_bulk_run(link, account, queued, fetched, skipped,
                    start_pin=1, max_pins=0):
    """Remember a bulk run so the user can see (and re-use) which
    Pinterest link was used for which account. The pin range is kept
    too, so 'Bhar do' refills it as well."""
    try:
        # Locked: two bulk runs finishing together must not read the
        # same history and lose each other's entry.
        with QUEUE_LOCK:
            hist = load_bulk_history()
            hist.insert(0, {"at": datetime.now().isoformat(timespec="seconds"),
                            "link": link, "account": account,
                            "queued": queued, "fetched": fetched,
                            "skipped": skipped, "start_pin": start_pin,
                            "max_pins": max_pins})
            BULK_HISTORY_FILE.write_text(json.dumps(hist[:100], indent=2),
                                         encoding="utf-8")
    except Exception:
        pass


ACCOUNT_LINKS_FILE = DATA / "account_links.json"


def load_account_links():
    """The Pinterest link saved for each Instagram account:
    {account: {"link", "at"}}."""
    try:
        data = json.loads(ACCOUNT_LINKS_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def get_account_link(account):
    """The saved Pinterest link for this account, or ""."""
    e = load_account_links().get(account) or {}
    return e.get("link", "") if isinstance(e, dict) else ""


def board_short_link(account):
    """Short display of the account's saved board link, or "".

    'https://www.pinterest.com/aatoota/حركات/' -> 'aatoota/حركات'.
    A non-Pinterest link is shown as-is (truncated to fit a column).
    """
    link = (get_account_link(account) or "").strip()
    if not link:
        return ""
    for prefix in ("https://www.pinterest.com/", "http://www.pinterest.com/",
                   "https://pinterest.com/", "http://pinterest.com/",
                   "www.pinterest.com/", "pinterest.com/"):
        if link.startswith(prefix):
            link = link[len(prefix):]
            break
    return link.strip("/")[:60]


def get_account_links(account):
    """All saved board links for this account, latest first.

    Legacy entries that only carry a single 'link' return [link].
    """
    e = load_account_links().get(account) or {}
    if not isinstance(e, dict):
        return []
    links = e.get("links")
    if isinstance(links, list) and links:
        seen = []
        for l in links:
            if isinstance(l, str) and l and l not in seen:
                seen.append(l)
        return seen
    link = e.get("link", "")
    return [link] if link else []


def set_account_link(account, link):
    """Save the Pinterest link used for this account (an empty link
    forgets it), so the bulk box can refill it automatically.

    Every saved link is kept, latest first (max 20): one account can
    carry many boards. 'link' stays the latest one for autofill.
    """
    try:
        # Locked: two bulk runs starting at once must not read the
        # same file and overwrite each other's saved link.
        with QUEUE_LOCK:
            links = load_account_links()
            link = (link or "").strip()
            if link:
                entry = links.get(account)
                if not isinstance(entry, dict):
                    entry = {}
                old = entry.get("links")
                if not isinstance(old, list):
                    old = [entry["link"]] if entry.get("link") else []
                entry["links"] = ([link] + [l for l in old
                                            if l != link])[:20]
                entry["link"] = link
                entry["at"] = datetime.now().isoformat(timespec="seconds")
                links[account] = entry
            else:
                links.pop(account, None)
            ACCOUNT_LINKS_FILE.write_text(json.dumps(links, indent=2),
                                          encoding="utf-8")
    except Exception:
        pass


def posted_summary():
    """Per-account view of posted.json: how many pins went to each
    account, when, plus a few sample pin links. Lets the user work
    out which Pinterest board/profile fed which account: open any
    sample pin on Pinterest and its board is shown there."""
    out = {}
    for p in load_posted():
        acct = p.get("account") or "?"
        e = out.setdefault(acct, {"count": 0, "first": "", "last": "",
                                   "samples": []})
        e["count"] += 1
        at = p.get("at") or ""
        if at and (not e["first"] or at < e["first"]):
            e["first"] = at
        if at and at > e["last"]:
            e["last"] = at
        src = p.get("source") or ""
        if src and len(e["samples"]) < 3 and src not in e["samples"]:
            e["samples"].append(src)
    return out


def load_passwords():
    try:
        return json.loads(PASSWORDS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def account_can_post(username):
    """True if the account has a password or a saved session (session-ID login)."""
    if username in load_passwords():
        return True
    return (SESSIONS / f"{username}.json").exists()


def save_passwords(pw):
    PASSWORDS_FILE.write_text(json.dumps(pw), encoding="utf-8")


def save_queue():
    with QUEUE_LOCK:
        QUEUE_FILE.write_text(json.dumps(QUEUE, indent=2), encoding="utf-8")


def load_queue():
    global QUEUE
    try:
        QUEUE = json.loads(QUEUE_FILE.read_text(encoding="utf-8"))
        # keep a last-good backup so a later bad start can never erase
        # the only copy of the user's scheduled posts
        try:
            shutil.copy(QUEUE_FILE, DATA / "queue_last_good.json")
        except Exception:
            pass
    except Exception:
        # never overwrite a queue file we could not read — preserve it
        try:
            if QUEUE_FILE.exists():
                shutil.copy(QUEUE_FILE,
                            DATA / "queue_unreadable_backup.json")
        except Exception:
            pass
        QUEUE = []
        return
    for job in QUEUE:  # never resume half-finished uploads
        if job.get("status") in ("uploading",):
            job["status"] = "waiting"
            job["message"] = ""
    rebase_queue_paths()
    save_queue()


def _rebase_one_path(p):
    """A queued file path that no longer exists -> same filename under
    this copy's uploads folder. Returns (path, changed)."""
    if not p:
        return p, False
    old = Path(p)
    if old.exists():
        return p, False
    cand = UPLOADS / old.name
    if cand.exists():
        return str(cand), True
    return p, False


def rebase_queue_paths():
    """Fix queued jobs whose files moved with the app folder.

    Jobs store absolute paths. If the whole app folder moved (e.g.
    Desktop -> F:), the old paths are dead but the files sit in this
    copy's uploads folder under the same names. Re-point filepath,
    cover and carousel files at load time; leave a job untouched when
    its file is nowhere to be found. Returns how many paths moved.
    """
    global _REBASED_COUNT
    fixed = 0
    for job in QUEUE:
        for key in ("filepath", "cover"):
            new, changed = _rebase_one_path(job.get(key, ""))
            if changed:
                job[key] = new
                fixed += 1
        files = job.get("files")
        if isinstance(files, list):
            new_files = []
            for f in files:
                new, changed = _rebase_one_path(f)
                new_files.append(new)
                if changed:
                    fixed += 1
            if new_files != files:
                job["files"] = new_files
    _REBASED_COUNT = fixed
    return fixed


def load_watches():
    global WATCHES
    try:
        WATCHES = json.loads(WATCHES_FILE.read_text(encoding="utf-8"))
    except Exception:
        WATCHES = []


def save_watches():
    with QUEUE_LOCK:
        WATCHES_FILE.write_text(json.dumps(WATCHES, indent=2), encoding="utf-8")


def log_history(account, filename, caption, link):
    try:
        with open(HISTORY_FILE, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M} | {account} | "
                    f"{filename} | {caption[:60]} | {link}\n")
    except Exception:
        pass


def read_history(limit=10):
    try:
        lines = HISTORY_FILE.read_text(encoding="utf-8").strip().splitlines()
        return lines[-limit:][::-1]
    except Exception:
        return []


def parse_history_entry(line):
    """One history.log line -> dict, or None if it doesn't parse.

    Format: "YYYY-MM-DD HH:MM | account | filename | caption | link".
    The caption itself may contain " | ", so the link is always the
    LAST field and the caption is everything between filename and link.
    via: "meta" when the account carries the 📘 Facebook-route marker
    (the link is then a numeric Instagram media id); otherwise "api"
    (the link is the post's Instagram URL).
    """
    parts = (line or "").strip().split(" | ")
    if len(parts) < 5:
        return None
    date, account, filename = parts[0], parts[1], parts[2]
    link = parts[-1]
    caption = " | ".join(parts[3:-1])
    if not date or not account or not filename or not link:
        return None
    via = "meta" if account.startswith("📘 ") else "api"
    if via == "meta":
        account = account[2:].strip()
    return {"date": date, "account": account, "filename": filename,
            "caption": caption, "link": link, "via": via}


def posted_entries(limit=500):
    """Posted posts from history, newest first, one row per post.

    The same post recorded twice (same link) shows once — deleting it
    once removes the post, so a second row for it could only fail.
    """
    seen, out = set(), []
    for line in read_history(limit):
        e = parse_history_entry(line)
        if not e or e["link"] in seen:
            continue
        seen.add(e["link"])
        out.append(e)
    return out


def delete_history_links(links):
    """Drop history lines whose post link is in `links`. Unparseable
    lines are kept (they may predate this feature)."""
    links = set(links)
    try:
        lines = HISTORY_FILE.read_text(encoding="utf-8").splitlines()
    except Exception:
        return
    kept = []
    for line in lines:
        e = parse_history_entry(line)
        if e is not None and e["link"] in links:
            continue
        kept.append(line)
    HISTORY_FILE.write_text("\n".join(kept) + ("\n" if kept else ""),
                            encoding="utf-8")


# ------------------------------------------------------------- instagram

def login_by_sessionid(username, sessionid):
    """Log in using a browser session ID (bypasses password-login blocks)."""
    from instagrapi import Client
    cl = Client()
    cl.delay_range = [1, 3]
    session_file = SESSIONS / f"{username}.json"
    if session_file.exists():
        try:
            cl.load_settings(session_file, override_app_version=True)
            cl.set_user_agent()
        except Exception:
            pass
    cl.login_by_sessionid(sessionid.strip())
    # verify it actually works
    cl.account_info()
    try:
        cl.dump_settings(session_file)
    except Exception:
        pass
    try:
        mark_login_ok(username)
    except Exception:
        pass
    return cl


def login_client(username, password, verification_code="",
                 challenge_code_handler=None):
    """Log in with a password (or reuse a saved session).

    challenge_code_handler (username, choice) -> code is used when
    Instagram asks for a confirmation code (SMS/email challenge):
    the desktop app asks her for the code in its own window. Without
    a handler, automatic challenge resolution is switched off, so a
    challenge raises ChallengeRequired instead of hanging on
    instagrapi's default stdin prompt inside the desktop app.
    """
    from instagrapi import Client
    cl = Client()
    cl.delay_range = [1, 3]
    if challenge_code_handler is not None:
        cl.challenge_code_handler = challenge_code_handler
    else:
        cl.with_challenge_flow = False
    session_file = SESSIONS / f"{username}.json"
    has_session = session_file.exists()
    if has_session:
        try:
            # override_app_version: old sessions were saved with an older
            # Instagram app version; Instagram rejects those at login.
            cl.load_settings(session_file, override_app_version=True)
            cl.set_user_agent()  # rebuild UA string with the new version
        except Exception:
            has_session = False
    if not password and has_session:
        # session-ID login: no password saved, use the session file as-is
        try:
            mark_login_ok(username)
        except Exception:
            pass
        return cl
    try:
        cl.login(username, password, verification_code=verification_code)
    except TypeError as e:
        # instagrapi's CAA flow can crash with int(None) on unexpected
        # Instagram responses — retry with the legacy login flow
        if "NoneType" in str(e):
            cl2 = Client()
            cl2.delay_range = [1, 3]
            if challenge_code_handler is not None:
                cl2.challenge_code_handler = challenge_code_handler
            else:
                cl2.with_challenge_flow = False
            cl2.login_legacy(username, password,
                             verification_code=verification_code)
            cl = cl2
        else:
            raise
    except Exception as e:
        # friendlier message for the common failure cases
        msg = str(e).lower()
        if "noneType" in str(e) or "bad credentials" in msg or \
                "invalid" in msg and "password" in msg:
            raise RuntimeError(
                "Instagram didn't accept the login. Check that the "
                "password is correct and you can log in to this account "
                "in the Instagram app.") from e
        raise
    try:
        cl.dump_settings(session_file)
    except Exception:
        pass
    try:
        mark_login_ok(username)
    except Exception:
        pass
    return cl


LINK_SOURCES = (
    ("instagram.com", "Instagram"),
    ("tiktok.com", "TikTok"),
    ("youtube.com", "YouTube"),
    ("youtu.be", "YouTube"),
    ("pinterest.com", "Pinterest"),
    ("pin.it", "Pinterest"),
)


def link_source_name(url):
    u = (url or "").lower()
    for dom, name in LINK_SOURCES:
        if dom in u:
            return name
    return None


def download_instagram(url, account):
    """Download the photo/video from an Instagram post/reel link."""
    pw = load_passwords().get(account, "")
    if not pw:
        raise RuntimeError(f"No saved password for @{account}.")
    cl = login_client(account, pw)
    pk = cl.media_pk_from_url(url.strip())
    info = cl.media_info(pk)
    res = info.resources[0] if info.media_type == 8 and info.resources else info
    if res.media_type == 2:
        return str(cl.video_download(res.pk, folder=UPLOADS))
    return str(cl.photo_download(res.pk, folder=UPLOADS))


def _pinterest_page_video_url(pin_url):
    """Scrape a pin's page for its direct mp4 URL (None if it's a photo).

    The pidgets API wrongly reports is_video=False for some video pins,
    so the pin page is the only reliable signal.
    """
    import urllib.request
    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
          "AppleWebKit/537.36 (KHTML, like Gecko) "
          "Chrome/120.0 Safari/537.36")
    req = urllib.request.Request(pin_url.strip(), headers={"User-Agent": UA})
    html = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")
    vids = re.findall(r"https://v1\.pinimg\.com/videos/iht/expMp4/[^\"]+?\.mp4",
                      html)
    return vids[0] if vids else None


def download_pinterest_pin(url):
    """Download a single Pinterest pin (video or photo) straight from its page.

    More reliable than yt-dlp for Pinterest: grabs the direct mp4 URL when
    the pin is a video, otherwise falls back to the photo.
    """
    import urllib.request
    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
          "AppleWebKit/537.36 (KHTML, like Gecko) "
          "Chrome/120.0 Safari/537.36")
    page_url = url.strip()

    # 1. video: direct mp4 (prefer the expMp4 single file over hls streams)
    vurl = _pinterest_page_video_url(page_url)
    if vurl:
        dest = UPLOADS / f"pinvid_{secrets.token_hex(6)}.mp4"
        req = urllib.request.Request(
            vurl, headers={"User-Agent": UA,
                           "Referer": "https://www.pinterest.com/"})
        with urllib.request.urlopen(req, timeout=120) as r, \
                open(dest, "wb") as f:
            shutil.copyfileobj(r, f)
        if dest.stat().st_size >= 1024:
            return str(dest)
        dest.unlink(missing_ok=True)
        raise RuntimeError("The video download was empty.")
    # 2. photo pin
    return download_pinterest_image(page_url)


def download_pinterest_image(url):
    """Direct photo grab for Pinterest image pins (yt-dlp only handles videos)."""
    import urllib.request
    UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
          "AppleWebKit/537.36 (KHTML, like Gecko) "
          "Chrome/120.0 Safari/537.36")
    page_url = url.strip()
    req = urllib.request.Request(page_url, headers={"User-Agent": UA})
    html = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")

    img_url = None
    # 1. the pin's own preload link (attribute order varies)
    m = re.search(r"<link[^>]*pin-image-preload[^>]*>", html)
    if m:
        hm = re.search(r'href="([^"]+)"', m.group(0))
        img_url = hm.group(1) if hm else None
    # 2. og:image meta (Pinterest uses name= or property=)
    if not img_url:
        m = re.search(
            r'<meta[^>]+(?:property|name)="og:image"[^>]+content="([^"]+)"', html)
        if not m:
            m = re.search(
                r'<meta[^>]+content="([^"]+)"[^>]+(?:property|name)="og:image"', html)
        img_url = m.group(1) if m else None
    if not img_url or "pinimg.com" not in img_url:
        raise RuntimeError("Couldn't find the photo in that pin.")

    # try full-quality original first, fall back to the sized version
    candidates = [re.sub(r"i\.pinimg\.com/[^/]+/", "i.pinimg.com/originals/",
                         img_url)]
    if candidates[0] != img_url:
        candidates.append(img_url)

    ext = Path(img_url.split("?")[0]).suffix.lower() or ".jpg"
    if ext not in IMAGE_EXTS:
        ext = ".jpg"
    dest = UPLOADS / f"pin_{secrets.token_hex(6)}{ext}"
    last_err = None
    for cand in candidates:
        try:
            req = urllib.request.Request(
                cand, headers={"User-Agent": UA,
                               "Referer": "https://www.pinterest.com/"})
            with urllib.request.urlopen(req, timeout=60) as r, \
                    open(dest, "wb") as f:
                f.write(r.read())
            if dest.stat().st_size >= 1024:
                return str(dest)
        except Exception as e:
            last_err = e
    dest.unlink(missing_ok=True)
    raise RuntimeError("Couldn't download the photo from that pin.")


def _pinterest_best_video(item):
    """Best direct mp4 URL from a Pinterest API pin item (or None).

    Story/idea pins often expose ONLY an HLS (.m3u8) stream and no direct
    mp4. Prefer mp4, but fall back to the HLS URL so those pins are still
    detected as videos; the downloader converts HLS to mp4 via yt-dlp.
    """
    def from_list(vl):
        mp4, hls = [], []
        for f in (vl or {}).values():
            if not isinstance(f, dict):
                continue
            url = f.get("url")
            if not url:
                continue
            area = (f.get("width") or 0) * (f.get("height") or 0)
            (hls if "m3u8" in url else mp4).append((area, url))
        if mp4:
            return max(mp4)[1]
        return max(hls)[1] if hls else None
    url = from_list((item.get("videos") or {}).get("video_list"))
    if url:
        return url
    # story / idea pins keep media under pages -> blocks
    for page in ((item.get("story_pin_data") or {}).get("pages") or []):
        for block in (page.get("blocks") or []):
            url = from_list((block.get("video") or {}).get("video_list"))
            if url:
                return url
    return None


def _pinterest_best_image(item):
    """Best direct image URL from a Pinterest API pin item (or None)."""
    imgs = item.get("images") or {}
    orig = imgs.get("orig") or {}
    if orig.get("url"):
        return orig["url"]
    best, best_area = None, 0
    for v in imgs.values():
        if isinstance(v, dict) and v.get("url"):
            area = (v.get("width") or 0) * (v.get("height") or 0)
            if area > best_area:
                best, best_area = v["url"], area
    if best:
        return best
    for page in ((item.get("story_pin_data") or {}).get("pages") or []):
        for block in (page.get("blocks") or []):
            img = (block.get("image") or {})
            if img.get("url"):
                return img["url"]
    return None


def _download_hls_to_mp4(url):
    """Convert an HLS (.m3u8) stream URL to a real mp4 file.

    Tries ffmpeg first (handles Pinterest's byte-range HLS well),
    falls back to yt-dlp.
    """
    import subprocess
    dest = UPLOADS / f"pinhls_{secrets.token_hex(6)}.mp4"
    # Try ffmpeg directly — best for HLS
    try:
        import imageio_ffmpeg
        ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        ffmpeg = None
    if ffmpeg:
        try:
            subprocess.run(
                [ffmpeg, "-y",
                 "-user_agent", ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                 "AppleWebKit/537.36 (KHTML, like Gecko) "
                                 "Chrome/120.0 Safari/537.36"),
                 "-headers", "Referer: https://www.pinterest.com/",
                 "-i", url.strip(),
                 "-c", "copy",
                 str(dest)],
                capture_output=True, timeout=300, check=True)
            if dest.exists() and dest.stat().st_size > 1024:
                return str(dest)
        except Exception:
            pass
    # Fallback: yt-dlp
    import contextlib
    import io
    from yt_dlp import YoutubeDL
    ydl_opts = {
        "outtmpl": str(UPLOADS / "pinhls_%(id)s.%(ext)s"),
        "format": "b/best",
        "merge_output_format": "mp4",
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "retries": 5,
        "fragment_retries": 5,
        "socket_timeout": 60,
        "http_headers": {
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/120.0 Safari/537.36"),
            "Referer": "https://www.pinterest.com/",
        },
    }
    try:
        with contextlib.redirect_stderr(io.StringIO()):
            with YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url.strip(), download=True)
                if not info:
                    raise RuntimeError("Could not download that video.")
                path = Path(ydl.prepare_filename(info))
    except Exception as e:
        raise RuntimeError(f"Video download failed: {str(e)[:80]}")
    if not path.exists():  # fallback: newest file in uploads
        cands = sorted((p for p in UPLOADS.iterdir() if p.is_file()),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        path = cands[0] if cands else None
    if not path or not path.exists():
        raise RuntimeError("The video download failed.")
    if path.suffix.lower() != ".mp4":
        mp4 = path.with_suffix(".mp4")
        path.rename(mp4)
        path = mp4
    if path.stat().st_size < 1024:
        path.unlink(missing_ok=True)
        raise RuntimeError("The video download was empty.")
    return str(path)


def download_pinterest_direct(pin):
    """Download one bulk-listed Pinterest pin straight from its media URL."""
    import urllib.request
    url = pin.get("video_url") or pin.get("image_url")
    is_video = bool(pin.get("video_url"))
    # pidgets wrongly marks some video pins as photos; check the pin page
    if not is_video and pin.get("url"):
        try:
            vurl = _pinterest_page_video_url(pin["url"])
            if vurl:
                url, is_video = vurl, True
        except Exception:
            pass
    if not url:
        raise RuntimeError("That pin has no downloadable photo or video.")
    if is_video and url.lower().split("?")[0].endswith(".m3u8"):
        # HLS playlist: try direct mp4 first (fast, reliable), then yt-dlp
        mp4_url = url.replace("/hls/", "/720p/").rsplit(".m3u8", 1)[0] + ".mp4"
        try:
            import urllib.request
            req = urllib.request.Request(
                mp4_url, method="HEAD",
                headers={"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; "
                                        "Win64; x64) AppleWebKit/537.36")})
            with urllib.request.urlopen(req, timeout=15):
                url = mp4_url  # direct mp4 exists — use it
        except Exception:
            # no direct mp4; convert the HLS playlist via yt-dlp
            return _download_hls_to_mp4(url)
    ext = Path(url.split("?")[0]).suffix.lower()
    if is_video:
        if ext not in VIDEO_EXTS:
            ext = ".mp4"
    elif ext not in IMAGE_EXTS:
        ext = ".jpg"
    dest = UPLOADS / f"pinbulk_{secrets.token_hex(6)}{ext}"
    req = urllib.request.Request(url, headers={
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0 Safari/537.36"),
        "Referer": "https://www.pinterest.com/"})
    with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
        shutil.copyfileobj(r, f)
    if dest.stat().st_size < 1024:
        dest.unlink(missing_ok=True)
        raise RuntimeError("Download was empty, skipped.")
    return str(dest)


def download_with_ytdlp(url):
    """Download photo/video from TikTok, YouTube, Pinterest, etc. via yt-dlp."""
    import contextlib
    import io
    from yt_dlp import YoutubeDL
    ydl_opts = {
        "outtmpl": str(UPLOADS / "%(id)s.%(ext)s"),
        "format": "b[ext=mp4]/b",  # best single file, prefer mp4
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "retries": 2,
        "socket_timeout": 30,
    }
    # keep yt-dlp's noisy error chatter off the user's screen
    with contextlib.redirect_stderr(io.StringIO()):
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url.strip(), download=True)
            if not info:
                raise RuntimeError("Could not read that link.")
            path = Path(ydl.prepare_filename(info))
    if not path.exists():  # fallback: newest file in uploads
        cands = sorted((p for p in UPLOADS.iterdir() if p.is_file()),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        path = cands[0] if cands else None
    if not path or not path.exists():
        raise RuntimeError("Download failed — the link may be private or blocked.")
    ext = path.suffix.lower()
    if ext == ".webp":  # Instagram can't post webp; convert to jpg
        jpg = path.with_suffix(".jpg")
        Image.open(path).convert("RGB").save(jpg, "JPEG")
        path.unlink()
        path, ext = jpg, ".jpg"
    if ext not in IMAGE_EXTS and ext not in VIDEO_EXTS:
        raise RuntimeError(f"That link gave a {ext} file, which can't be posted.")
    return str(path)


def download_generic(url):
    """Download photo/video from TikTok, YouTube, Pinterest, etc."""
    u = url.lower()
    if ("pinterest.com" in u or "pin.it" in u):
        if "/pin/" not in u:
            raise RuntimeError(
                "Please paste a single pin link (with /pin/ in it), "
                "not a board or profile link.")
        # direct page scrape first — far more reliable than yt-dlp for pins
        try:
            return download_pinterest_pin(url)
        except Exception:
            pass  # fall through to yt-dlp
    try:
        return download_with_ytdlp(url)
    except Exception as e:
        # Pinterest photo pins have no video formats — grab the photo directly
        if ("no video formats found" in str(e).lower()
                and ("pinterest.com" in u or "pin.it" in u)):
            return download_pinterest_image(url)
        raise


# ------------------------------------------------------------- zip media

ZIP_MEDIA_EXTS = IMAGE_EXTS | VIDEO_EXTS


def extract_zip_media(zip_path, max_total_mb=2048):
    """Extract photos/videos from a zip file into data/zipmedia/<unique>/.

    Returns a sorted list of Path objects (media files only).
    Raises ValueError with a friendly message when the zip has no
    usable photos/videos. Skips anything that is not a photo/video,
    and blocks unsafe paths (zip-slip).
    """
    src = Path(zip_path)
    if not src.is_file():
        raise ValueError("That file was not found.")
    try:
        zf = zipfile.ZipFile(src)
    except zipfile.BadZipFile:
        raise ValueError("That file is not a valid .zip file.")
    dest_dir = ZIPMEDIA / f"{int(time.time())}_{secrets.token_hex(4)}"
    dest_dir.mkdir(parents=True)
    # tidy up abandoned extractions older than 7 days
    try:
        cutoff = time.time() - 7 * 24 * 3600
        for old in ZIPMEDIA.iterdir():
            if old.is_dir() and old.stat().st_mtime < cutoff:
                shutil.rmtree(old, ignore_errors=True)
    except Exception:
        pass
    media = []
    seen_names = []  # every file entry, for a helpful error if no media found
    total = 0
    try:
        with zf:
            for info in zf.infolist():
                if info.is_dir():
                    continue
                p = PurePosixPath(info.filename)
                seen_names.append(info.filename)
                if p.is_absolute() or ".." in p.parts:
                    continue  # zip-slip protection
                if p.suffix.lower() not in ZIP_MEDIA_EXTS:
                    continue
                total += info.file_size
                if total > max_total_mb * 1024 * 1024:
                    raise ValueError("This zip is too large (over 2 GB).")
                target = dest_dir / p.name
                n = 1
                while target.exists():
                    target = dest_dir / f"{p.stem}_{n}{p.suffix}"
                    n += 1
                with zf.open(info) as fin, open(target, "wb") as fout:
                    shutil.copyfileobj(fin, fout)
                media.append(target)
    except RuntimeError as e:
        if "password" in str(e).lower() or "encrypt" in str(e).lower():
            raise ValueError(
                "This zip is password-protected. Please unzip it first.")
        raise
    if not media:
        sample = ", ".join(seen_names[:5]) or "(empty)"
        raise ValueError(
            "No photos or videos found inside this zip.\n"
            f"It has {len(seen_names)} file(s), e.g.: {sample}\n"
            "Supported: JPG, PNG, MP4, MOV.\n"
            "If this should be your video zip, the download may be "
            "incomplete — try downloading it again.")
    return sorted(media, key=lambda p: p.name.lower())


CAPTION_FILE_NAMES = {"captions.txt", "caption.txt"}


def read_zip_captions(zip_path):
    """The text of a captions file (captions.txt) inside a zip,
    or None when the zip has none. Lets a zip carry one caption
    per post next to its videos and covers."""
    try:
        with zipfile.ZipFile(zip_path) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                if Path(info.filename).name.lower() \
                        in CAPTION_FILE_NAMES:
                    raw = z.read(info)
                    for enc in ("utf-8-sig", "utf-8", "cp1252"):
                        try:
                            return raw.decode(enc)
                        except Exception:
                            continue
                    return raw.decode("utf-8", "replace")
    except Exception:
        pass
    return None


def split_captions(text):
    """One caption per line, in order; blank lines are skipped."""
    return [ln.strip() for ln in (text or "").splitlines()
            if ln.strip()]


DAY_RE = re.compile(r"day[\s_\-]*0*(\d+)", re.IGNORECASE)
_DAY_HEAD_RE = re.compile(r"^\s*Day\s*0*(\d+)\s*[:|\-–—]",
                          re.IGNORECASE)


def day_number(name):
    """Day number in a file name or heading ("Day 01 FIXED.mp4" -> 1,
    "day_3_cover.jpg" -> 3), or None when there is none."""
    m = DAY_RE.search(name or "")
    return int(m.group(1)) if m else None


def split_captions_by_day(text):
    """Split caption text into [(day|None, full_caption)].

    A line starting with a Day heading ("Day 1:", "Day 01 |", ...)
    starts a new caption, so a caption spanning several lines
    (text, blank lines, hashtags, emojis) stays whole — nothing
    inside it is dropped or reordered. When no Day heading exists
    at all, falls back to one caption per non-blank line.
    """
    chunks = []
    cur_day, cur = None, []

    def flush():
        nonlocal cur
        t = "\n".join(cur).strip()
        if t:
            chunks.append((cur_day, t))
        cur = []

    for ln in (text or "").splitlines():
        m = _DAY_HEAD_RE.match(ln)
        if m:
            flush()
            cur_day = int(m.group(1))
            rest = ln[m.end():].strip()
            cur = [rest] if rest else []
        else:
            cur.append(ln)
    flush()
    if chunks and any(d is not None for d, _ in chunks):
        return chunks
    return [(None, ln.strip()) for ln in (text or "").splitlines()
            if ln.strip()]


def _read_zip_text(z, info):
    raw = z.read(info)
    for enc in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", "replace")


def read_zip_captions_all(zip_path):
    """Every caption in a zip, as [(day|None, full_caption)].

    Prefers a captions.txt/caption.txt (split by Day headings);
    otherwise reads every .txt file — a file's whole text is one
    caption, its day taken from the file name or its own headings.
    Returns [] when the zip has no caption text at all.
    """
    try:
        with zipfile.ZipFile(zip_path) as z:
            infos = [i for i in z.infolist() if not i.is_dir()]
            for info in infos:
                if PurePosixPath(info.filename).name.lower() \
                        in CAPTION_FILE_NAMES:
                    return split_captions_by_day(_read_zip_text(z, info))
            out = []
            for info in sorted(infos, key=lambda i: i.filename.lower()):
                if PurePosixPath(info.filename).suffix.lower() != ".txt":
                    continue
                text = _read_zip_text(z, info)
                chunks = split_captions_by_day(text)
                d = day_number(PurePosixPath(info.filename).name)
                if d is not None and chunks \
                        and all(c[0] is None for c in chunks):
                    t = text.strip()
                    if t:
                        out.append((d, t))
                else:
                    out.extend(chunks)
            return out
    except Exception:
        return []
    return []


def extract_zip_images(zip_path):
    """All images in a zip, extracted (zip-slip safe) into
    data/zipmedia/<unique>/, sorted by name. Returns [Path, ...],
    or [] when the zip has no image."""
    src = Path(zip_path)
    if not src.is_file():
        raise ValueError("That file was not found.")
    try:
        zf = zipfile.ZipFile(src)
    except zipfile.BadZipFile:
        raise ValueError("That file is not a valid .zip file.")
    dest_dir = ZIPMEDIA / f"covers_{int(time.time())}_{secrets.token_hex(4)}"
    dest_dir.mkdir(parents=True)
    imgs = []
    with zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            p = PurePosixPath(info.filename)
            if p.is_absolute() or ".." in p.parts:
                continue  # zip-slip protection
            if p.suffix.lower() not in IMAGE_EXTS:
                continue
            target = dest_dir / p.name
            n = 1
            while target.exists():
                target = dest_dir / f"{p.stem}_{n}{p.suffix}"
                n += 1
            with zf.open(info) as fin, open(target, "wb") as fout:
                shutil.copyfileobj(fin, fout)
            imgs.append(target)
    return sorted(imgs, key=lambda p: p.name.lower())


def first_image_in_zip(zip_path):
    """The first image (sorted by name) inside a zip, extracted
    into uploads and returned as a path — so a cover can come
    from a zip file too. Returns None when the zip has no image."""
    try:
        with zipfile.ZipFile(zip_path) as z:
            imgs = []
            for info in z.infolist():
                if info.is_dir():
                    continue
                p = PurePosixPath(info.filename)
                if p.is_absolute() or ".." in p.parts:
                    continue  # zip-slip protection
                if p.suffix.lower() in IMAGE_EXTS:
                    imgs.append(info)
            if not imgs:
                return None
            info = sorted(imgs, key=lambda i: i.filename.lower())[0]
            target = UPLOADS / (
                f"zipcover_{int(time.time())}_"
                f"{PurePosixPath(info.filename).name}")
            with z.open(info) as fin, open(target, "wb") as fout:
                shutil.copyfileobj(fin, fout)
            return str(target)
    except Exception:
        return None


def recoverable_uploads(account=None):
    """Media in uploads/ that was downloaded or copied for a post.

    Job media reaches uploads/ under several names: queue copies
    '<epoch>_<original name>' (single/zip posts), 'pinbulk_<hex>'
    (Pinterest bulk), 'pin_'/'pinvid_<hex>' (single pins) and plain
    download names (link posts). '_ig' re-encodes and their '.jpg'
    thumbnails are working files, not posts. Returns
    (display_name, path, queued_datetime, posted_note, posted_here,
    ever_posted) newest first, one entry per media (an epoch copy and
    its original count once). posted_note is the account the file was
    last posted to ("" if never); posted_here is True when it already
    went to `account` — the dialog leaves those unticked but still
    listed, because the same video is often re-queued for another
    account or a later date. Media already waiting in the current
    queue is skipped so nothing is recovered twice.
    """
    def _san(name):
        return re.sub(r"[^a-zA-Z0-9_.-]", "_", name or "")

    def _key(name):
        # identity of a media across its copies: drop the queue-copy
        # epoch prefix, then sanitize like the history compare does
        m = re.match(r"^\d{9,}_(.+)$", name or "")
        return _san(m.group(1) if m else name)

    posted = {}  # media key -> {"accounts": set, "latest": str}
    try:
        for line in HISTORY_FILE.read_text(encoding="utf-8").splitlines():
            parts = line.split(" | ")
            if len(parts) > 2:
                entry = posted.setdefault(
                    _key(parts[2].strip()),
                    {"accounts": set(), "latest": ""})
                acct = parts[1].strip().replace("📘 ", "")
                entry["accounts"].add(acct)
                entry["latest"] = acct
    except Exception:
        pass
    queued_keys = set()
    with QUEUE_LOCK:
        for j in QUEUE:
            if j.get("status") in ("waiting", "uploading"):
                queued_keys.add(_key(j.get("filename", "")))
                queued_keys.add(_key(Path(
                    j.get("filepath", "")).name))
    found = {}  # media key -> result tuple
    try:
        entries = list(UPLOADS.iterdir())
    except Exception:
        return []
    for p in entries:
        try:
            if not p.is_file():
                continue
        except Exception:
            continue
        name = p.name
        if name.endswith("_ig.mp4") or name.endswith("_ig.mp4.jpg"):
            continue  # working copies made during an upload
        if p.suffix.lower() not in IMAGE_EXTS | VIDEO_EXTS:
            continue
        key = _key(name)
        if key in queued_keys:
            continue
        m = re.match(r"^(\d{9,})_", name)
        try:
            when = (datetime.fromtimestamp(int(m.group(1))) if m
                    else datetime.fromtimestamp(p.stat().st_mtime))
        except Exception:
            when = None
        note, posted_here = "", False
        if key in posted:
            note = posted[key]["latest"]
            posted_here = bool(account) and \
                account in posted[key]["accounts"]
        prev = found.get(key)
        if prev is not None:
            # an epoch copy and its original are the same media —
            # keep the copy (it is the one that was queued last)
            prev_is_copy = bool(re.match(r"^\d{9,}_", prev[1].name))
            if bool(m) == prev_is_copy or not m:
                continue
        found[key] = (_key(name) if m else name, p, when, note,
                      posted_here, key in posted)
    out = sorted(found.values(),
                 key=lambda t: t[2] or datetime.min, reverse=True)
    # Re-running a bulk import downloads the same pin again under a
    # fresh hex name, so uploads/ fills with identical copies. For
    # pin-download files, identical size + type means the same media:
    # keep only the newest copy of each.
    deduped, seen_sizes = [], set()
    for t in out:
        nm = t[1].name
        if nm.startswith(("pinbulk_", "pin_", "pinvid_")):
            try:
                sk = (t[1].stat().st_size, t[1].suffix.lower())
            except Exception:
                sk = None
            if sk is not None:
                if sk in seen_sizes:
                    continue
                seen_sizes.add(sk)
        deduped.append(t)
    return deduped[:800]


def pinterest_api(resource, options, retries=4):
    """Call Pinterest's public JSON API (no login needed)."""
    import urllib.request
    import urllib.parse
    import urllib.error
    data = urllib.parse.urlencode({"data": json.dumps({"options": options})})
    url = f"https://www.pinterest.com/resource/{resource}Resource/get/?{data}"
    req = urllib.request.Request(url, headers={
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0 Safari/537.36"),
        "X-Pinterest-PWS-Handler": "www/[username].js",
        "X-Requested-With": "XMLHttpRequest"})
    import http.client
    last = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read())["resource_response"]
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 429 and attempt < retries - 1:
                time.sleep(5 * (attempt + 1))  # back off on rate limits
                continue
            if e.code == 429:
                raise RuntimeError(
                    "Pinterest is rate-limiting right now. "
                    "Wait a few minutes and try again.")
            raise
        except (urllib.error.URLError, http.client.HTTPException,
                TimeoutError, ConnectionError) as e:
            last = e
            if attempt < retries - 1:
                time.sleep(5 * (attempt + 1))
                continue
            raise RuntimeError(
                "Pinterest didn't answer. Check your internet and try again.")
    raise RuntimeError(
        "Pinterest is rate-limiting right now. "
        "Wait a few minutes and try again.")


def list_pinterest_pidgets_pins(username):
    """Pins via Pinterest's public pidgets API (v3).

    Returns the same dict shape as list_pinterest_pins. This finds far
    more pins than the Boards/BoardFeed API (e.g. 25 vs 3 for one profile).
    Note: pidgets carries no video streams and smaller images; the HTML
    supplement fills video URLs in for pins it also finds.
    """
    import urllib.request
    url = f"https://api.pinterest.com/v3/pidgets/users/{username}/pins/"
    req = urllib.request.Request(url, headers={
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0 Safari/537.36")})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read()).get("data") or {}
    except Exception:
        return []
    pins = []
    for p in data.get("pins") or []:
        pid = str(p.get("id") or "")
        if not pid:
            continue
        imgs = p.get("images") or {}
        best, best_area = None, 0
        for v in imgs.values():
            if isinstance(v, dict) and v.get("url"):
                area = (v.get("width") or 0) * (v.get("height") or 0)
                if area > best_area:
                    best, best_area = v["url"], area
        if not best:
            continue
        pins.append({
            "id": pid,
            "url": f"https://www.pinterest.com/pin/{pid}/",
            "is_video": bool(p.get("is_video")),
            "title": p.get("title") or p.get("description") or "",
            "description": p.get("description") or "",
            "video_url": None,  # pidgets has no streams; HTML fills in
            "image_url": best,
        })
    return pins


def list_pinterest_html_pins(page_url):
    """Pins embedded as JSON in a Pinterest profile/board page's HTML.

    The Boards/BoardFeed API misses some pins (e.g. 'Created' pins); the
    page itself embeds them, with direct image/video URLs.
    Returns the same dict shape as list_pinterest_pins.
    """
    import urllib.request
    req = urllib.request.Request(page_url, headers={
        "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                       "AppleWebKit/537.36 (KHTML, like Gecko) "
                       "Chrome/120.0 Safari/537.36")})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            html = r.read().decode("utf-8", "replace")
    except Exception:
        return []
    pins = []
    # embedded pin objects look like: "PID":{"node_id":"UGluOj...","type":"pin",...}
    # (UGluOj is base64 for "Pin:")
    for m in re.finditer(r'"(\d{15,})":\{"node_id":"UGluOj', html):
        pid = m.group(1)
        start = html.find("{", m.start())
        if start < 0:
            continue
        depth, obj = 0, None
        for j in range(start, min(start + 30000, len(html))):
            ch = html[j]
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        obj = json.loads(html[start:j + 1])
                    except Exception:
                        obj = None
                    break
        if not isinstance(obj, dict) or obj.get("type") != "pin":
            continue
        video_url = _pinterest_best_video(obj)
        image_url = _pinterest_best_image(obj)
        if not video_url and not image_url:
            continue
        pins.append({
            "id": pid,
            "url": f"https://www.pinterest.com/pin/{pid}/",
            "is_video": bool(video_url),
            "title": "",
            "description": "",
            "video_url": video_url,
            "image_url": image_url,
        })
    return pins


def list_pinterest_pins(url):
    """List pins from a Pinterest profile or board URL.

    Returns a list of dicts: id, url, is_video, title.
    """
    u = url.strip().rstrip("/")
    m = re.match(
        r"https?://(?:www\.)?pinterest\.[a-z.]+/([^/?#]+)(?:/([^/?#]+))?",
        u, re.I)
    if not m:
        raise RuntimeError(
            "Paste a Pinterest profile link (pinterest.com/username) "
            "or a board link (pinterest.com/username/board-name).")
    # A board link copied from a browser carries a non-English board
    # name percent-encoded ("حركات" arrives as %D8%AD...). Decode it
    # ONCE here: pinterest_api urlencodes the options again, so
    # passing the encoded form double-encodes it and Pinterest looks
    # for a board literally named "%D8%AD..." — which never exists.
    # That is why Urdu/emoji board links never fetched. A link pasted
    # already decoded is unaffected (unquote is a no-op on it).
    from urllib.parse import unquote
    username = unquote(m.group(1))
    board_slug = unquote(m.group(2) or "")
    slug = board_slug.lower()
    if slug in ("", "pins", "_created", "_saved"):
        # profile URL (the _created/_saved suffix just picks the profile tab)
        try:
            boards = pinterest_api(
                "Boards", {"username": username, "page_size": 50})["data"] or []
        except Exception:
            boards = []
        board_ids = [b["id"] for b in boards if b.get("id")]
        # no boards is fine — the page HTML below may still embed pins
    else:
        try:
            board = pinterest_api(
                "Board", {"slug": board_slug, "username": username})["data"]
            board_ids = [board["id"]]
        except Exception:
            raise RuntimeError(
                "Couldn't read that board. Check the link, or use the "
                "profile link instead.")
    pins = []
    for n, bid in enumerate(board_ids):
        if n:
            time.sleep(1.5)  # be gentle with Pinterest's API
        # Robust pagination: Pinterest's BoardFeed often returns partial
        # or empty pages; retry each page until we get pins or give up.
        # For page 1, take the best of 3 attempts (API varies wildly).
        bookmark = None
        seen_page_ids = set()
        try:
            first_page = True
            while True:
                best_pins = []
                best_bookmark = None
                attempts = 3 if first_page else 6
                for attempt in range(attempts):
                    try:
                        opts = {"board_id": bid, "page_size": 100}
                        if bookmark:
                            opts["bookmarks"] = [bookmark]
                        resp = pinterest_api("BoardFeed", opts)
                        bm = resp.get("bookmark")
                        cur = [item for item in resp.get("data") or []
                               if isinstance(item, dict)
                               and item.get("type") == "pin"]
                        # keep the fullest page we've seen
                        if len(cur) > len(best_pins):
                            best_pins = cur
                            best_bookmark = bm
                        # good page? stop early (but not on page 1 —
                        # try all 3 to find the fullest)
                        if not first_page and cur:
                            break
                    except Exception:
                        pass
                    time.sleep(1.5)
                first_page = False
                page_pins = best_pins
                page_bookmark = best_bookmark
                new_on_page = 0
                for item in page_pins:
                    apd = item.get("aggregated_pin_data") or {}
                    # the API's own id is encoded; the numeric public pin id
                    # lives in aggregated_pin_data
                    pid = str(apd.get("id") or "")
                    if not pid.isdigit() or pid in seen_page_ids:
                        continue
                    seen_page_ids.add(pid)
                    new_on_page += 1
                    video_url = _pinterest_best_video(item)
                    image_url = _pinterest_best_image(item)
                    if not video_url and not image_url:
                        continue
                    pins.append({
                        "id": pid,
                        "url": f"https://www.pinterest.com/pin/{pid}/",
                        "is_video": bool(video_url),
                        "title": item.get("grid_title") or item.get("title") or "",
                        "description": item.get("description") or "",
                        "video_url": video_url,
                        "image_url": image_url,
                    })
                # follow pagination; stop if no bookmark or no new pins
                # (Pinterest sometimes loops the bookmark)
                bm = page_bookmark
                bookmark = bm[0] if isinstance(bm, list) and bm else bm
                if not bookmark or not new_on_page:
                    break
        except Exception:
            # one bad board (deleted/private) must not kill the whole fetch
            continue
    # supplement: the main profile page HTML embeds pins the API misses
    # (the _created/_saved tab pages are JS shells with no pin data,
    # so always read the main profile page). Only for profile URLs —
    # a board link must return just that board's pins.
    if not slug or slug in ("pins", "_created", "_saved"):
        try:
            pins.extend(list_pinterest_html_pins(
                f"https://www.pinterest.com/{username}/"))
        except Exception:
            pass
        # pidgets finds far more profile pins than Boards/BoardFeed;
        # added last so richer BoardFeed/HTML entries win the dedup
        try:
            pins.extend(list_pinterest_pidgets_pins(username))
        except Exception:
            pass
    seen, out = set(), []
    for p in pins:
        if p["id"] not in seen:
            seen.add(p["id"])
            out.append(p)
    if not out:
        raise RuntimeError("No pins found on that Pinterest link.")
    return out


def bulk_pinterest_queue(url, account, caption, mode, start_at=None,
                         every_hours=2, kind="both", progress_cb=None,
                         via="api", meta_ig_id="", max_pins=0,
                         cancel_check=None, use_pin_caption=True,
                         start_pin=1):
    """Download every pin from a Pinterest profile/board and queue them.

    mode: "now" (post immediately) or "schedule" (spaced every_hours apart).
    start_pin: first pin number to take (1-based; pin #1 is the first pin
    fetched from the board, within the chosen kind filter).
    max_pins: how many pins to take from there (0 = all the rest).
    cancel_check: optional callable returning True to stop mid-download.
    use_pin_caption: copy each pin's own caption/description to Instagram.
    progress_cb(done, total, message) is called along the way.
    Pins already posted to this account are skipped (never posted twice).
    Returns (queued, fetched, skipped_already_posted).
    """
    pins = list_pinterest_pins(url)
    if kind == "videos":
        pins = [p for p in pins if p["is_video"]]
    elif kind == "photos":
        pins = [p for p in pins if not p["is_video"]]
    if start_pin and start_pin > 1:
        if start_pin > len(pins):
            raise RuntimeError(
                f"Start pin {start_pin} is past the end — this board has "
                f"only {len(pins)} pins with this filter.")
        pins = pins[start_pin - 1:]
    if max_pins and max_pins > 0:
        pins = pins[:max_pins]
    if not pins:
        raise RuntimeError("No pins found with that filter.")
    fresh, skipped = [], 0
    for p in pins:
        if was_posted(p["url"], account):
            skipped += 1
        else:
            fresh.append(p)
    pins = fresh
    if not pins:
        record_bulk_run(url, account, 0, skipped, skipped,
                        start_pin, max_pins)
        raise RuntimeError(
            f"All {skipped} pins were already posted to this account — "
            "nothing new to queue.")
    total = len(pins)
    if progress_cb:
        progress_cb(0, total, f"Found {total} pins — downloading…")
    # Download in parallel (4 at a time) — much faster for videos.
    # Results are queued in original order so scheduling stays correct.
    from concurrent.futures import ThreadPoolExecutor, as_completed
    results = {}  # index -> (local_path or None, error or None)
    done_count = [0]

    def _dl(idx_pin):
        idx, pin = idx_pin
        if cancel_check and cancel_check():
            return idx, None, "cancelled"
        try:
            local = download_pinterest_direct(pin)
            return idx, local, None
        except Exception as e:
            return idx, None, str(e)[:80]

    with ThreadPoolExecutor(max_workers=4) as ex:
        futures = {ex.submit(_dl, (i, pin)): i for i, pin in enumerate(pins)}
        for fut in as_completed(futures):
            idx, local, err = fut.result()
            results[idx] = (local, err)
            done_count[0] += 1
            if progress_cb:
                progress_cb(done_count[0], total,
                            f"Downloaded {done_count[0]}/{total}…")
            if cancel_check and cancel_check():
                # cancel remaining
                for f in futures:
                    f.cancel()
                break
    queued = 0
    for i, pin in enumerate(pins):
        if i not in results:
            continue
        local, err = results[i]
        if err == "cancelled":
            break
        if not local:
            if progress_cb:
                progress_cb(i + 1, total, f"Skipped 1 ({err or 'download failed'})")
            continue
        cap = ((caption.strip() + "\n") if caption and caption.strip() else "")
        if use_pin_caption:
            pin_cap = (pin.get("description") or pin.get("title") or "").strip()
            # decode HTML entities Pinterest uses (&amp; etc.)
            import html as _html
            pin_cap = _html.unescape(pin_cap)
            if pin_cap:
                cap += pin_cap
        elif pin["title"]:
            cap += pin["title"]
        when = "now"
        sched = ""
        if mode == "schedule" and start_at:
            sched = (start_at + timedelta(hours=i * every_hours)).strftime(
                "%Y-%m-%dT%H:%M")
        with QUEUE_LOCK:
            QUEUE.append({
                "id": secrets.token_hex(8),
                "account": account,
                "filename": Path(local).name,
                "filepath": local,
                "caption": cap.strip(),
                "scheduled_at": sched,
                "status": "waiting",
                "message": "",
                "code": "",
                "created": datetime.now().isoformat(timespec="seconds"),
                "via": via,
                "meta_ig_id": meta_ig_id,
                "source": pin["url"],  # Pinterest pin -> skip if posted again
                "kind": "bulk",
            })
        queued += 1
        if progress_cb:
            progress_cb(i + 1, total, f"Queued {queued}/{total}…")
    save_queue()
    record_bulk_run(url, account, queued, total + skipped, skipped,
                    start_pin, max_pins)
    if mode == "now" and queued:
        start_batch_thread(only_due=False)
    return queued, total, skipped


def download_from_link(url, account):
    """Download the photo/video from a supported post link."""
    if not link_source_name(url):
        raise RuntimeError(
            "That link isn't supported. Use Instagram, TikTok, YouTube or Pinterest.")
    if "instagram.com" in url.lower():
        return download_instagram(url, account)
    return download_generic(url)


def process_link(task):
    """Background worker: download a link, then queue/post it."""
    try:
        task["status"] = "downloading"
        task["message"] = "Downloading from the link…"
        path = download_from_link(task["link"], task["account"])
        job = {"id": secrets.token_hex(6), "account": task["account"],
               "filename": Path(path).name, "filepath": path,
               "caption": task["caption"], "status": "waiting",
               "message": "", "link": "", "code": "",
               "scheduled_at": task.get("scheduled_at", ""),
               "via": task.get("via", "api"),
               "meta_ig_id": task.get("meta_ig_id", ""),
               "source": task.get("link", ""),
               "kind": "link"}
        with QUEUE_LOCK:
            QUEUE.append(job)
        save_queue()
        if task["mode"] == "now":
            task["status"] = "posting"
            task["message"] = "Downloaded — posting now…"
            run_job(job)
            task["status"] = "done" if job["status"] == "done" else job["status"]
            task["message"] = "Posted!" if job["status"] == "done" else job["message"]
        else:
            task["status"] = "done"
            task["message"] = "Downloaded — scheduled."
    except Exception as e:
        task["status"] = "failed"
        task["message"] = str(e)[:160]


def check_watches():
    """Daily link reposts: download + post each watch once per day at its time."""
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    with QUEUE_LOCK:
        watches = list(WATCHES)
    for w in watches:
        if w.get("last_run") == today:
            continue
        try:
            t = datetime.strptime(w.get("daily_time", "10:00"), "%H:%M").time()
        except ValueError:
            continue
        if t > now.time():
            continue
        w["status"] = "working"
        w["message"] = "Downloading…"
        save_watches()
        try:
            path = download_from_link(w["link"], w["account"])
            job = {"id": secrets.token_hex(6), "account": w["account"],
                   "filename": Path(path).name, "filepath": path,
                   "caption": w.get("caption", ""), "status": "waiting",
                   "message": "", "link": "", "code": "", "scheduled_at": "",
                   "via": w.get("via", "api"),
                   "meta_ig_id": w.get("meta_ig_id", ""),
                   "source": w.get("link", "")}
            with QUEUE_LOCK:
                QUEUE.append(job)
            save_queue()
            run_job(job)
            w["last_run"] = today
            w["status"] = "active"
            w["message"] = (f"Posted today at {now:%H:%M}."
                            if job["status"] == "done"
                            else "Posted with issues — see queue.")
        except Exception as e:
            w["status"] = "error"
            w["message"] = str(e)[:160]
        save_watches()
def upload_media(username, password, filepath, caption, verification_code="",
                 cover=""):
    """Post one photo/video. Returns (link, cover_applied): for a
    video, `cover` (an image path) is used as its cover/thumbnail
    when given; cover_applied says whether it actually went up."""
    cl = login_client(username, password, verification_code)
    ext = Path(filepath).suffix.lower()
    if ext in IMAGE_EXTS:
        media = cl.photo_upload(Path(filepath), caption)
        return f"https://www.instagram.com/p/{media.code}/", False
    elif ext in VIDEO_EXTS:
        # Ensure the video is Instagram-compatible (H.264 + AAC).
        # Pinterest/yt-dlp videos sometimes have odd codecs that
        # Instagram rejects with "something went wrong during upload".
        fixed = _fix_video_for_instagram(filepath)
        thumb = Path(cover) if cover and Path(cover).is_file() else None
        media = None
        if thumb is not None:
            try:
                media = cl.clip_upload(Path(fixed), caption,
                                       thumbnail=thumb)
            except Exception:
                media = None  # cover may be the problem — retry clean
        if media is None:
            try:
                media = cl.clip_upload(Path(fixed), caption)
                thumb = None
            except Exception:
                # Reel upload failed — try as a regular video post
                if thumb is not None:
                    try:
                        media = cl.video_upload(Path(fixed), caption,
                                                thumbnail=thumb)
                    except Exception:
                        media = cl.video_upload(Path(fixed), caption)
                        thumb = None
                else:
                    media = cl.video_upload(Path(fixed), caption)
        return (f"https://www.instagram.com/reel/{media.code}/",
                thumb is not None)
    raise RuntimeError("Unsupported file type. Use JPG/PNG photos or MP4 videos.")


def upload_carousel(username, password, filepaths, caption,
                    verification_code=""):
    """Post a photo carousel (2–20 photos). Returns the post link.

    Photos only — a video can never join a carousel, so callers must
    refuse videos before queueing, not here at upload time. The
    returned Media's code gives an instagram.com/p/{code}/ link, so
    the delete manager deletes a carousel like any normal post.
    """
    cl = login_client(username, password, verification_code)
    paths = [Path(p) for p in filepaths]
    if len(paths) < 2:
        raise RuntimeError(
            "Carousel ke liye kam se kam 2 photos chahiye.")
    if len(paths) > 20:
        raise RuntimeError(
            "Instagram carousel mein zyada se zyada 20 photos hoti hain.")
    bad = [p for p in paths if p.suffix.lower() not in IMAGE_EXTS]
    if bad:
        raise RuntimeError(
            "Carousel mein sirf photos hoti hain — video nahi: "
            + ", ".join(p.name for p in bad[:3]))
    media = cl.album_upload(paths, caption)
    return f"https://www.instagram.com/p/{media.code}/"


def upload_to_story(username, password, filepath, verification_code=""):
    """Upload the same media to the account's Story (24 hours).

    Returns the story's pk (str) on success, so the caller can record
    it for a later story delete. Raises on failure, as before.
    """
    cl = login_client(username, password, verification_code)
    ext = Path(filepath).suffix.lower()
    if ext in IMAGE_EXTS:
        story = cl.photo_upload_to_story(Path(filepath))
    elif ext in VIDEO_EXTS:
        fixed = _fix_video_for_instagram(filepath)
        story = cl.video_upload_to_story(Path(fixed))
    else:
        raise RuntimeError("Unsupported file type for a story.")
    pk = getattr(story, "pk", None)
    return str(pk) if pk else None


def _fix_video_for_instagram(filepath):
    """Re-encode a video to H.264/AAC if needed. Returns the path to use."""
    import subprocess
    try:
        import imageio_ffmpeg
        ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return filepath  # no ffmpeg — try the original
    out = str(Path(filepath).with_name(Path(filepath).stem + "_ig.mp4"))
    # Only re-encode if not already done
    if Path(out).exists() and Path(out).stat().st_size > 1024:
        return out
    try:
        subprocess.run(
            [ffmpeg, "-y", "-i", str(filepath),
             "-c:v", "libx264", "-preset", "fast", "-crf", "23",
             "-c:a", "aac", "-b:a", "128k",
             "-movflags", "+faststart",
             "-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2",
             out],
            capture_output=True, timeout=300, check=True)
        if Path(out).stat().st_size > 1024:
            return out
    except Exception:
        pass
    return filepath


def _post_old_route(job):
    """Post one job via the unofficial route (instagrapi). Sets the
    job's status/message. (Extracted from run_job so a failed Meta
    upload can fall back to it — see meta_run_job.)"""
    from instagrapi.exceptions import TwoFactorRequired, ChallengeRequired
    job["status"] = "uploading"
    job["message"] = "Uploading…"
    save_queue()
    try:
        if job.get("files"):
            # Carousel job: one post made of many photos, no cover.
            link = upload_carousel(
                job["account"], load_passwords().get(job["account"], ""),
                job["files"], job["caption"], job.get("code", ""))
            job["status"] = "done"
            job["link"] = link
            job["message"] = "Posted! 🎠"
        else:
            link, cover_used = upload_media(
                job["account"], load_passwords().get(job["account"], ""),
                job["filepath"], job["caption"], job.get("code", ""),
                cover=job.get("cover", ""))
            job["status"] = "done"
            job["link"] = link
            job["message"] = "Posted!"
            if cover_used:
                job["message"] = "Posted! + Cover 🖼"
        if job.get("to_story"):
            # post is already up — a story failure must not fail the job
            # A carousel's story uses its first photo.
            story_path = (job.get("files") or [job["filepath"]])[0]
            base_msg = job["message"]
            try:
                sid = upload_to_story(
                    job["account"],
                    load_passwords().get(job["account"], ""),
                    story_path, job.get("code", ""))
                if sid:
                    record_story(link, job["account"], sid)
                job["message"] = base_msg + " + Story ✅"
            except Exception as se:
                job["message"] = (f"{base_msg} "
                                   f"(Story failed: {str(se)[:80]})")
        mark_posted(job.get("source"), job["account"])
        log_history(job["account"], job["filename"], job["caption"], link)
    except TwoFactorRequired:
        job["status"] = "needs_code"
        job["message"] = "Instagram sent a login code."
        mark_login_failed(job["account"], job["message"])
    except ChallengeRequired:
        job["status"] = "needs_approval"
        job["message"] = "Approve the login in the Instagram app."
        mark_login_failed(job["account"], job["message"])
    except Exception as e:
        job["status"] = "failed"
        job["message"] = str(e)[:200]
        if looks_like_login_failure(job["message"]):
            mark_login_failed(job["account"], job["message"])
    save_queue()


def run_job(job):
    if job.get("via") == "meta":
        meta_run_job(job)
        return
    _post_old_route(job)


# Only one batch may run at a time: the scheduler tick and the
# Post-now button must never post two batches concurrently.
_BATCH_LOCK = threading.Lock()

# Automatic posting starts PAUSED: the app used to start posting by
# itself within 30 seconds of opening, before she had a chance to
# fix accounts or choose which accounts go first. The desktop app
# asks at startup ("Aaj ki posting start karun?") and the toggle
# button starts/stops it later. Manual posting (Post now / Abhi
# post / Start posting / Retry / Accounts batch) is never gated by
# this flag — only the automatic scheduler tick is.
_SCHEDULER_PAUSED = True
_SCHEDULER_LOCK = threading.Lock()


def scheduler_paused():
    """Is automatic posting paused (waiting for her Yes)?"""
    with _SCHEDULER_LOCK:
        return _SCHEDULER_PAUSED


def set_scheduler_paused(paused):
    """Pause or resume automatic posting."""
    global _SCHEDULER_PAUSED
    with _SCHEDULER_LOCK:
        _SCHEDULER_PAUSED = bool(paused)


def run_batch(only_due=False):
    """Run due jobs ONE BY ONE with a gap between them.

    Due jobs used to run concurrently (up to 3 at once), so accounts
    sharing a post time fired as a burst from one connection — the
    pattern Instagram flags, and the reason posting windows at 10:30
    and 20:30 were dangerous. Now each batch is sequential with a
    configurable gap, and a second caller while a batch runs simply
    returns, leaving its jobs waiting for the next tick (never lost,
    never doubled).
    """
    jobs = due_jobs(only_due)
    if not jobs:
        return
    if not _BATCH_LOCK.acquire(blocking=False):
        return
    try:
        gap = load_post_gap_minutes() * 60
        for i, job in enumerate(jobs):
            if i > 0 and gap > 0:
                time.sleep(gap)
            try:
                run_job(job)
            except Exception:
                # run_job marks its own failures; this guard only keeps
                # one unexpected raise from stopping the rest.
                pass
    finally:
        _BATCH_LOCK.release()


def run_job_list(job_ids):
    """Post a given list of jobs NOW, one by one with the posting gap.

    Used by the queue's "Abhi post karo" button: the filtered
    account's waiting jobs, in queue order, posted immediately
    instead of waiting for their scheduled time. Same safety as
    run_batch: one batch at a time (a second caller returns False),
    the gap between posts, one failing job never stops the rest. A
    job that is no longer waiting when its turn comes (posted by
    Retry, deleted, paused meanwhile) is skipped. Returns True if
    the batch ran, False if another batch was already running.
    """
    if not _BATCH_LOCK.acquire(blocking=False):
        return False
    try:
        gap = load_post_gap_minutes() * 60
        ran = 0
        for jid in job_ids:
            with QUEUE_LOCK:
                job = next((j for j in QUEUE if j.get("id") == jid), None)
            if not job or job.get("status") != "waiting":
                continue
            if ran > 0 and gap > 0:
                time.sleep(gap)
            ran += 1
            try:
                run_job(job)
            except Exception:
                # run_job marks its own failures; this guard only
                # keeps one unexpected raise from stopping the rest.
                pass
        return True
    finally:
        _BATCH_LOCK.release()


# ---- Careful auto like/comment (her own accounts only) ----------------
# Official (Meta) route cannot like at all and can only comment on its
# own media, so this uses each liker's saved API session. Slow by
# design: a gap between actions, a daily cap, dedup via the engage
# log, and a block/challenge stops only that liker.
ENGAGE_LOG_FILE = DATA / "engage_log.json"
_ENGAGE_LOCK = threading.Lock()
_ENGAGE_BLOCK_WORDS = ("feedback_required", "challenge", "login_required",
                       "checkpoint", "action_block", "spam",
                       "two-factor", "two factor", "not logged in")


def load_engage_log():
    try:
        data = json.loads(ENGAGE_LOG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict) and isinstance(data.get("actions"), list):
            return data
    except Exception:
        pass
    return {"actions": []}


def save_engage_log(data):
    try:
        ENGAGE_LOG_FILE.write_text(json.dumps(data), encoding="utf-8")
    except Exception:
        pass


def engage_today_count():
    today = datetime.now().strftime("%Y-%m-%d")
    return sum(1 for a in load_engage_log().get("actions", [])
               if str(a.get("at", ""))[:10] == today)


def engage_already_done(liker, media_id, kind):
    for a in load_engage_log().get("actions", []):
        if (a.get("liker") == liker
                and str(a.get("media_id")) == str(media_id)
                and a.get("kind") == kind):
            return True
    return False


def engage_mark_done(liker, target, media_id, kind):
    with _ENGAGE_LOCK:
        data = load_engage_log()
        data.setdefault("actions", []).append({
            "at": datetime.now().strftime("%Y-%m-%dT%H:%M"),
            "liker": liker, "target": target,
            "media_id": str(media_id), "kind": kind})
        data["actions"] = data["actions"][-500:]
        save_engage_log(data)


def _engage_media_rows(medias):
    out = []
    for m in medias or []:
        taken = getattr(m, "taken_at", None)
        try:
            taken_s = taken.strftime("%d %b") if taken else ""
        except Exception:
            taken_s = ""
        out.append({
            "id": str(getattr(m, "id", "")),
            "code": getattr(m, "code", "") or "",
            "caption": (getattr(m, "caption_text", "") or "")[:80],
            "media_type": getattr(m, "media_type", 1),
            "like_count": getattr(m, "like_count", 0) or 0,
            "taken_at": taken_s,
            "has_liked": bool(getattr(m, "has_liked", False)),
            "video_duration": float(getattr(m, "video_duration", 0) or 0),
        })
    return out


def fetch_target_media(likers, target, amount=12):
    """Recent media of the target account, fetched with the first
    liker that manages to log in. Returns [{id, code, caption,
    media_type, like_count, taken_at, has_liked}]."""
    errors = []
    for liker in likers:
        try:
            cl = login_client(liker, load_passwords().get(liker, ""))
            user_id = cl.user_id_from_username(target)
            return _engage_media_rows(cl.user_medias(user_id, amount))
        except Exception as e:
            errors.append(f"@{liker}: {str(e)[:100]}")
    raise RuntimeError("Posts nahi mil saki — " + " | ".join(errors[:2]))


def media_view(cl, media_id, watch_seconds=8, media_type=1):
    """Report a realistic watch of a reel/video.

    instagrapi's media_seen reports a 100-3000 SECOND interval for
    every view — no real watch can be that long, so Instagram ignores
    the report and no view is counted. This sends the feed seen
    payload with a real watch interval (and really waits that long
    first, like a viewer would). Reels also get clip_seen — the
    Reels viewer's own seen-state endpoint (clips/write_seen_state):
    reel plays are counted on the clips surface, not the feed.
    """
    watch = max(3, min(int(watch_seconds or 8), 30))
    time.sleep(watch)
    end = int(datetime.now().timestamp())
    begin = end - watch
    media_pk, user_id = cl.media_id(media_id).split("_")
    data = {
        "container_module": "feed_timeline",
        "live_vods_skipped": {},
        "nuxes_skipped": {},
        "nuxes": {},
        "reels": {f"{media_pk}_{user_id}_{user_id}": [f"{begin}_{end}"]},
        "live_vods": {},
        "reel_media_skipped": {},
    }
    result = cl.private_request("/v2/media/seen/?reel=1&live_vod=0",
                                cl.with_default_data(data))
    ok = result.get("status") == "ok"
    if media_type == 2:
        ok = cl.clip_seen([media_id]) and ok
    return ok


def engage_actions(jobs, gap_seconds, stop_event, on_result):
    """Run like/comment jobs in order, with a gap between jobs.

    jobs: [{media_id, target, liker, like: bool, comment: str|None}].
    Logs in once per liker (cached). on_result(job, kind, ok, msg)
    is called after each action. A block/challenge stops only that
    liker — the others continue. Returns (attempted_jobs, [blocked]).
    """
    clients = {}
    blocked = set()
    attempted = 0
    for i, job in enumerate(jobs):
        liker = job["liker"]
        if liker in blocked:
            continue
        if stop_event is not None and stop_event.is_set():
            return attempted, sorted(blocked)
        if i > 0 and gap_seconds > 0:
            time.sleep(gap_seconds)
        if stop_event is not None and stop_event.is_set():
            return attempted, sorted(blocked)
        try:
            cl = clients.get(liker)
            if cl is None:
                cl = login_client(liker, load_passwords().get(liker, ""))
                clients[liker] = cl
        except Exception as e:
            on_result(job, "login", False,
                      f"Login nahi ho saka — {str(e)[:120]}")
            blocked.add(liker)
            continue
        ran = False
        if job.get("view"):
            try:
                if not media_view(cl, job["media_id"],
                                  job.get("watch_seconds", 8),
                                  job.get("media_type", 1)):
                    raise RuntimeError("View register nahi hua")
                engage_mark_done(liker, job.get("target", ""),
                                 job["media_id"], "view")
                on_result(job, "👁 View", True, "ho gaya")
                ran = True
            except Exception as e:
                msg = str(e)[:200]
                if any(w in msg.lower() for w in _ENGAGE_BLOCK_WORDS):
                    on_result(job, "⛔ Block", False, msg)
                    blocked.add(liker)
                    continue
                on_result(job, "❌ View", False, msg)
        if job.get("like"):
            try:
                cl.media_like(job["media_id"])
                engage_mark_done(liker, job.get("target", ""),
                                 job["media_id"], "like")
                on_result(job, "❤️ Like", True, "ho gaya")
                ran = True
            except Exception as e:
                msg = str(e)[:200]
                if any(w in msg.lower() for w in _ENGAGE_BLOCK_WORDS):
                    on_result(job, "⛔ Block", False, msg)
                    blocked.add(liker)
                    continue
                on_result(job, "❌ Like", False, msg)
        if job.get("comment") and liker not in blocked:
            try:
                cl.media_comment(job["media_id"], job["comment"])
                engage_mark_done(liker, job.get("target", ""),
                                 job["media_id"], "comment")
                on_result(job, "💬 Comment", True, "ho gaya")
                ran = True
            except Exception as e:
                msg = str(e)[:200]
                if any(w in msg.lower() for w in _ENGAGE_BLOCK_WORDS):
                    on_result(job, "⛔ Block", False, msg)
                    blocked.add(liker)
                    continue
                on_result(job, "❌ Comment", False, msg)
        if ran:
            attempted += 1
    return attempted, sorted(blocked)


def run_job_list_batched(job_ids, batch_size=5, confirm=None):
    """Post job_ids in batches of batch_size, one by one with gap.

    "Start posting": the caller tells it how many posts per batch
    and whether to ask before the next batch. confirm(batch_no,
    attempted, remaining) -> bool is called (from this worker
    thread) after each batch except the last; False stops the run
    with the rest left waiting on their schedule. Holds the batch
    lock for the whole run so the scheduler cannot interleave —
    while it waits for an answer between batches, due posts simply
    wait for the next tick. Returns None if another batch is
    already running, else (attempted, stopped_early).
    """
    if not _BATCH_LOCK.acquire(blocking=False):
        return None
    try:
        gap = load_post_gap_minutes() * 60
        batch_size = max(1, int(batch_size or 5))
        attempted = 0
        stopped_early = False
        total = len(job_ids)
        for start in range(0, total, batch_size):
            chunk = job_ids[start:start + batch_size]
            batch_no = start // batch_size + 1
            for jid in chunk:
                with QUEUE_LOCK:
                    job = next((j for j in QUEUE if j.get("id") == jid),
                               None)
                if not job or job.get("status") != "waiting":
                    continue
                if attempted > 0 and gap > 0:
                    time.sleep(gap)
                attempted += 1
                try:
                    run_job(job)
                except Exception:
                    # run_job marks its own failures; this guard only
                    # keeps one unexpected raise from stopping the rest.
                    pass
            if start + batch_size >= total:
                break
            if confirm is not None:
                ids = set(job_ids)
                with QUEUE_LOCK:
                    remaining = sum(
                        1 for j in QUEUE
                        if j.get("id") in ids
                        and j.get("status") == "waiting")
                if not confirm(batch_no, attempted, remaining):
                    stopped_early = True
                    break
        return attempted, stopped_early
    finally:
        _BATCH_LOCK.release()


def run_due_jobs_by_account(usernames, accounts_per_batch=5, confirm=None,
                            progress=None):
    """Post due jobs account by account, asking between account batches.

    "Accounts batch": she tells it how many accounts per batch, it
    posts those accounts' due jobs one by one with the gap, then
    asks before the next accounts — so between batches she can fix
    a broken account (login) before its turn comes. usernames are
    plain account names, in the order to post (her account-list
    order). Each account's due jobs are looked up live at its turn,
    so a job stopped or deleted meanwhile is skipped. confirm(
    batch_no, accounts_done, accounts_left, attempted) -> bool is
    called after each account-batch except the last; False stops
    with the rest left waiting. progress(done, total, attempted,
    current) is called at the start and after each account finishes
    (current = the next account to post, "" when none) so the UI can
    show live that posting is actually happening — without it the
    tab stays silent for the whole gap between posts and she cannot
    tell whether anything is running. Holds the batch lock for the
    whole run. Returns None if another batch is already running,
    else (attempted, stopped_early).
    """
    if not _BATCH_LOCK.acquire(blocking=False):
        return None
    try:
        gap = load_post_gap_minutes() * 60
        accounts_per_batch = max(1, int(accounts_per_batch or 5))
        attempted = 0
        stopped_early = False
        total = len(usernames)
        done = 0

        def _tell(current=""):
            if progress is not None:
                try:
                    progress(done, total, attempted, current)
                except Exception:
                    pass

        if total:
            _tell(usernames[0])
        for start in range(0, total, accounts_per_batch):
            chunk = usernames[start:start + accounts_per_batch]
            batch_no = start // accounts_per_batch + 1
            for idx, username in enumerate(chunk):
                for job in due_jobs(only_due=True):
                    if job.get("account", "").lower() != username.lower():
                        continue
                    with QUEUE_LOCK:
                        live = next(
                            (j for j in QUEUE
                             if j.get("id") == job.get("id")), None)
                    if not live or live.get("status") != "waiting":
                        continue
                    if attempted > 0 and gap > 0:
                        time.sleep(gap)
                    attempted += 1
                    try:
                        run_job(live)
                    except Exception:
                        # run_job marks its own failures; this guard
                        # only keeps one unexpected raise from
                        # stopping the rest.
                        pass
                done += 1
                _tell(usernames[done] if done < total else "")
            done_accts = start + len(chunk)
            if done_accts >= total:
                break
            if confirm is not None:
                if not confirm(batch_no, done_accts,
                               total - done_accts, attempted):
                    stopped_early = True
                    break
        return attempted, stopped_early
    finally:
        _BATCH_LOCK.release()


def today_posting_plan(jobs, today):
    """Today's posting plan: (slot order, {slot: [jobs]}).

    Slots: "Reh gayi" (overdue jobs that will run at the next tick),
    "Foran" (no time set, or an unreadable time — due_jobs treats those
    as due now), then today's times "HH:MM" in order. Only jobs that
    post today (or already did) are included: future jobs, old done /
    failed jobs and old paused jobs are left out, so the plan never
    drowns in the thousands of far-future jobs. Jobs in a slot are
    sorted by account, then filename.
    """
    plan = {}

    def put(slot, job):
        plan.setdefault(slot, []).append(job)

    for job in jobs:
        st = job.get("status", "")
        sched = (job.get("scheduled_at") or "").strip()
        date, clock = "", ""
        if len(sched) >= 10 and sched[4:5] == "-" and sched[7:8] == "-":
            date, clock = sched[:10], sched[11:16]
        if date == today:
            put(clock if clock else "Foran", job)
        elif not sched or not date:
            # No time, or unreadable time: due now, if still to run.
            if st in ("waiting", "uploading", "needs_code"):
                put("Foran", job)
        elif date < today:
            # Overdue and still to run: it posts at the next tick.
            if st in ("waiting", "uploading", "needs_code"):
                put("Reh gayi", job)
        # date > today (future) and old done/failed/paused: not today.
    order = []
    for special in ("Reh gayi", "Foran"):
        if special in plan:
            order.append(special)
    order.extend(sorted(t for t in plan if t not in ("Reh gayi", "Foran")))
    for slot in plan:
        plan[slot].sort(key=lambda j: (
            (("📘 " if j.get("via") == "meta" else "")
             + j.get("account", "")),
            j.get("filename", "")))
    return order, plan


def due_jobs(only_due):
    """Which waiting jobs should run now.
    only_due=True  (auto scheduler): "post now" jobs + scheduled jobs whose
                   time has arrived.
    only_due=False ("Post now" button): only "post now" jobs. Scheduled jobs
                   wait for their time (or their own "Post now" button)."""
    now = datetime.now()
    with QUEUE_LOCK:
        jobs = []
        for j in QUEUE:
            if j.get("status") != "waiting":
                continue
            sched = (j.get("scheduled_at") or "").strip()
            if not sched:
                jobs.append(j)
            elif only_due:
                try:
                    if datetime.fromisoformat(sched) <= now:
                        jobs.append(j)
                except ValueError:
                    jobs.append(j)
        return jobs


def start_batch_thread(only_due=False):
    threading.Thread(target=run_batch, args=(only_due,), daemon=True).start()


def scheduler_tick():
    """One automatic tick: due posts + daily watches, unless paused."""
    if scheduler_paused():
        return
    try:
        run_batch(only_due=True)
    except Exception:
        pass
    try:
        check_watches()
    except Exception:
        pass


def scheduler_loop():
    """Posts scheduled jobs and daily link watches when their time arrives."""
    while True:
        time.sleep(30)
        scheduler_tick()


def start_single_job(job):
    threading.Thread(target=run_job, args=(job,), daemon=True).start()


# ------------------------------------------------------------- Meta (Facebook login)

META_API_VERSION = "v26.0"
META_OAUTH_PORT = 8765
META_FILE = DATA / "meta.json"
# Instagram API with Facebook Login — required content permissions
# (from "API setup with Facebook login" in the Meta app dashboard).
# Note: the dashboard lists "instagram_content_publishing" but the login
# only accepts "instagram_content_publish".
META_SCOPES = ("instagram_basic,instagram_content_publish,"
               "pages_read_engagement,pages_show_list,business_management")


class MetaError(RuntimeError):
    pass


class MetaAuthError(MetaError):
    """Token missing/expired — the user must log in with Facebook again."""


def load_meta():
    try:
        d = json.loads(META_FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def save_meta(d):
    META_FILE.write_text(json.dumps(d, indent=1), encoding="utf-8")


def meta_login_url(app_id):
    import urllib.parse
    redirect = f"http://localhost:{META_OAUTH_PORT}/callback"
    q = urllib.parse.urlencode({
        "client_id": app_id,
        "redirect_uri": redirect,
        "scope": META_SCOPES,
        "response_type": "code",
    })
    return f"https://www.facebook.com/{META_API_VERSION}/dialog/oauth?{q}"


def _meta_http_json(url, data=None, timeout=90):
    import urllib.request
    req = urllib.request.Request(url, data=data,
                                 headers={"User-Agent": "InstaUploader/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            payload = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode("utf-8"))
        except Exception:
            raise MetaError(f"Facebook error (HTTP {e.code}).")
        err = payload.get("error", {})
        raise _meta_friendly_error(err)
    except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
        raise MetaError(f"Couldn't reach Facebook ({e}). Check your internet.")
    if isinstance(payload, dict) and payload.get("error"):
        raise _meta_friendly_error(payload["error"])
    return payload


def _meta_friendly_error(err):
    code = err.get("code")
    sub = err.get("error_subcode")
    msg = err.get("message", "Unknown Facebook error.")
    detail = f" [fb code {code}" + (f"/{sub}" if sub else "") + "]"
    if code == 190 and sub in (460, 461, 463, 464):
        return MetaAuthError(
            "Facebook login expired — press 'Login with Facebook' again."
            + detail)
    if code == 190:
        return MetaAuthError(f"Facebook: {msg}{detail}")
    return MetaError(f"Facebook: {msg}{detail}")


def meta_oauth_login(app_id, app_secret, status_cb=None):
    """Browser OAuth with a tiny local callback server.

    Returns (long_lived_token, expires_at_unix).
    """
    import urllib.parse

    holder = {}

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            params = urllib.parse.parse_qs(
                urllib.parse.urlparse(self.path).query)
            if "code" in params:
                holder["code"] = params["code"][0]
                body = ("<h2 style='font-family:sans-serif'>Done! "
                        "You can close this tab and go back to "
                        "InstaUploader.</h2>")
            else:
                holder["error"] = params.get(
                    "error_description", ["Login was cancelled"])[0]
                body = (f"<h2 style='font-family:sans-serif'>Login didn't "
                        f"complete: {holder['error']}</h2>")
            data = body.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, *a):
            pass

    try:
        server = ThreadingHTTPServer(("127.0.0.1", META_OAUTH_PORT), Handler)
    except OSError:
        raise MetaError("Port 8765 is busy — close the other program using it "
                        "and try again.")
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        webbrowser.open(meta_login_url(app_id))
        if status_cb:
            status_cb("Browser opened — log in with Facebook and approve…")
        deadline = time.time() + 180
        while (time.time() < deadline and "code" not in holder
               and "error" not in holder):
            time.sleep(0.5)
    finally:
        server.shutdown()
    if "error" in holder:
        raise MetaError(holder["error"])
    if "code" not in holder:
        raise MetaError("Login timed out — try again.")
    code = holder["code"]

    import urllib.parse
    redirect = urllib.parse.quote(
        f"http://localhost:{META_OAUTH_PORT}/callback", safe="")
    short = _meta_http_json(
        f"https://graph.facebook.com/{META_API_VERSION}/oauth/access_token"
        f"?client_id={app_id}&redirect_uri={redirect}"
        f"&client_secret={app_secret}&code={code}")["access_token"]
    return meta_to_long_lived(app_id, app_secret, short)


def meta_to_long_lived(app_id, app_secret, short_token):
    """Exchange a short-lived user token for a long-lived (~60 days) one.

    Returns (long_lived_token, expires_at_unix). Works with tokens from
    the browser login or pasted manually from the Graph API Explorer.
    """
    ll = _meta_http_json(
        f"https://graph.facebook.com/{META_API_VERSION}/oauth/access_token"
        f"?grant_type=fb_exchange_token&client_id={app_id}"
        f"&client_secret={app_secret}&fb_exchange_token={short_token}")
    if not ll.get("access_token"):
        raise MetaError("Facebook didn't return a token. The pasted token "
                        "may be wrong or expired — generate a fresh one.")
    expires_at = int(time.time()) + int(ll.get("expires_in", 5184000))
    return ll["access_token"], expires_at


def meta_device_login_start(app_id, app_secret, client_token=None):
    """Start Facebook Device Login. No redirect URI needed.

    Meta's device docs want the CLIENT TOKEN (App Settings -> Advanced)
    combined with the app id as the access_token; fall back to the app
    secret when no client token was provided.

    Returns the device response: user_code, verification_uri, code,
    interval, expires_in. The user types user_code at facebook.com/device.
    """
    import urllib.parse
    cred = client_token or app_secret
    data = urllib.parse.urlencode({
        "access_token": f"{app_id}|{cred}",
        "scope": META_SCOPES,
    }).encode()
    try:
        resp = _meta_http_json(
            f"https://graph.facebook.com/{META_API_VERSION}/device/login",
            data=data)
    except MetaError as e:
        if "Invalid API method" in str(e) or "code 3" in str(e).lower():
            raise MetaError(
                "Enable 'Login from Devices' first: in your Meta app go to "
                "Facebook Login -> Settings -> 'Login from Devices' -> Yes, "
                "then try again.")
        raise
    if not resp.get("user_code") or not resp.get("code"):
        raise MetaError("Facebook didn't start the device login.")
    return resp


def meta_device_login_poll(app_id, app_secret, device_code, interval=5,
                           timeout=420, stop_event=None, client_token=None):
    """Poll until the user approves at facebook.com/device.

    Returns (access_token, expires_at_unix). The device-flow token is
    already long-lived (~60 days), no exchange needed.
    """
    import urllib.parse
    import urllib.request
    url = f"https://graph.facebook.com/{META_API_VERSION}/device/login_status"
    app_token = f"{app_id}|{client_token or app_secret}"
    deadline = time.time() + timeout
    while time.time() < deadline:
        if stop_event is not None and stop_event.is_set():
            raise MetaError("Cancelled.")
        time.sleep(max(5, interval))
        data = urllib.parse.urlencode(
            {"access_token": app_token, "code": device_code}).encode()
        req = urllib.request.Request(
            url, data=data, headers={"User-Agent": "InstaUploader/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                resp = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                err = json.loads(e.read().decode("utf-8")).get("error", {})
            except Exception:
                continue  # transient — keep polling
            sub = err.get("error_subcode")
            if sub == 1349174:  # authorization pending
                continue
            if sub == 1349152:  # code expired
                raise MetaError("Code expired — press the button for a new code.")
            raise _meta_friendly_error(err)
        except (urllib.error.URLError, TimeoutError, ConnectionError):
            continue  # transient — keep polling
        if resp.get("access_token"):
            expires_at = int(time.time()) + int(resp.get("expires_in", 5184000))
            return resp["access_token"], expires_at
        # unexpected shape — keep polling
    raise MetaError("Code expired — press the button for a new code.")


def meta_api(path, token, params=None, method="GET", timeout=90):
    import urllib.parse
    params = dict(params or {})
    params["access_token"] = token
    base = f"https://graph.facebook.com/{META_API_VERSION}{path}"
    if method == "GET":
        return _meta_http_json(
            base + "?" + urllib.parse.urlencode(params), timeout=timeout)
    return _meta_http_json(
        base, data=urllib.parse.urlencode(params).encode(), timeout=timeout)


def meta_api_paged(path, token, params=None, timeout=90):
    """GET a Graph edge, following every page of results.

    Facebook returns 25 items per page by default, so a plain
    /me/accounts call silently drops every Page past the first 25 —
    with 25+ Pages the list looks "random" (some of one account's,
    some of another's) and newer Pages never appear at all. Ask for
    100 per page and follow paging.next until it ends (capped so a
    runaway cursor can never loop forever). Returns the combined
    data list. A failure on a LATER page keeps the items already
    collected; a failure on the FIRST page raises, as before.
    """
    params = dict(params or {})
    params["limit"] = 100
    items = []
    resp = meta_api(path, token, params, timeout=timeout)
    for _ in range(20):  # at most 20 pages = 2000 items
        items.extend(resp.get("data", []) or [])
        nxt = (resp.get("paging") or {}).get("next")
        if not nxt:
            break
        try:
            resp = _meta_http_json(nxt, timeout=timeout)
        except MetaError:
            break
    return items


def meta_token():
    m = load_meta()
    tok = m.get("access_token")
    if not tok:
        raise MetaAuthError("Not logged in with Facebook yet.")
    if m.get("expires_at", 0) < time.time():
        raise MetaAuthError(
            "Facebook login expired — press 'Login with Facebook' again.")
    return tok


def meta_delete_media(media_id):
    """Delete an Instagram post published via the Facebook route.

    Graph API DELETE on the media id with the stored Page token.
    Raises MetaError on failure (already deleted, expired login...).
    """
    import urllib.parse
    import urllib.request
    token = meta_token()
    url = (f"https://graph.facebook.com/{META_API_VERSION}/{media_id}"
           f"?access_token={urllib.parse.quote(token)}")
    req = urllib.request.Request(url, method="DELETE",
                                 headers={"User-Agent": "InstaUploader/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            payload = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode("utf-8"))
        except Exception:
            raise MetaError(f"Facebook error (HTTP {e.code}).")
        raise _meta_friendly_error(payload.get("error", {}))
    except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
        raise MetaError(f"Couldn't reach Facebook ({e}). Check your internet.")
    if isinstance(payload, dict) and payload.get("error"):
        raise _meta_friendly_error(payload["error"])
    if not payload.get("success"):
        raise MetaError("Facebook did not confirm the delete.")
    return True


_STORY_GONE_HINTS = ("not found", "deleted", "expired", "gone",
                     "no longer", "does not exist", "invalid media",
                     "media not found", "unsupported delete")


def _story_error_is_gone(ex):
    """An already-gone/expired story is not a failure: stories live
    24h, so by delete time most are simply over. A login or network
    error is a real failure and must surface as one."""
    if isinstance(ex, MetaAuthError):
        return False
    name = type(ex).__name__.lower()
    if "notfound" in name or "not_found" in name:
        return True
    low = str(ex).lower()
    if "couldn't reach" in low or "check your internet" in low:
        return False
    return any(h in low for h in _STORY_GONE_HINTS)


def _delete_story_for_entry(e, stories, clients):
    """Delete one entry's recorded story. Returns a story dict:
    {"status": "deleted"|"gone"|"failed"|"none", "error": str}.
    "none" = no recorded story (old post, or posted without one) —
    expected, needs no action. "gone" = the story already expired or
    was removed — reported gracefully, never as a failure. The record
    is dropped whenever a record existed (a deleted post's row is
    gone, so the record could never be used again).
    """
    rec = stories.get(e["link"])
    if not rec:
        return {"status": "none", "error": ""}
    try:
        if e["via"] == "meta":
            meta_delete_media(rec["story_id"])
        else:
            acct = e["account"]
            if acct not in clients:
                clients[acct] = login_client(
                    acct, load_passwords().get(acct, ""))
            clients[acct].story_delete(rec["story_id"])
        story = {"status": "deleted", "error": ""}
    except Exception as ex:
        if _story_error_is_gone(ex):
            story = {"status": "gone", "error": ""}
        else:
            story = {"status": "failed", "error": str(ex)[:120]}
    drop_story(e["link"])
    return story


def delete_posted_entries(entries, on_progress=None, delete_story=False,
                          story_only=False, should_stop=None):
    """Delete posted Instagram media, one login per account.

    Returns [(entry, ok, error, story)]: a failure on one post never
    stops the rest, and only successfully deleted posts are dropped
    from history by the caller. After every entry (ok or failed),
    on_progress(done, total, filename) fires so the UI can show live
    progress — a long delete must never look stuck.

    `story` is None unless delete_story or story_only is on, else a
    dict: {"status": "deleted"|"gone"|"failed"|"none", "error": str}.
    In the old combined flow a story was only touched when its post
    was actually deleted; in story_only mode the post is never
    touched at all — only the story part runs, so the caller must
    never treat those results as deleted posts (their history lines
    stay) and must never report them as post failures.

    should_stop: a threading.Event checked between entries; when set,
    the loop breaks and only already-processed entries are returned
    (already-deleted posts stay deleted — they cannot come back).
    """
    results, clients = [], {}
    stories = load_story_posts() if (delete_story or story_only) else {}
    for i, e in enumerate(entries):
        if should_stop is not None and should_stop.is_set():
            break
        story = None
        if story_only:
            story = _delete_story_for_entry(e, stories, clients)
            results.append((e, True, "", story))
        else:
            try:
                if e["via"] == "meta":
                    meta_delete_media(e["link"])
                else:
                    acct = e["account"]
                    if acct not in clients:
                        clients[acct] = login_client(
                            acct, load_passwords().get(acct, ""))
                    cl = clients[acct]
                    cl.media_delete(cl.media_pk_from_url(e["link"]))
                post_ok, post_err = True, ""
            except Exception as ex:
                post_ok, post_err = False, str(ex)[:150]
            if delete_story and post_ok:
                story = _delete_story_for_entry(e, stories, clients)
            results.append((e, post_ok, post_err, story))
        if on_progress is not None:
            try:
                on_progress(i + 1, len(entries), e["filename"])
            except Exception:
                pass
    return results


def meta_list_businesses(token):
    """Business portfolios the user granted the app access to."""
    try:
        data = meta_api_paged("/me/businesses", token, {"fields": "id,name"})
    except MetaError:
        return []
    return [{"id": str(b.get("id", "")), "name": b.get("name", "")}
            for b in data if b.get("id")]


def meta_discover(token):
    """Find businesses, Pages and linked Instagram accounts in one go.

    Returns {"businesses": [...], "pages": [...], "ig_accounts": [...]}.
    """
    businesses = meta_list_businesses(token)
    pages = []
    ig_accounts = []
    try:
        data = meta_api_paged(
            "/me/accounts", token,
            {"fields": "name,instagram_business_account{id,username}"})
        for pg in data:
            pages.append({"id": str(pg.get("id", "")),
                          "name": pg.get("name", "")})
            ig = pg.get("instagram_business_account")
            if ig and ig.get("id"):
                ig_accounts.append({"page": pg.get("name", ""),
                                    "ig_id": str(ig["id"]),
                                    "username": ig.get("username", "")})
    except MetaError:
        pass
    if not ig_accounts:
        # New Instagram API fallback: the token may directly represent an IG user.
        try:
            me = meta_api("/me", token, {"fields": "id,username"})
            if me.get("id") and me.get("username"):
                ig_accounts.append({"page": "", "ig_id": str(me["id"]),
                                    "username": me.get("username", "")})
        except MetaError:
            pass
    return {"businesses": businesses, "pages": pages,
            "ig_accounts": ig_accounts}


def meta_list_ig_accounts(token):
    """Instagram Business/Creator accounts linked through the user's Pages."""
    return meta_discover(token)["ig_accounts"]


def convert_api_jobs_to_meta(ig_accounts):
    """Switch waiting API-route jobs to the Meta route for accounts
    that are now Page-linked.

    ig_accounts: discovery entries {username, ig_id, ...}. Only jobs
    with status == "waiting" whose account matches a discovered
    username (case-insensitive) and that are not already Meta move.
    The account name is normalized to the discovery casing (so the
    queue filter keeps matching); only via/meta_ig_id otherwise
    change, so times, captions, covers and videos stay exactly as
    queued. Returns {username: count} of converted jobs (discovery
    casing). Paused/done/failed jobs are never touched.
    """
    by_name = {}
    for a in ig_accounts or []:
        uname = (a.get("username") or "").strip()
        ig_id = (a.get("ig_id") or "").strip()
        if uname and ig_id:
            by_name[uname.lower()] = (uname, ig_id)
    if not by_name:
        return {}
    moved = {}
    with QUEUE_LOCK:
        for j in QUEUE:
            if j.get("status") != "waiting" or j.get("via") == "meta":
                continue
            hit = by_name.get((j.get("account") or "").strip().lower())
            if not hit:
                continue
            uname, ig_id = hit
            j["account"] = uname
            j["via"] = "meta"
            j["meta_ig_id"] = ig_id
            moved[uname] = moved.get(uname, 0) + 1
    if moved:
        save_queue()
    return moved


# Temporary hosts for the Meta route: Instagram can only fetch media
# from a public link, so the file goes to a free host first. catbox.moe
# is the main host; uguu.se is the fallback — on 2026-11-11 Instagram
# stopped accepting catbox links (photos AND videos both failed with a
# provably valid file), while the old direct-upload route kept working.
META_TEMP_HOSTS = ("catbox", "uguu")


def _upload_once(filepath, host):
    """One upload attempt to one temporary host. Returns the public URL
    or raises MetaError."""
    import urllib.request
    import uuid
    boundary = uuid.uuid4().hex
    with open(filepath, "rb") as f:
        file_data = f.read()
    filename = Path(filepath).name
    if host == "uguu":
        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="files[]"; '
            f'filename="{filename}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n"
        ).encode() + file_data + f"\r\n--{boundary}--\r\n".encode()
        url = "https://uguu.se/upload.php"
    else:  # catbox
        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="reqtype"\r\n\r\n'
            f"fileupload\r\n"
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="fileToUpload"; '
            f'filename="{filename}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n"
        ).encode() + file_data + f"\r\n--{boundary}--\r\n".encode()
        url = "https://catbox.moe/user/api.php"
    req = urllib.request.Request(
        url, data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}",
                 "User-Agent": "InstaUploader/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            raw = r.read().decode("utf-8").strip()
    except Exception as e:
        raise MetaError(
            f"Couldn't upload media for Instagram to fetch via {host} "
            f"({e}).")
    if host == "uguu":
        import json
        try:
            data = json.loads(raw)
            link = (data.get("files") or [{}])[0].get("url", "")
        except Exception:
            link = ""
        if not link.startswith("https://"):
            raise MetaError(f"Temporary upload failed: {raw[:120]}")
        return link
    if not raw.startswith("https://"):
        raise MetaError(f"Temporary upload failed: {raw[:120]}")
    return raw


def _upload_host(filepath, host):
    """Upload to one host, one attempt only. The retry across hosts
    lives in meta_upload_temp / meta_publish: a second attempt on the
    same host made a failing retry drag on for ~16 minutes (2 hosts x
    2 attempts x 240s) while the status bar just said "Retrying…"
    (craftbyzara55, 2026-11-12)."""
    return _upload_once(filepath, host)


def meta_upload_temp(filepath):
    """Upload a file to a temporary public host so Instagram can fetch it.

    Tries catbox.moe first, then uguu.se. The file gets a public link,
    so only use this for content you are fine sharing via a link.
    """
    last_err = None
    for host in META_TEMP_HOSTS:
        try:
            return _upload_host(filepath, host)
        except MetaError as e:
            last_err = e
    raise last_err


def _meta_publish_media(ig_id, token, params, is_video, kind="post"):
    """Create a container for one media URL, wait for processing
    (videos), and publish it. Returns the published media id."""
    msgs = {
        "post": ("Instagram didn't accept the media.",
                 "Instagram couldn't process that video.",
                 "Instagram took too long with that video.",
                 "Instagram didn't publish the post."),
        "story": ("Instagram didn't accept the story media.",
                  "Instagram couldn't process that story video.",
                  "Instagram took too long with that story.",
                  "Instagram didn't publish the story."),
    }[kind]
    container = meta_api(f"/{ig_id}/media", token, params, method="POST")
    cid = container.get("id")
    if not cid:
        raise MetaError(msgs[0])
    if is_video:
        deadline = time.time() + 600
        while time.time() < deadline:
            code = meta_api(f"/{cid}", token,
                            {"fields": "status_code"}).get("status_code")
            if code == "FINISHED":
                break
            if code == "ERROR":
                raise MetaError(msgs[1])
            time.sleep(10)
        else:
            raise MetaError(msgs[2])
    pub = meta_api(f"/{ig_id}/media_publish", token,
                   {"creation_id": cid}, method="POST")
    if not pub.get("id"):
        raise MetaError(msgs[3])
    return pub["id"]


def meta_publish(ig_id, token, filepath, caption):
    """Publish a photo (feed post) or video (reel) via the Instagram API.

    Tries each temporary host in turn: if Instagram rejects the media
    from one host (e.g. it cannot fetch the file there), the whole
    publish is retried with the file on the next host.
    """
    ext = Path(filepath).suffix.lower()
    is_video = ext in VIDEO_EXTS
    if is_video:
        # Same fix as the unofficial route: Pinterest/yt-dlp videos
        # sometimes have odd codecs that Instagram rejects with
        # "couldn't process that video" — re-encode to H.264/AAC
        # first (cached as *_ig.mp4, so it runs once per file).
        filepath = _fix_video_for_instagram(filepath)
    last_err = None
    for host in META_TEMP_HOSTS:
        try:
            media_url = _upload_host(filepath, host)
            params = {"caption": caption or ""}
            if is_video:
                params.update({"media_type": "REELS", "video_url": media_url,
                               "share_to_feed": "true"})
            else:
                params.update({"image_url": media_url})
            return _meta_publish_media(ig_id, token, params, is_video)
        except MetaError as e:
            last_err = e
    raise last_err


def meta_publish_carousel(ig_id, token, filepaths, caption):
    """Publish a photo carousel via the Instagram API.

    Same 3-step shape as meta_publish: one image container per photo
    (marked is_carousel_item), then a CAROUSEL container holding their
    ids (comma-joined, as the Graph API documents), then publish.
    Returns the published media id. Photos only, 2–20.
    """
    paths = [Path(p) for p in filepaths]
    if len(paths) < 2:
        raise MetaError("Carousel ke liye kam se kam 2 photos chahiye.")
    if len(paths) > 20:
        raise MetaError(
            "Instagram carousel mein zyada se zyada 20 photos hoti hain.")
    bad = [p for p in paths if p.suffix.lower() not in IMAGE_EXTS]
    if bad:
        raise MetaError(
            "Carousel mein sirf photos hoti hain — video nahi: "
            + ", ".join(p.name for p in bad[:3]))
    last_err = None
    for host in META_TEMP_HOSTS:
        try:
            children = []
            for fp in paths:
                media_url = _upload_host(fp, host)
                container = meta_api(f"/{ig_id}/media", token,
                                     {"image_url": media_url,
                                      "is_carousel_item": "true"},
                                     method="POST")
                cid = container.get("id")
                if not cid:
                    raise MetaError(
                        "Instagram didn't accept a carousel photo.")
                children.append(cid)
            container = meta_api(f"/{ig_id}/media", token,
                                 {"media_type": "CAROUSEL",
                                  "children": ",".join(children),
                                  "caption": caption or ""}, method="POST")
            cid = container.get("id")
            if not cid:
                raise MetaError("Instagram didn't accept the carousel.")
            pub = meta_api(f"/{ig_id}/media_publish", token,
                           {"creation_id": cid}, method="POST")
            if not pub.get("id"):
                raise MetaError("Instagram didn't publish the carousel.")
            return pub["id"]
        except MetaError as e:
            last_err = e
    raise last_err


def meta_publish_story(ig_id, token, filepath):
    """Publish the same media as a Story via the Instagram API."""
    ext = Path(filepath).suffix.lower()
    is_video = ext in VIDEO_EXTS
    if is_video:
        # Same H.264/AAC fix as meta_publish (see there).
        filepath = _fix_video_for_instagram(filepath)
    last_err = None
    for host in META_TEMP_HOSTS:
        try:
            media_url = _upload_host(filepath, host)
            params = {"media_type": "STORIES"}
            if is_video:
                params["video_url"] = media_url
            else:
                params["image_url"] = media_url
            return _meta_publish_media(ig_id, token, params, is_video,
                                       kind="story")
        except MetaError as e:
            last_err = e
    raise last_err


def _is_upload_error(e):
    """Is this Meta failure the temp-host upload leg (both hosts)?
    Those are the only failures the old-route fallback applies to:
    the upload happens before any container is created, so Instagram
    never saw the media and the fallback cannot double-post."""
    msg = str(e)
    return ("Couldn't upload media" in msg
            or "Temporary upload failed" in msg)


def meta_run_job(job):
    job["status"] = "uploading"
    job["message"] = "Posting via Facebook…"
    save_queue()
    try:
        token = meta_token()
        ig_id = job.get("meta_ig_id")
        if not ig_id:
            raise MetaError("This post lost its linked Instagram account — "
                            "please add it again.")
        if job.get("files"):
            media_id = meta_publish_carousel(ig_id, token, job["files"],
                                             job.get("caption", ""))
        else:
            media_id = meta_publish(ig_id, token, job["filepath"],
                                    job.get("caption", ""))
        job["status"] = "done"
        job["link"] = ""
        job["message"] = "Posted via Facebook! ✅"
        if job.get("to_story"):
            # post is already up — a story failure must not fail the job
            # A carousel's story uses its first photo. The story id is
            # recorded under the post's media id (the Meta history link).
            story_path = (job.get("files") or [job["filepath"]])[0]
            try:
                sid = meta_publish_story(ig_id, token, story_path)
                if sid:
                    record_story(media_id, job["account"], sid)
                job["message"] = "Posted via Facebook! ✅ + Story ✅"
            except Exception as se:
                job["message"] = ("Posted via Facebook! ✅ "
                                  f"(Story failed: {str(se)[:80]})")
        if job.get("cover"):
            job["message"] += (" (Cover nahi laga — Meta route pe "
                               "cover nahi hota)")
        mark_posted(job.get("source"), job["account"])
        log_history("📘 " + job["account"], job["filename"],
                    job.get("caption", ""), media_id)
    except MetaAuthError as e:
        job["status"] = "failed"
        job["message"] = str(e)
        mark_login_failed(job["account"], job["message"])
    except Exception as e:
        if _is_upload_error(e):
            # Meta's temp-host upload failed on both hosts — the post
            # would otherwise never go out, and she has spent a month
            # building this tool so posts go out while she focuses on
            # content. Fall back to the old route, which uploads
            # directly to Instagram and works on her slow connection
            # (craftbyzara55 pinhls, 2026-11-12 — she posted it that
            # way by hand). The job message says so, so it is never
            # silent; Meta stays the first try on every Retry.
            job["message"] = ("Meta upload nahi hua — purane route se "
                              "post ho rahi hai…")
            save_queue()
            _post_old_route(job)
            if job.get("status") == "done":
                job["message"] = (job["message"]
                                  + " (Meta upload fail — purana route)")
            elif job.get("status") == "failed":
                job["message"] = (f"Meta upload fail ({str(e)[:80]}) + "
                                  f"purana route fail: "
                                  f"{job['message'][:80]}")
            else:  # needs_code / needs_approval — action needed
                job["message"] = ("Meta upload fail — "
                                  + job["message"])
            save_queue()
            return
        job["status"] = "failed"
        job["message"] = str(e)[:200]
        if looks_like_login_failure(job["message"]):
            mark_login_failed(job["account"], job["message"])
    save_queue()


# ------------------------------------------------------------- html pages

CSS = """
body{font-family:'Segoe UI',Arial,sans-serif;max-width:700px;margin:0 auto;
padding:20px;background:#faf7f2;color:#333}
h1{color:#a87b1f;text-align:center}
.card{background:#fff;border-radius:14px;padding:20px;margin:16px 0;
box-shadow:0 2px 10px rgba(0,0,0,.07)}
label{font-weight:600;display:block;margin:10px 0 4px}
input[type=text],input[type=password],select,textarea{width:100%;padding:10px;
border:1px solid #ddd;border-radius:8px;font-size:15px;box-sizing:border-box}
button,.btn{background:#e8a0bf;color:#fff;border:none;border-radius:10px;
padding:12px 26px;font-size:16px;font-weight:700;cursor:pointer;margin-top:12px}
button:hover,.btn:hover{background:#d98aae}
button.big{font-size:18px;padding:14px 34px;width:100%}
button.mini{padding:6px 12px;font-size:13px;margin:2px}
button.gray{background:#bbb}
.small{font-size:13px;color:#888}
.ok{background:#e6f7e6;border:1px solid #8fd694;padding:14px;border-radius:10px}
.err{background:#fde8e8;border:1px solid #e88;padding:14px;border-radius:10px}
.info{background:#eef4fd;border:1px solid #9db9e8;padding:14px;border-radius:10px}
a{color:#a87b1f}
.row{display:flex;gap:10px}.row>*{flex:1}
.hist{font-size:13px;color:#666;border-top:1px solid #eee;padding:8px 0}
table{width:100%;border-collapse:collapse;font-size:14px}
th,td{text-align:left;padding:8px;border-bottom:1px solid #eee;vertical-align:top}
.st-waiting{color:#a87b1f}.st-uploading{color:#2a7de1}.st-done{color:#2e9e4f}
.st-failed{color:#d33}.st-needs_code,.st-needs_approval{color:#b65fc7}
.badge{display:inline-block;background:#f3e9d2;border-radius:20px;
padding:2px 10px;font-size:12px;font-weight:700}
"""

JS = """
let lastJson = '';
async function refresh(){
  try{
    const r = await fetch('/queue_status');
    const text = await r.text();
    if(text === lastJson) return;  // nothing changed: leave the page (and typing) alone
    lastJson = text;
    const data = JSON.parse(text);
    const jobs = data.jobs, watches = data.watches, tasks = data.tasks;
    const tb = document.getElementById('qbody');
    // remember any code the user is typing so it is never wiped
    const saved = {};
    let focusedId = null;
    const active = document.activeElement;
    if(active && active.name==='code'){
      const idEl = active.closest('tr').querySelector('input[name="id"]');
      if(idEl) focusedId = idEl.value;
    }
    tb.querySelectorAll('tr').forEach(function(row){
      const idEl = row.querySelector('input[name="id"]');
      const codeEl = row.querySelector('input[name="code"]');
      if(idEl && codeEl && codeEl.value) saved[idEl.value] = codeEl.value;
    });
    tb.innerHTML = jobs.map(jobRow).join('') ||
      '<tr><td colspan="5" class="small">Queue is empty. Add posts above.</td></tr>';
    Object.keys(saved).forEach(function(id){
      const row = Array.from(tb.rows).find(function(r){
        const el = r.querySelector('input[name="id"]');
        return el && el.value===id;
      });
      if(row){
        const inp = row.querySelector('input[name="code"]');
        if(inp){
          inp.value = saved[id];
          if(id===focusedId){
            inp.focus();
            try{ inp.setSelectionRange(inp.value.length, inp.value.length); }catch(e){}
          }
        }
      }
    });
    const waiting = jobs.filter(j=>j.status==='waiting' && !j.scheduled_at).length;
    const uploading = jobs.filter(j=>j.status==='uploading').length;
    document.getElementById('postall').disabled = !(waiting>0) || uploading>0;
    document.getElementById('postall').textContent =
      uploading>0 ? '⏳ Posting…' : '🚀 Post now ('+waiting+')';
    const wb = document.getElementById('wbody');
    wb.innerHTML = watches.map(function(w){
      return '<tr><td class="small">'+esc(w.link.slice(0,38))+'…</td>'+
        '<td><span class="badge">'+esc(w.account)+'</span></td>'+
        '<td>'+esc(w.daily_time)+'</td>'+
        '<td><span class="small">'+esc(w.message||w.status)+'</span>'+
        (w.last_run ? '<br><span class="small">Last: '+esc(w.last_run)+'</span>' : '')+'</td>'+
        '<td><form method="post" action="/watch_remove" style="display:inline">'+
        '<input type="hidden" name="id" value="'+w.id+'">'+
        '<button class="mini gray" type="submit">Remove</button></form></td></tr>';
    }).join('') || '<tr><td colspan="5" class="small">No daily reposts set.</td></tr>';
    const td = document.getElementById('tasks');
    td.innerHTML = tasks.length ? tasks.map(function(t){
      return '<div class="hist">🔗 '+esc(t.link.slice(0,48))+'… → @'+esc(t.account)+
        ' — <b>'+esc(t.status)+'</b> <span class="small">'+esc(t.message)+'</span></div>';
    }).join('') : '<div class="small">No downloads yet.</div>';
  }catch(e){}
}
function esc(s){return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;')
  .replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function jobRow(j){
  const labels={waiting:'⏳ waiting',uploading:'⏳ uploading…',done:'✅ posted',
    failed:'❌ failed',needs_code:'📱 code needed',needs_approval:'🔐 approval needed'};
  let status = labels[j.status];
  if(j.status==='waiting' && j.scheduled_at &&
     new Date(j.scheduled_at) > new Date()) status='📅 scheduled';
  const when = j.scheduled_at
    ? '📅 '+j.scheduled_at.replace('T',' ').slice(0,16) : 'Now';
  let action='';
  if(j.status==='done'&&j.link)
    action='<a href="'+esc(j.link)+'" target="_blank">View post →</a>';
  else if(j.status==='failed')
    action='<span class="small">'+esc(j.message)+'</span><br>'+
      '<form method="post" action="/queue_retry" style="display:inline">'+
      '<input type="hidden" name="id" value="'+j.id+'">'+
      '<button class="mini" type="submit">Retry</button></form>';
  else if(j.status==='needs_code')
    action='<form method="post" action="/queue_code">'+
      '<input type="hidden" name="id" value="'+j.id+'">'+
      '<input type="text" name="code" placeholder="6-digit code" '+
      'inputmode="numeric" autocomplete="one-time-code" required '+
      'style="width:130px;display:inline-block">'+
      '<button class="mini" type="submit">Send</button></form>';
  else if(j.status==='needs_approval')
    action='<span class="small">Approve in the Instagram app, then:</span><br>'+
      '<form method="post" action="/queue_retry" style="display:inline">'+
      '<input type="hidden" name="id" value="'+j.id+'">'+
      '<button class="mini" type="submit">Retry</button></form>';
  else if(j.status==='waiting'){
    action='';
    if(j.scheduled_at)
      action+='<form method="post" action="/queue_now" style="display:inline">'+
        '<input type="hidden" name="id" value="'+j.id+'">'+
        '<button class="mini" type="submit">Post now</button></form> ';
    action+='<form method="post" action="/queue_remove" style="display:inline">'+
      '<input type="hidden" name="id" value="'+j.id+'">'+
      '<button class="mini gray" type="submit">Remove</button></form>';
  }
  else if(j.status==='uploading')
    action='<span class="small">Uploading…</span>';
  return '<tr><td><span class="badge">'+esc(j.account)+'</span><br>'+
    '<span class="small">'+esc(j.filename)+'</span></td>'+
    '<td>'+esc(j.caption.slice(0,60))+'</td>'+
    '<td class="small">'+when+'</td>'+
    '<td><span class="st-'+j.status+'">'+status+'</span></td>'+
    '<td>'+action+'</td></tr>';
}
setInterval(refresh,2500); refresh();
function toggleSched(){
  const checked = document.querySelector('input[name="when"]:checked');
  document.getElementById('schedbox').style.display =
    (checked && checked.value==='later') ? 'block' : 'none';
}
function toggleLinkMode(){
  const checked = document.querySelector('input[name="mode"]:checked');
  const v = checked ? checked.value : 'now';
  document.getElementById('link_once').style.display = v==='once' ? 'block' : 'none';
  document.getElementById('link_daily').style.display = v==='daily' ? 'block' : 'none';
}
"""

def page(title, body, js=""):
    script = f"<script>{js}</script>" if js else ""
    folder = html.escape(BASE.name)
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)} ({folder})</title><style>{CSS}</style></head>
<body><h1>📸 InstaUploader</h1>
<div class="small" style="margin:-8px 0 12px 2px">📁 Copy: <b>{folder}</b></div>{body}{script}</body></html>"""


def main_page(msg="", msg_cls=""):
    accounts = load_accounts()
    opts = "".join(f'<option value="{html.escape(a)}">{html.escape("@"+a)}</option>'
                   for a in accounts) or '<option value="">-- no accounts yet --</option>'
    hist = "".join(f'<div class="hist">{html.escape(h)}</div>'
                   for h in read_history()) or '<div class="small">Nothing posted yet.</div>'
    banner = f'<div class="{msg_cls}">{msg}</div>' if msg else ""
    return page("InstaUploader", f"""
{banner}
<div class="card"><h3>Your accounts</h3>
<form method="post" action="/add_account"><div class="row">
<div><label>Username</label><input type="text" name="username" placeholder="my_shop" required></div>
<div><label>Password</label><input type="password" name="password" required></div>
</div><button type="submit">+ Add account</button>
<p class="small">Saved only on this computer. Add each Instagram account once.</p></form>
<form method="post" action="/remove_account" style="margin-top:8px">
<div class="row"><div><label>Remove</label><select name="username">{opts}</select></div>
<div><label>&nbsp;</label><button type="submit">Remove</button></div></div></form></div>
<div class="card"><h3>➕ Add a post to the queue</h3>
<form method="post" action="/queue_add" enctype="multipart/form-data">
<label>Account</label><select name="account">{opts}</select>
<label>Photo or video</label><input type="file" name="media"
accept=".jpg,.jpeg,.png,.webp,.mp4,.mov" required>
<p class="small">Photos become posts, videos become reels.</p>
<label>Caption</label><textarea name="caption" rows="3"
placeholder="Write the caption for this post..."></textarea>
<label>When to post</label>
<div>
<label style="display:inline;font-weight:normal"><input type="radio" name="when" value="now" checked onchange="toggleSched()"> Post now</label>
<label style="display:inline;font-weight:normal;margin-left:18px"><input type="radio" name="when" value="later" onchange="toggleSched()"> Schedule for later</label>
</div>
<div id="schedbox" style="display:none;margin-top:8px">
<input type="datetime-local" name="scheduled_at">
<p class="small">It posts automatically at this time — keep the app open on your laptop.</p>
</div>
<button type="submit">Add to queue</button></form>
<p class="small">Add as many as you like — each can go to a different account,
and each can be "Post now" or "Schedule for later". Both work in one queue.</p></div>
<div class="card"><h3>📋 Queue</h3>
<table><thead><tr><th>Post</th><th>Caption</th><th>When</th><th>Status</th><th></th></tr></thead>
<tbody id="qbody"></tbody></table>
<form method="post" action="/queue_start">
<button type="submit" id="postall" class="big">🚀 Post now</button></form>
<p class="small">Posts everything marked "Post now". Scheduled posts wait for
their time automatically.</p>
<form method="post" action="/queue_clear" style="margin-top:6px">
<button type="submit" class="mini gray">Clear finished</button></form></div>
<div class="card"><h3>🔗 Repost from link</h3>
<p class="small">Paste a link — Instagram, TikTok, YouTube or Pinterest.
The app downloads the photo/video by itself, then posts it now,
once at a set time, or every day.</p>
<form method="post" action="/link_add">
<label>Post link</label><input type="text" name="link"
placeholder="https://... (Instagram / TikTok / YouTube / Pinterest)" required>
<label>Post to account</label><select name="account">{opts}</select>
<label>Caption</label><textarea name="caption" rows="2"
placeholder="Caption for the repost..."></textarea>
<label>How</label>
<div>
<label style="display:inline;font-weight:normal"><input type="radio" name="mode" value="now" checked onchange="toggleLinkMode()"> Download &amp; post now</label><br>
<label style="display:inline;font-weight:normal"><input type="radio" name="mode" value="once" onchange="toggleLinkMode()"> Download &amp; schedule once</label><br>
<label style="display:inline;font-weight:normal"><input type="radio" name="mode" value="daily" onchange="toggleLinkMode()"> Download &amp; post daily</label>
</div>
<div id="link_once" style="display:none;margin-top:8px">
<label>Post date &amp; time</label><input type="datetime-local" name="scheduled_at">
</div>
<div id="link_daily" style="display:none;margin-top:8px">
<label>Post every day at</label><input type="time" name="daily_time" value="10:00">
</div>
<button type="submit">Add</button></form>
<h4>Downloads</h4><div id="tasks"><div class="small">No downloads yet.</div></div>
<h4>Daily reposts</h4>
<table><thead><tr><th>Link</th><th>Account</th><th>Daily at</th><th>Status</th><th></th></tr></thead>
<tbody id="wbody"><tr><td colspan="5" class="small">No daily reposts set.</td></tr></tbody></table>
<form method="post" action="/linktask_clear" style="margin-top:6px">
<button type="submit" class="mini gray">Clear downloads</button></form></div>
<div class="card"><h3>Recent posts</h3>{hist}</div>""", JS)


# ------------------------------------------------------------- http server

def parse_multipart(body, boundary):
    fields = {}
    for part in body.split(b"--" + boundary):
        if b"\r\n\r\n" not in part:
            continue
        head, data = part.split(b"\r\n\r\n", 1)
        data = data[:-2] if data.endswith(b"\r\n") else data
        try:
            head_s = head.decode("utf-8", "replace")
        except Exception:
            continue
        name_m = re.search(r'name="([^"]+)"', head_s)
        if not name_m:
            continue
        name = name_m.group(1)
        fn_m = re.search(r'filename="([^"]*)"', head_s)
        if fn_m and fn_m.group(1):
            fields[name] = (fn_m.group(1), data)
        else:
            fields[name] = data.decode("utf-8", "replace").strip()
    return fields


class Handler(BaseHTTPRequestHandler):
    server_version = "InstaUploader/1.0"

    def log_message(self, *a):
        pass

    def send_html(self, html_text, code=200):
        data = html_text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, obj):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_form(self):
        length = int(self.headers.get("Content-Length", 0))
        ctype = self.headers.get("Content-Type", "")
        body = self.rfile.read(length) if length else b""
        if "multipart/form-data" in ctype and "boundary=" in ctype:
            boundary = ctype.split("boundary=")[1].encode()
            return parse_multipart(body, boundary)
        return {k: v[0] for k, v in parse_qs(body.decode("utf-8", "replace")).items()}

    def find_job(self, job_id):
        with QUEUE_LOCK:
            for j in QUEUE:
                if j.get("id") == job_id:
                    return j
        return None

    def do_GET(self):
        if self.path == "/":
            self.send_html(main_page())
        elif self.path == "/queue_status":
            with QUEUE_LOCK:
                jobs = [{k: j.get(k, "") for k in
                         ("id", "account", "filename", "caption", "status",
                          "message", "link", "scheduled_at")} for j in QUEUE]
                watches = [{k: w.get(k, "") for k in
                             ("id", "link", "account", "caption", "daily_time",
                              "last_run", "status", "message")} for w in WATCHES]
                tasks = [{k: t.get(k, "") for k in
                           ("id", "link", "account", "mode", "status",
                            "message")} for t in LINK_TASKS]
            self.send_json({"jobs": jobs, "watches": watches, "tasks": tasks})
        else:
            self.send_error(404)

    def do_POST(self):
        try:
            form = self.read_form()
        except Exception:
            self.send_html(main_page("Could not read the form. Please try again.", "err"))
            return

        if self.path == "/add_account":
            username = (form.get("username") or "").strip().lstrip("@")
            password = form.get("password") or ""
            accounts = load_accounts()
            if username:
                insert_account_ordered(accounts, username)
                save_accounts(accounts)
            if username:
                pw = load_passwords()
                pw[username] = password
                save_passwords(pw)
                self.send_html(main_page(f"✅ Account @{html.escape(username)} added.", "ok"))
            else:
                self.send_html(main_page("Please enter a username.", "err"))

        elif self.path == "/remove_account":
            username = form.get("username") or ""
            accounts = load_accounts()
            if username in accounts:
                groups = [g["name"] for g in load_groups()
                          if username in g.get("accounts", [])]
                remember_account(username, position=accounts.index(username),
                                 groups=groups)
            save_accounts([a for a in accounts if a != username])
            pw = load_passwords()
            pw.pop(username, None)
            save_passwords(pw)
            self.send_html(main_page(f"Account @{html.escape(username)} removed.", "ok"))

        elif self.path == "/queue_add":
            self.handle_queue_add(form)

        elif self.path == "/queue_remove":
            job = self.find_job(form.get("id") or "")
            if job and job.get("status") in ("waiting", "failed"):
                with QUEUE_LOCK:
                    QUEUE.remove(job)
                save_queue()
            self.send_html(main_page())

        elif self.path == "/queue_start":
            start_batch_thread()
            self.send_html(main_page("🚀 Posting everything in the queue…", "ok"))

        elif self.path == "/queue_now":
            job = self.find_job(form.get("id") or "")
            if job and job.get("status") == "waiting" and job.get("scheduled_at"):
                job["scheduled_at"] = ""
                job["message"] = ""
                save_queue()
                start_single_job(job)
            self.send_html(main_page())

        elif self.path == "/queue_retry":
            job = self.find_job(form.get("id") or "")
            if job and job.get("status") in ("failed", "needs_code", "needs_approval"):
                job["status"] = "waiting"
                job["message"] = ""
                save_queue()
                start_single_job(job)
            self.send_html(main_page())

        elif self.path == "/queue_code":
            job = self.find_job(form.get("id") or "")
            code = (form.get("code") or "").strip()
            if job and job.get("status") == "needs_code" and code:
                job["code"] = code
                job["status"] = "waiting"
                job["message"] = ""
                save_queue()
                start_single_job(job)
            self.send_html(main_page())

        elif self.path == "/link_add":
            link = (form.get("link") or "").strip()
            account = form.get("account") or ""
            caption = form.get("caption") or ""
            mode = (form.get("mode") or "now").strip()
            if not link_source_name(link):
                self.send_html(main_page(
                    "Please paste an Instagram, TikTok, YouTube or Pinterest link.",
                    "err"))
            elif account not in load_passwords():
                self.send_html(main_page(
                    f"No saved password for @{html.escape(account)}.", "err"))
            elif mode == "daily":
                daily_time = (form.get("daily_time") or "10:00").strip()
                try:
                    datetime.strptime(daily_time, "%H:%M")
                except ValueError:
                    self.send_html(main_page("Please pick a valid daily time.", "err"))
                    return
                w = {"id": secrets.token_hex(6), "link": link, "account": account,
                     "caption": caption, "daily_time": daily_time,
                     "last_run": "", "status": "active",
                     "message": "Will download and post daily."}
                with QUEUE_LOCK:
                    WATCHES.append(w)
                save_watches()
                self.send_html(main_page(
                    f"✅ Daily repost set: @{html.escape(account)} at "
                    f"{html.escape(daily_time)} every day.", "ok"))
            else:
                sched = ""
                if mode == "once":
                    sched = (form.get("scheduled_at") or "").strip()
                    try:
                        datetime.fromisoformat(sched)
                    except ValueError:
                        sched = ""
                    if not sched:
                        self.send_html(main_page(
                            "Please pick a date and time, or choose another option.",
                            "err"))
                        return
                task = {"id": secrets.token_hex(6), "link": link,
                        "account": account, "caption": caption,
                        "mode": mode, "scheduled_at": sched,
                        "status": "waiting", "message": "Waiting to download…"}
                LINK_TASKS.append(task)
                threading.Thread(target=process_link, args=(task,),
                                 daemon=True).start()
                self.send_html(main_page(
                    "🔗 Download started — watch its progress below.", "ok"))

        elif self.path == "/watch_remove":
            wid = form.get("id") or ""
            with QUEUE_LOCK:
                WATCHES[:] = [w for w in WATCHES if w.get("id") != wid]
            save_watches()
            self.send_html(main_page())

        elif self.path == "/linktask_clear":
            LINK_TASKS[:] = [t for t in LINK_TASKS
                             if t.get("status") in ("waiting", "downloading",
                                                     "posting")]
            self.send_html(main_page())

        elif self.path == "/queue_clear":
            with QUEUE_LOCK:
                QUEUE[:] = [j for j in QUEUE
                            if j.get("status") not in ("done", "failed")]
            save_queue()
            self.send_html(main_page())

        else:
            self.send_error(404)

    def handle_queue_add(self, form):
        account = form.get("account") or ""
        caption = form.get("caption") or ""
        file_field = form.get("media")

        if not account:
            self.send_html(main_page("Add an Instagram account first.", "err"))
            return
        if account not in load_passwords():
            self.send_html(main_page(
                f"No saved password for @{html.escape(account)}. Remove and re-add it.", "err"))
            return
        if not isinstance(file_field, tuple) or not file_field[1]:
            self.send_html(main_page("Choose a photo or video first.", "err"))
            return
        filename, data = file_field
        ext = Path(filename).suffix.lower()
        if ext not in IMAGE_EXTS | VIDEO_EXTS:
            self.send_html(main_page("Please choose a JPG/PNG photo or MP4 video.", "err"))
            return

        safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", Path(filename).name)
        dest = UPLOADS / f"{int(time.time())}_{safe}"
        dest.write_bytes(data)

        when = (form.get("when") or "now").strip()
        sched = ""
        if when == "later":
            sched = (form.get("scheduled_at") or "").strip()
            try:
                datetime.fromisoformat(sched)
            except ValueError:
                sched = ""
            if not sched:
                self.send_html(main_page(
                    "Please pick a date and time for the scheduled post, "
                    "or choose “Post now”.", "err"))
                return

        job = {"id": secrets.token_hex(6), "account": account,
               "filename": Path(filename).name, "filepath": str(dest),
               "caption": caption, "status": "waiting", "message": "",
               "link": "", "code": "", "scheduled_at": sched}
        with QUEUE_LOCK:
            QUEUE.append(job)
        save_queue()
        self.send_html(main_page(
            f"✅ Added to queue for @{html.escape(account)}.", "ok"))


def free_port():
    import socket
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def main():
    load_queue()
    load_watches()
    port = 8080
    try:
        server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except OSError:
        port = free_port()
        server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = f"http://127.0.0.1:{port}/"
    print(f"\n  InstaUploader is running! Opening {url}\n"
          "  Keep this window open while you use it.\n")
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    threading.Thread(target=scheduler_loop, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
